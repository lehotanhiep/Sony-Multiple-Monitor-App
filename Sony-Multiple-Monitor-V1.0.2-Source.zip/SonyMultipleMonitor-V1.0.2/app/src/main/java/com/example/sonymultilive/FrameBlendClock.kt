package com.example.sonymultilive

/** Monotonic timing only; ImageView alpha does the blend without CPU frame copies. */
class FrameBlendClock(private val fps: Int = 25) {
    val intervalMs = (1000L / fps.coerceAtLeast(1)).coerceAtLeast(1L)
    private var lastFrameMs: Long? = null
    private var startedMs = 0L
    private var durationMs = 0L
    private var nextMs = 0L
    fun frameArrived(now: Long, hasPrevious: Boolean) {
        val gap = lastFrameMs?.let { (now - it).coerceAtLeast(0L) } ?: 0L
        lastFrameMs = now
        startedMs = now
        // Already-fast sources remain immediate. Long stale gaps also start fresh.
        durationMs = if (hasPrevious && gap > intervalMs && gap <= 1000L) gap.coerceIn(intervalMs, 120L) else 0L
    }
    fun alpha(now: Long): Float = if (durationMs == 0L) 1f
        else ((now - startedMs).toFloat() / durationMs).coerceIn(0f, 1f)
    fun delayToNextTick(now: Long): Long {
        if (nextMs <= now) {
            if (nextMs == 0L || now - nextMs >= intervalMs) nextMs = now + intervalMs
            else nextMs += intervalMs
        }
        return (nextMs - now).coerceAtLeast(1L)
    }
    fun resetTicker() { nextMs = 0L }
}
