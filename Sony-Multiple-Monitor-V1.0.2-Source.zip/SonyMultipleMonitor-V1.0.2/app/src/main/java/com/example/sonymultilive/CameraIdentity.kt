package com.example.sonymultilive

/** Physical identity; never merge two cameras just because model/name matches. */
data class CameraIdentity(
    val transport: CameraTransport,
    val id: String,
    val ip: String,
    val mac: String,
    val serial: String,
    val usbPath: String
) {
    fun sameEndpoint(other: CameraIdentity): Boolean {
        if (transport != other.transport) return false
        if (transport == CameraTransport.PTP_IP) {
            if (ip.isNotEmpty() && ip == other.ip) return true
            if (mac.isNotEmpty() && mac == other.mac) return true
        } else if (usbPath.isNotEmpty() && usbPath == other.usbPath) return true
        // Conflicting known MACs/serials must not merge by a bad shared UDN.
        if (mac.isNotEmpty() && other.mac.isNotEmpty() && mac != other.mac) return false
        if (serial.isNotEmpty() && serial == other.serial) return true
        if (serial.isNotEmpty() && other.serial.isNotEmpty() && serial != other.serial) return false
        if (transport == CameraTransport.PTP_IP && ip.isNotEmpty() && other.ip.isNotEmpty() && ip != other.ip) return false
        return id.isNotEmpty() && id == other.id
    }

    fun matchesSaved(other: CameraIdentity): Boolean {
        if (transport != other.transport) return false
        if (mac.isNotEmpty() && other.mac.isNotEmpty()) return mac == other.mac
        if (serial.isNotEmpty() && other.serial.isNotEmpty()) return serial == other.serial
        return sameEndpoint(other)
    }

    fun enrichedBy(other: CameraIdentity): CameraIdentity = copy(
        id = other.id.ifBlank { id }, ip = other.ip.ifBlank { ip },
        mac = other.mac.ifBlank { mac }, serial = other.serial.ifBlank { serial },
        usbPath = other.usbPath.ifBlank { usbPath }
    )

    companion object {
        fun normalizeIp(value: String): String {
            val host = value.trim().lowercase().removePrefix("http://").removePrefix("https://")
                .substringBefore('/').substringBefore(':')
            val parts = host.split('.')
            if (parts.size == 4 && parts.all { it.toIntOrNull() in 0..255 }) {
                return parts.joinToString(".") { it.toInt().toString() }
            }
            return host
        }
        fun normalizeMac(value: String): String {
            val normalized = value.trim().replace(":", "").replace("-", "").replace(".", "").lowercase()
            return normalized.takeIf { it.matches(Regex("[0-9a-f]{12}")) && it != "000000000000" && it != "ffffffffffff" }.orEmpty()
        }
        fun normalizeSerial(value: String): String {
            val serial = value.trim()
            return serial.takeUnless { it.isBlank() || it.all { c -> c == '0' } ||
                it.lowercase() in setOf("unknown", "n/a", "--") }.orEmpty()
        }
        fun of(camera: SonyCamera) = CameraIdentity(camera.transport, camera.id.trim(),
            if (camera.transport == CameraTransport.PTP_IP) normalizeIp(camera.host) else "",
            normalizeMac(camera.macAddress), normalizeSerial(camera.serialNumber), camera.usbDeviceName.trim())
    }
}
