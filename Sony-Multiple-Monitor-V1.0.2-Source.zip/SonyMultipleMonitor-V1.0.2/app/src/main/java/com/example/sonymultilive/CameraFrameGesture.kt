package com.example.sonymultilive

import kotlin.math.abs

/** Independent of camera transport: hold to enlarge, vertical swipe to return. */
class CameraFrameGesture(private val touchSlop: Float) {
    private var cameraId: String? = null
    private var downX = 0f
    private var downY = 0f
    private var downAt = 0L
    private var singlePointer = true
    var held = false
        private set
    val pendingHold: Boolean get() = cameraId != null

    fun begin(id: String?, x: Float, y: Float, now: Long) {
        cameraId = id
        downX = x
        downY = y
        downAt = now
        held = false
        singlePointer = true
    }
    fun move(x: Float, y: Float) {
        if (abs(x - downX) > touchSlop || abs(y - downY) > touchSlop) cameraId = null
    }
    fun multiplePointers() { singlePointer = false; cameraId = null }
    fun takeHold(now: Long): String? {
        if (!singlePointer || held || now - downAt < 2_000L) return null
        val id = cameraId ?: return null
        cameraId = null
        held = true
        return id
    }
    fun swipeDown(x: Float, y: Float, threshold: Float): Boolean {
        val dy = y - downY
        return singlePointer && !held && dy > threshold && dy > abs(x - downX) * 1.2f
    }
    fun swipeUp(x: Float, y: Float, threshold: Float): Boolean {
        val dy = downY - y
        return singlePointer && !held && dy > threshold && dy > abs(x - downX) * 1.2f
    }
    fun end() { cameraId = null; held = false; singlePointer = false }
}
