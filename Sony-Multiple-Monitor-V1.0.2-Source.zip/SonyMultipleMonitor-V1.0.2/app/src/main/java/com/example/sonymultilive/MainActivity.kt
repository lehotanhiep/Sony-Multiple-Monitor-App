package com.example.sonymultilive

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.graphics.Color
import android.os.Bundle
import android.os.SystemClock
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.provider.Settings
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.content.pm.PackageManager
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.BaseAdapter
import android.widget.PopupWindow
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

private const val ACTION_USB_PERMISSION = "com.example.sonymultilive.USB_PERMISSION"
private const val SONY_VENDOR_ID = 0x054c

class MainActivity : Activity() {
    private val networkExecutor = Executors.newCachedThreadPool()
    // Limit concurrent JPEG/Bitmap work so multiple 1024x576 cameras do not
    // create unnecessary Skia allocation/GC pressure.
    private val decodeExecutor = Executors.newFixedThreadPool(
        min(4, max(2, Runtime.getRuntime().availableProcessors()))
    )
    private val sessions = ConcurrentHashMap<String, SonyCameraSession>()
    @Volatile private var lastDirectReconnectAttemptMs = 0L
    @Volatile private var reconnectDiscoveryPending = false
    private val tiles = LinkedHashMap<String, CameraTileView>()
    private val remoteColumns = LinkedHashMap<String, RemoteCameraSettingColumnView>()
    private lateinit var toolButton: Button
    private lateinit var layoutButton: Button
    private lateinit var scanButton: Button
    private lateinit var addIpButton: Button
    private lateinit var hotspotButton: Button
    private lateinit var resolutionButton: Button
    private lateinit var liveViewButton: Button
    private lateinit var hotspotManager: PhoneHotspotManager
    private lateinit var hotspotConfigStore: HotspotConfigStore
    private lateinit var hotspotAutoDiscovery: HotspotCameraAutoDiscovery
    private lateinit var usbManager: UsbManager
    @Volatile private var connectionMode = ConnectionMode.CAMERA_WIFI
    @Volatile private var waitingForSystemHotspotReturn = false
    @Volatile private var systemHotspotMode = false
    private lateinit var grid: LinearLayout
    private lateinit var topControls: View
    private lateinit var bottomControls: View
    @Volatile private var scanning = false
    @Volatile private var maxCameras = 20
    @Volatile private var falseColorMode = 0
    @Volatile private var controlsHidden = false
    private var expandedCameraId: String? = null
    private val frameGesture by lazy { CameraFrameGesture(dp(14).toFloat()) }
    private var frameHoldDownEvent: MotionEvent? = null
    private val expandFrameHold = Runnable {
        val id = frameGesture.takeHold(SystemClock.uptimeMillis())
        if (id != null && tiles.containsKey(id)) {
            // Cancel the child's touch so releasing a hold cannot also send AF.
            frameHoldDownEvent?.let { down ->
                val cancel = MotionEvent.obtain(down)
                cancel.action = MotionEvent.ACTION_CANCEL
                cancelFrameChildTouch(cancel)
                cancel.recycle()
            }
            expandedCameraId = id
            rebuildGrid()
        }
        frameHoldDownEvent?.recycle()
        frameHoldDownEvent = null
    }
    @Volatile private var renderWidth = 1024
    @Volatile private var renderHeight = 576
    @Volatile private var gridLayoutMode = GridLayoutMode.TWO_BY_TWO
    private lateinit var globalPlaybackButton: TextView
    private lateinit var globalPreviousButton: TextView
    private lateinit var globalNextButton: TextView
    private lateinit var globalRecordButton: TextView
    private lateinit var globalHoldButton: TextView
    private lateinit var osdButton: Button
    private lateinit var falseColorButton: Button
    private lateinit var histogramButton: Button
    private val globalSettingButtons = LinkedHashMap<CameraSettingKey, TextView>()
    @Volatile private var osdVisible = true
    @Volatile private var globalHold = false
    @Volatile private var globalRecordRequested = false
    @Volatile private var globalRecordCommandKnown = false
    @Volatile private var globalRecordTakeCounter = 0
    private var globalRecordBlinkPhase = false
    private var globalRecordBlinkRunning = false
    private val globalRecordBlinkRunnable = object : Runnable {
        override fun run() {
            if (!::globalRecordButton.isInitialized ||
                sessions.values.none { it.isMovieRecording() } ||
                sessions.values.any { it.isPlaybackRequested() }
            ) {
                globalRecordBlinkRunning = false
                globalRecordBlinkPhase = false
                if (::globalRecordButton.isInitialized && sessions.values.none { it.isPlaybackRequested() }) {
                    applyGlobalRecordButtonStyle(recording = false, bright = false)
                }
                return
            }
            globalRecordBlinkPhase = !globalRecordBlinkPhase
            applyGlobalRecordButtonStyle(recording = true, bright = globalRecordBlinkPhase)
            globalRecordButton.postDelayed(this, 450L)
        }
    }
    @Volatile private var playbackToggleBusy = false
    @Volatile private var histogramVisible = false
    @Volatile private var liveViewAllEnabled = true
    @Volatile private var largeCameraLiveSelectMode = false
    @Volatile private var selectedLiveCameraId: String? = null
    private val slotAssignments = arrayOfNulls<String>(20)
    private val cameraSlotMemory = CameraSlotMemory(20)
    private val activeCameraIdentities = HashMap<String, CameraIdentity>()
    private lateinit var reconnectCoordinator: CameraReconnectCoordinator
    @Volatile private var reconnectScanning = false
    @Volatile private var lastReconnectAttemptMs = 0L

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            val device = usbDeviceFromIntent(intent)
            when (action) {
                ACTION_USB_PERMISSION -> {
                    if (device != null && usbManager.hasPermission(device)) {
                        connectUsbDevice(device)
                    }
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    if (device != null && SonyUsbCameraDiscovery.hasPtpInterface(device) && device.vendorId == SONY_VENDOR_ID) {
                        requestOrConnectUsbDevice(device)
                    }
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    if (device != null) removeUsbCamera(device)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraSlotMemory.load(getSharedPreferences("camera_fixed_slots", Context.MODE_PRIVATE)
            .getString("placements", "").orEmpty())
        window.decorView.keepScreenOn = true
        enterSystemFullscreen()
        hotspotManager = PhoneHotspotManager(this)
        hotspotConfigStore = HotspotConfigStore(this)
        hotspotAutoDiscovery = HotspotCameraAutoDiscovery(this)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        reconnectCoordinator = CameraReconnectCoordinator(
            this,
            onNetworkChanged = { onCameraNetworkChanged() },
            onPeriodicCheck = { checkCameraReconnects() }
        )
        setContentView(buildUi())
        registerUsbReceiver()
        // Startup monitor view is always the four-frame 2x2 canvas. Once cameras
        // are discovered, automatic layout follows the connected camera count.
        applyAutomaticLayoutForCameraCount(0)
        rebuildGrid()
        scanButton.setOnClickListener { scan() }
        toolButton.setOnClickListener { showToolMenu(toolButton) }
        layoutButton.setOnClickListener { showLayoutMenu(layoutButton) }
        osdButton.setOnClickListener { setOsdVisible(!osdVisible) }
        falseColorButton.setOnClickListener { toggleFalseColor() }
        histogramButton.setOnClickListener { setHistogramVisible(!histogramVisible) }
        liveViewButton.setOnClickListener { handleLiveViewButton() }
        resolutionButton.setOnClickListener {
            if (renderWidth == 1024) {
                renderWidth = 640
                renderHeight = 360
            } else {
                renderWidth = 1024
                renderHeight = 576
            }
            updateResolutionUi()
        }
        // Auto-discover and connect as soon as the UI is ready.
        window.decorView.postDelayed({ scan() }, 350L)
        reconnectCoordinator.start()
        // No periodic PTP reconnect. Settings are synchronized from Sony 0xC203
        // PropertyChanged events while the existing Live View session stays open.
    }

    override fun onResume() {
        super.onResume()
        if (waitingForSystemHotspotReturn) {
            waitingForSystemHotspotReturn = false
            systemHotspotMode = true
            connectionMode = ConnectionMode.PHONE_HOTSPOT
            updateHotspotButton()
            window.decorView.postDelayed({
                startHotspotAutoDiscovery()
            }, 900L)
        }
    }

    override fun onPause() {
        cancelFrameHold()
        frameGesture.end()
        super.onPause()
    }

    override fun onDestroy() {
        cancelFrameHold()
        sessions.values.forEach { it.close() }
        sessions.clear()
        if (::reconnectCoordinator.isInitialized) reconnectCoordinator.close()
        if (::hotspotAutoDiscovery.isInitialized) hotspotAutoDiscovery.close()
        if (::hotspotManager.isInitialized) hotspotManager.close()
        runCatching { unregisterReceiver(usbReceiver) }
        networkExecutor.shutdownNow()
        decodeExecutor.shutdownNow()
        SonyNetworkRoute.clearProcessBinding(this)
        super.onDestroy()
    }

    private fun buildUi(): View {
        val baseLeft = dp(2)
        val baseTop = dp(1)
        val baseRight = dp(2)
        val baseBottom = dp(1)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(baseLeft, baseTop, baseRight, baseBottom)
            setOnApplyWindowInsetsListener { view, insets ->
                val left: Int
                val top: Int
                val right: Int
                val bottom: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(
                        android.view.WindowInsets.Type.statusBars() or
                            android.view.WindowInsets.Type.navigationBars() or
                            android.view.WindowInsets.Type.displayCutout()
                    )
                    left = bars.left
                    top = bars.top
                    right = bars.right
                    bottom = bars.bottom
                } else {
                    left = insets.systemWindowInsetLeft
                    top = insets.systemWindowInsetTop
                    right = insets.systemWindowInsetRight
                    bottom = insets.systemWindowInsetBottom
                }
                view.setPadding(
                    baseLeft + left,
                    baseTop + top,
                    baseRight + right,
                    baseBottom + bottom
                )
                insets
            }
        }

        fun sonyTopText(label: String, size: Float = 10f, bold: Boolean = false) = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = size
            gravity = Gravity.CENTER
            typeface = if (bold) UiFonts.MEDIUM else UiFonts.REGULAR
            setPadding(dp(6), 0, dp(6), 0)
        }

        // Keep backing buttons alive because the connection engine and TOOL menu
        // still dispatch through them. Only TOOL is presented in the Sony-style header.
        scanButton = Button(this).apply { text = "SCAN" }
        addIpButton = Button(this).apply { text = "+IP" }
        hotspotButton = Button(this).apply { text = "HOTSPOT" }
        resolutionButton = Button(this).apply { text = "RES HIGH 1024" }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xaa000000.toInt())
            setPadding(dp(8), dp(2), dp(8), dp(2))
        }

        val clock = sonyTopText("--:--", 10f, true)
        fun updateClock() {
            val now = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            clock.text = now
        }
        updateClock()
        clock.post(object : Runnable {
            override fun run() {
                updateClock()
                clock.postDelayed(this, 30_000L)
            }
        })
        topBar.addView(clock, LinearLayout.LayoutParams(dp(54), LinearLayout.LayoutParams.MATCH_PARENT))

        toolButton = Button(this).apply {
            text = "≡  TOOL ▼"
            textSize = 10f
            setTextColor(Color.WHITE)
            typeface = UiFonts.MEDIUM
            minWidth = 0
            minimumWidth = 0
            minimumHeight = 0
            setPadding(dp(8), 0, dp(8), 0)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(0, Color.TRANSPARENT)
            }
        }
        topBar.addView(toolButton, LinearLayout.LayoutParams(dp(92), dp(34)))

        falseColorButton = Button(this).apply {
            text = "FALSE COLOR"
            textSize = 8f
            setTextColor(Color.WHITE)
            typeface = UiFonts.MEDIUM
            minWidth = 0
            minimumWidth = 0
            minimumHeight = 0
            setPadding(dp(5), 0, dp(5), 0)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x22000000)
                setStroke(dp(1), 0xff55585d.toInt())
                cornerRadius = dp(3).toFloat()
            }
        }
        topBar.addView(falseColorButton, LinearLayout.LayoutParams(dp(82), dp(30)).apply { marginEnd = dp(5) })

        histogramButton = Button(this).apply {
            text = "HIST"
            textSize = 8f
            setTextColor(Color.WHITE)
            typeface = UiFonts.MEDIUM
            minWidth = 0
            minimumWidth = 0
            minimumHeight = 0
            setPadding(dp(5), 0, dp(5), 0)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x22000000)
                setStroke(dp(1), 0xff55585d.toInt())
                cornerRadius = dp(3).toFloat()
            }
        }
        topBar.addView(histogramButton, LinearLayout.LayoutParams(dp(54), dp(30)).apply { marginEnd = dp(5) })

        topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        osdButton = Button(this).apply {
            text = "OSD ON"
            textSize = 9f
            setTextColor(Color.WHITE)
            typeface = UiFonts.MEDIUM
            minWidth = 0
            minimumWidth = 0
            minimumHeight = 0
            setPadding(dp(8), 0, dp(8), 0)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x22000000)
                setStroke(dp(1), 0xff55585d.toInt())
                cornerRadius = dp(3).toFloat()
            }
        }
        topBar.addView(osdButton, LinearLayout.LayoutParams(dp(72), dp(30)).apply {
            marginEnd = dp(6)
        })
        resolutionButton.apply {
            text = if (renderWidth == 1024) "RES HIGH" else "RES LOW"
            textSize = 8f
            setTextColor(Color.WHITE)
            typeface = UiFonts.MEDIUM
            minWidth = 0
            minimumWidth = 0
            minimumHeight = 0
            setPadding(dp(6), 0, dp(6), 0)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x22000000)
                setStroke(dp(1), 0xff55585d.toInt())
                cornerRadius = dp(3).toFloat()
            }
        }
        topBar.addView(resolutionButton, LinearLayout.LayoutParams(dp(72), dp(30)).apply {
            marginEnd = dp(6)
        })
        liveViewButton = Button(this).apply {
            text = "LIVE ON"
            textSize = 8f
            setTextColor(0xff67e56f.toInt())
            typeface = UiFonts.MEDIUM
            minWidth = 0
            minimumWidth = 0
            minimumHeight = 0
            setPadding(dp(6), 0, dp(6), 0)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x22000000)
                setStroke(dp(1), 0xff55585d.toInt())
                cornerRadius = dp(3).toFloat()
            }
        }
        topBar.addView(liveViewButton, LinearLayout.LayoutParams(dp(86), dp(30)).apply {
            marginEnd = dp(6)
        })
        layoutButton = Button(this).apply {
            text = gridLayoutMode.buttonLabel()
            textSize = 9f
            setTextColor(Color.WHITE)
            typeface = UiFonts.MEDIUM
            minWidth = 0
            minimumWidth = 0
            minimumHeight = 0
            setPadding(dp(8), 0, dp(8), 0)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x22000000)
                setStroke(dp(1), 0xff55585d.toInt())
                cornerRadius = dp(3).toFloat()
            }
        }
        topBar.addView(layoutButton, LinearLayout.LayoutParams(dp(124), dp(30)).apply {
            marginEnd = dp(8)
        })
        topBar.addView(sonyTopText("100%", 9f, true).apply {
            setTextColor(0xff67e56f.toInt())
        }, LinearLayout.LayoutParams(dp(48), dp(34)))

        topControls = topBar
        root.addView(topBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)))

        grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
            weightSum = 2f
            setBackgroundColor(Color.BLACK)
        }
        root.addView(grid, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // Global camera settings + transport live in one footer. Settings here are
        // intentionally broadcast to every connected camera; per-tile touch focus
        // and the existing tile setting wheel remain available for camera-specific work.
        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(3), dp(8), dp(3))
            setBackgroundColor(0xff050708.toInt())
        }

        val allCamLabel = TextView(this).apply {
            text = "ALL CAM"
            setTextColor(0xff54e5d0.toInt())
            textSize = 8f
            typeface = UiFonts.MEDIUM
            gravity = Gravity.CENTER
            setPadding(dp(4), 0, dp(4), 0)
        }
        bottomBar.addView(allCamLabel, LinearLayout.LayoutParams(dp(48), dp(42)).apply { marginEnd = dp(3) })

        val globalSettingsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val globalSettingsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isFillViewport = false
            addView(globalSettingsRow, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
        }

        val globalKeys = listOf(
            CameraSettingKey.RECORD_FRAME_RATE,
            CameraSettingKey.FOCUS_MODE,
            CameraSettingKey.IRIS,
            CameraSettingKey.ISO,
            CameraSettingKey.SHUTTER,
            CameraSettingKey.EXPOSURE_COMPENSATION,
            CameraSettingKey.WHITE_BALANCE,
            CameraSettingKey.LOOK
        )
        globalKeys.forEach { key ->
            val chip = TextView(this).apply {
                text = "${globalSettingShortTitle(key)}\n--"
                setTextColor(Color.WHITE)
                textSize = 8f
                typeface = UiFonts.MEDIUM
                gravity = Gravity.CENTER
                maxLines = 2
                setPadding(dp(5), 0, dp(5), 0)
                isClickable = true
                isFocusable = true
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(0x22000000)
                    setStroke(dp(1), 0xff4b4f54.toInt())
                    cornerRadius = dp(3).toFloat()
                }
                setOnClickListener { showGlobalSettingWheel(this, key) }
            }
            globalSettingButtons[key] = chip
            val width = when (key) {
                CameraSettingKey.SHUTTER -> dp(82)
                CameraSettingKey.WHITE_BALANCE -> dp(74)
                CameraSettingKey.RECORD_FRAME_RATE -> dp(68)
                else -> dp(64)
            }
            globalSettingsRow.addView(chip, LinearLayout.LayoutParams(width, dp(42)).apply { marginEnd = dp(3) })
        }
        bottomBar.addView(globalSettingsScroll, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) })

        val transportBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
        }
        globalPlaybackButton = TextView(this).apply {
            text = "PLAYBACK"
            setTextColor(Color.WHITE)
            textSize = 8f
            typeface = UiFonts.MEDIUM
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x44000000)
                setStroke(dp(1), 0xff777b80.toInt())
                cornerRadius = dp(3).toFloat()
            }
            setOnClickListener { togglePlaybackAllCameras() }
        }
        globalPreviousButton = TextView(this).apply {
            text = "<"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = UiFonts.MEDIUM
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            visibility = View.GONE
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x44000000)
                setStroke(dp(1), 0xff777b80.toInt())
                cornerRadius = dp(5).toFloat()
            }
            setOnClickListener { previousAllPlaybackCameras() }
        }
        globalNextButton = TextView(this).apply {
            text = ">"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = UiFonts.MEDIUM
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            visibility = View.GONE
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x44000000)
                setStroke(dp(1), 0xff777b80.toInt())
                cornerRadius = dp(5).toFloat()
            }
            setOnClickListener { nextAllPlaybackCameras() }
        }
        globalRecordButton = TextView(this).apply {
            text = "REC"
            setTextColor(Color.WHITE)
            textSize = 9f
            typeface = UiFonts.MEDIUM
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                // REC keeps its red fill at all times. The border alone conveys
                // idle/recording state: green at rest, blinking red while REC is active.
                setColor(0xffd91625.toInt())
                setStroke(dp(2), 0xff36e06f.toInt())
            }
            setOnClickListener {
                if (sessions.values.any { it.isPlaybackRequested() }) togglePlayPauseAllPlaybackCameras()
                else toggleAllCameraRecording()
            }
        }
        globalHoldButton = TextView(this).apply {
            text = "HOLD  ○"
            setTextColor(Color.WHITE)
            textSize = 9f
            typeface = UiFonts.MEDIUM
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x66000000)
                setStroke(dp(1), 0xffbfc2c7.toInt())
                cornerRadius = dp(15).toFloat()
            }
            setOnClickListener { setGlobalHold(!globalHold) }
        }
        transportBar.addView(globalPlaybackButton, LinearLayout.LayoutParams(dp(68), dp(34)).apply { marginEnd = dp(5) })
        transportBar.addView(globalPreviousButton, LinearLayout.LayoutParams(dp(38), dp(34)).apply { marginEnd = dp(4) })
        transportBar.addView(globalRecordButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(8) })
        transportBar.addView(globalNextButton, LinearLayout.LayoutParams(dp(38), dp(34)).apply { marginEnd = dp(4) })
        transportBar.addView(globalHoldButton, LinearLayout.LayoutParams(dp(82), dp(30)))
        bottomBar.addView(transportBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(50)))

        bottomControls = bottomBar
        root.addView(bottomBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)))
        return root
    }

    private fun showLayoutMenu(anchor: View) {
        restoreExpandedFrame()
        if (!liveViewAllEnabled || largeCameraLiveSelectMode || (tiles.size > 4 || highestAssignedSlot() >= 4)) {
            Toast.makeText(this, "Layout is fixed in CONTROL ONLY / single-camera Live mode", Toast.LENGTH_SHORT).show()
            return
        }
        val popup = darkPopupMenu(anchor)
        GridLayoutMode.values().forEachIndexed { order, mode ->
            popup.menu.add(0, mode.menuItemId, order, mode.menuLabel)
        }
        popup.setOnMenuItemClickListener { item ->
            val next = GridLayoutMode.fromMenuItemId(item.itemId)
                ?: return@setOnMenuItemClickListener false
            gridLayoutMode = next
            layoutButton.text = next.buttonLabel()
            rebuildGrid()
            true
        }
        popup.show()
    }

    private fun showToolMenu(anchor: View) {
        val popup = darkPopupMenu(anchor)
        popup.menu.add(0, 1, 0, "SCAN NEW · Wi-Fi/AP + USB PTP")
        popup.menu.add(0, 4, 1, "RECONNECT CAMERAS")
        val assignMenu = popup.menu.addSubMenu("ASSIGN CAMERAS TO SLOTS")
        // One-tap escape hatch from any manual slot map. This intentionally does
        // not reconnect/rescan cameras; it only restores Automatic placement.
        assignMenu.add(0, 1900, 0, "RESET ALL · AUTOMATIC")
        for (slot in slotAssignments.indices) {
            val slotMenu = assignMenu.addSubMenu("Slot ${slot + 1}")
            val automatic = slotAssignments[slot] == null
            slotMenu.add(0, 2000 + slot * 100, 0, if (automatic) "✓ Automatic" else "Automatic")
            tiles.values.forEachIndexed { index, tile ->
                val label = tile.camera.displayName.ifBlank { tile.camera.endpointLabel }
                val assigned = slotAssignments[slot] == tile.camera.id
                slotMenu.add(0, 2001 + slot * 100 + index, index + 1, if (assigned) "✓ $label · ${tile.camera.endpointLabel}" else "$label · ${tile.camera.endpointLabel}")
            }
        }
        popup.setOnMenuItemClickListener { item ->
            if (item.itemId in 2000 until (2000 + slotAssignments.size * 100)) {
                val slot = (item.itemId - 2000) / 100
                val offset = (item.itemId - 2000) % 100
                if (slot in slotAssignments.indices) {
                    if (offset == 0) clearSlotAssignment(slot)
                    else {
                        val tileList: List<CameraTileView> = tiles.values.toList()
                        val tileIndex: Int = offset - 1
                        if (tileIndex >= 0 && tileIndex < tileList.size) {
                            val selectedTile: CameraTileView = tileList[tileIndex]
                            val selectedCameraId: String = selectedTile.camera.id
                            assignCameraToSlot(slot, selectedCameraId)
                        }
                    }
                    return@setOnMenuItemClickListener true
                }
            }
            when (item.itemId) {
                1 -> { scan(); true }
                1900 -> {
                    resetAllSlotAssignments()
                    true
                }
                4 -> {
                    if (sessions.isEmpty()) {
                        scan()
                    } else {
                        // Reconnect either PTP/IP or USB PTP while preserving each
                        // camera's Live View / CONTROL ONLY selection.
                        sessions.values.forEach { session ->
                            if (session.isPlaybackRequested()) session.resumeLiveView() else session.retryDirectPtp()
                        }
                        refreshPlaybackTransportUi()
                        Toast.makeText(this, "Reconnecting cameras", Toast.LENGTH_SHORT).show()
                    }
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    /**
     * PLAYBACK is a true toggle. First press emulates the physical Playback key
     * on all connected cameras; the second press emulates the same key again to
     * leave Playback, then restores Remote Live View.
     */
    private fun togglePlaybackAllCameras() {
        if (sessions.isEmpty()) {
            Toast.makeText(this, "No cameras connected", Toast.LENGTH_SHORT).show()
            return
        }

        val exiting = sessions.values.any { it.isPlaybackRequested() }
        val targets = if (exiting) {
            sessions.values.filter { it.isPlaybackRequested() }
        } else {
            sessions.values.toList()
        }
        if (targets.isEmpty()) {
            refreshPlaybackTransportUi()
            return
        }

        globalPlaybackButton.isEnabled = false
        globalPlaybackButton.alpha = 0.55f
        var remaining = targets.size
        var accepted = 0
        targets.forEach { session ->
            val callback: (Boolean) -> Unit = { ok ->
                runOnUiThread {
                    if (ok) accepted++
                    remaining--
                    if (remaining <= 0) {
                        globalPlaybackButton.isEnabled = true
                        globalPlaybackButton.alpha = 1f
                        refreshPlaybackTransportUi()
                        Toast.makeText(
                            this,
                            if (exiting) "Exit Playback $accepted/${targets.size} camera"
                            else "Playback $accepted/${targets.size} camera",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            if (exiting) session.exitPlaybackMode(callback) else session.enterPlaybackMode(callback)
        }
    }

    /**
     * ALL CAM playback transport. The center PLAY button is a single toggle:
     * stopped -> PLAY, playing -> PAUSE. ZV-E10M2 maps both actions to the
     * working physical CENTER/ENTER path inside SonyCameraSession.
     */
    private fun togglePlayPauseAllPlaybackCameras() {
        val targets = sessions.values.filter { it.isPlaybackRequested() }
        if (targets.isEmpty() || playbackToggleBusy) return

        // Keep the PLAY button visually static. ZV-E10M2 uses the same physical
        // CENTER/ENTER key for play and pause, while the per-session state only
        // decides which semantic helper to call on other Sony bodies.
        playbackToggleBusy = true
        var remaining = targets.size
        var accepted = 0
        targets.forEach { session ->
            val callback: (Boolean) -> Unit = { ok ->
                runOnUiThread {
                    if (ok) accepted++
                    remaining--
                    if (remaining <= 0) {
                        playbackToggleBusy = false
                        if (accepted == 0) {
                            Toast.makeText(this, "Play/Pause not supported by camera", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            if (session.isMoviePlaybackPlaying()) session.playbackPause(callback)
            else session.playbackPlay(callback)
        }
    }

    private fun previousAllPlaybackCameras() = navigateAllPlaybackCameras(previous = true)

    private fun nextAllPlaybackCameras() = navigateAllPlaybackCameras(previous = false)

    private fun navigateAllPlaybackCameras(previous: Boolean) {
        val targets = sessions.values.filter { it.isPlaybackRequested() }
        if (targets.isEmpty()) return

        val button = if (previous) globalPreviousButton else globalNextButton
        val unsupportedMessage = if (previous) {
            "Previous file not supported by camera"
        } else {
            "Next file not supported by camera"
        }
        button.isEnabled = false
        button.alpha = 0.55f

        var remaining = targets.size
        var accepted = 0
        targets.forEach { session ->
            val callback: (Boolean) -> Unit = { ok ->
                runOnUiThread {
                    if (ok) accepted++
                    remaining--
                    if (remaining <= 0) {
                        button.isEnabled = true
                        button.alpha = 1f
                        refreshPlaybackTransportUi()
                        if (accepted == 0) {
                            Toast.makeText(this, unsupportedMessage, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            if (previous) session.playbackPrevious(callback) else session.playbackNext(callback)
        }
    }

    private fun refreshPlaybackTransportUi() {
        if (!::globalPlaybackButton.isInitialized) return
        val active = sessions.values.any { it.isPlaybackRequested() }

        globalPlaybackButton.text = if (active) "LIVE VIEW" else "PLAYBACK"
        globalPlaybackButton.setTextColor(if (active) 0xffffd84a.toInt() else Color.WHITE)
        globalPreviousButton.visibility = if (active) View.VISIBLE else View.GONE
        globalNextButton.visibility = if (active) View.VISIBLE else View.GONE
        globalHoldButton.visibility = if (active) View.GONE else View.VISIBLE

        if (active) {
            stopGlobalRecordBlink()
            // Playback transport is intentionally command-driven only. The center
            // control always looks exactly the same: <  PLAY  >. Each tap toggles
            // play/pause on the camera without changing text, color, or shape.
            globalRecordButton.text = "PLAY"
            globalRecordButton.setTextColor(Color.WHITE)
            globalRecordButton.background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x44000000)
                setStroke(dp(1), 0xff777b80.toInt())
                cornerRadius = dp(5).toFloat()
            }
            globalRecordButton.layoutParams = LinearLayout.LayoutParams(dp(58), dp(34)).apply { marginEnd = dp(4) }
        } else {
            playbackToggleBusy = false
            // Leave Playback -> restore normal REC/STOP and HOLD transport.
            globalRecordButton.setTextColor(Color.WHITE)
            globalRecordButton.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(8) }
            updateGlobalRecordUi()
        }

        // Tiles retain Playback state only to suppress disconnect warnings; all
        // playback transport controls live in the ALL CAM bar.
        tiles.forEach { (cameraId, tile) ->
            val tileActive = sessions[cameraId]?.isPlaybackRequested() == true
            tile.setPlaybackMode(tileActive, false)
        }
    }

    private fun toggleFalseColor() {
        falseColorMode = if (falseColorMode == FalseColorPalette.OFF) FalseColorPalette.SDR else FalseColorPalette.OFF
        tiles.values.forEach { it.setFalseColorMode(falseColorMode) }
        if (::falseColorButton.isInitialized) {
            val on = falseColorMode != FalseColorPalette.OFF
            falseColorButton.text = if (on) "FALSE ON" else "FALSE COLOR"
            falseColorButton.setTextColor(if (on) 0xffffd84a.toInt() else Color.WHITE)
        }
    }

    private fun setHistogramVisible(visible: Boolean) {
        histogramVisible = visible
        tiles.values.forEach { it.setHistogramVisible(visible) }
        if (::histogramButton.isInitialized) {
            histogramButton.text = if (visible) "HIST ON" else "HIST"
            histogramButton.setTextColor(if (visible) 0xff54e5d0.toInt() else Color.WHITE)
        }
    }

    private fun handleLiveViewButton() {
        if ((tiles.size > 4 || highestAssignedSlot() >= 4) || largeCameraLiveSelectMode) {
            showLiveCameraSelectionMenu(liveViewButton)
        } else {
            setAllLiveViewEnabled(!liveViewAllEnabled)
        }
    }

    private fun setAllLiveViewEnabled(enabled: Boolean) {
        largeCameraLiveSelectMode = false
        selectedLiveCameraId = null
        liveViewAllEnabled = enabled
        tiles.forEach { (id, tile) ->
            tile.setLiveViewEnabled(enabled)
            sessions[id]?.setLiveViewEnabled(enabled)
        }
        updateLiveViewButton()
        rebuildGrid()
        Toast.makeText(
            this,
            if (enabled) "Live View ON" else "Live View OFF · remote control remains active",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun enterLargeCameraLiveSelectMode(showToast: Boolean = true) {
        if (!largeCameraLiveSelectMode) {
            largeCameraLiveSelectMode = true
            selectedLiveCameraId = null
            liveViewAllEnabled = false
            tiles.forEach { (id, tile) ->
                tile.setLiveViewEnabled(false)
                sessions[id]?.setLiveViewEnabled(false)
            }
            if (showToast) {
                Toast.makeText(
                    this,
                    "More than 4 cameras · Live View OFF · remote control only",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        updateLiveViewButton()
    }

    private fun updateLiveViewModeForCameraCount() {
        if ((tiles.size > 4 || highestAssignedSlot() >= 4)) {
            enterLargeCameraLiveSelectMode()
        } else {
            // A fresh SCAN explicitly resets fleet mode. Do not auto-exit here:
            // reconnect/replacement can temporarily drop a >4-camera fleet below
            // five tiles and must not restart JPEG streams by accident.
            updateLiveViewButton()
        }
    }

    private fun shouldCameraUseLiveView(cameraId: String): Boolean =
        if (largeCameraLiveSelectMode || (tiles.size > 4 || highestAssignedSlot() >= 4)) selectedLiveCameraId == cameraId else liveViewAllEnabled

    private fun selectLiveCamera(cameraId: String?) {
        largeCameraLiveSelectMode = true
        liveViewAllEnabled = false
        selectedLiveCameraId = cameraId
        tiles.forEach { (id, tile) ->
            val enabled = id == cameraId
            tile.setLiveViewEnabled(enabled)
            sessions[id]?.setLiveViewEnabled(enabled)
        }
        updateLiveViewButton()
        rebuildGrid()
    }

    private fun showLiveCameraSelectionMenu(anchor: View) {
        val popup = darkPopupMenu(anchor)
        val displayTiles = tilesForFixedSlots().mapIndexedNotNull { slot, tile ->
            tile?.let { slot to it }
        }
        popup.menu.add(0, 4000, 0, if (selectedLiveCameraId == null) "✓ OFF · CONTROL ONLY" else "OFF · CONTROL ONLY")
        displayTiles.forEachIndexed { menuIndex, (slot, tile) ->
            val camera = tile.camera
            val label = camera.displayName.ifBlank { camera.endpointLabel }
            val selected = selectedLiveCameraId == camera.id
            val camNumber = slot + 1
            popup.menu.add(0, 4001 + menuIndex, menuIndex + 1, if (selected) "✓ CAM $camNumber · $label" else "CAM $camNumber · $label")
        }
        popup.setOnMenuItemClickListener { item ->
            when {
                item.itemId == 4000 -> {
                    selectLiveCamera(null)
                    true
                }
                item.itemId >= 4001 -> {
                    val index = item.itemId - 4001
                    val tile = displayTiles.getOrNull(index)?.second ?: return@setOnMenuItemClickListener false
                    selectLiveCamera(tile.camera.id)
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    private fun updateLiveViewButton() {
        if (!::liveViewButton.isInitialized) return
        if (largeCameraLiveSelectMode || (tiles.size > 4 || highestAssignedSlot() >= 4)) {
            val selected = selectedLiveCameraId?.let { id ->
                val slot = tilesForFixedSlots().indexOfFirst { it?.camera?.id == id }
                if (slot >= 0) "CAM ${slot + 1}" else "OFF"
            } ?: "OFF"
            liveViewButton.text = "LIVE $selected ▼"
            liveViewButton.setTextColor(if (selectedLiveCameraId == null) 0xff8b8f94.toInt() else 0xff67e56f.toInt())
        } else {
            liveViewButton.text = if (liveViewAllEnabled) "LIVE ON" else "LIVE OFF"
            liveViewButton.setTextColor(if (liveViewAllEnabled) 0xff67e56f.toInt() else 0xff8b8f94.toInt())
        }
    }

    private fun assignCameraToSlot(slot: Int, cameraId: String) {
        if (slot !in slotAssignments.indices || !tiles.containsKey(cameraId)) return
        val existingSlot = slotAssignments.indexOf(cameraId)
        val displaced = slotAssignments[slot]
        if (existingSlot >= 0 && existingSlot != slot) {
            // Swap instead of compacting. Every position is a physical monitor slot:
            // 1 2
            // 3 4
            slotAssignments[existingSlot] = displaced
        }
        slotAssignments[slot] = cameraId
        activeCameraIdentities[cameraId]?.let { cameraSlotMemory.remember(slot, it) }
        saveCameraSlotMemory()
        updateLiveViewModeForCameraCount()
        gridLayoutMode = GridLayoutMode.forCameraCount(max(tiles.size, slot + 1))
        if (::layoutButton.isInitialized) layoutButton.text = gridLayoutMode.buttonLabel()
        rebuildGrid()
        Toast.makeText(this, "Camera assigned to fixed slot ${slot + 1}", Toast.LENGTH_SHORT).show()
    }

    private fun clearSlotAssignment(slot: Int) {
        if (slot !in slotAssignments.indices) return
        slotAssignments[slot] = null
        cameraSlotMemory.forget(slot)
        rememberDisplayedCameraSlots()
        if (slotAssignments.all { it == null }) {
            applyAutomaticLayoutForCameraCount(tiles.size)
        }
        rebuildGrid()
    }

    private fun resetAllSlotAssignments() {
        slotAssignments.fill(null)
        cameraSlotMemory.clear()
        rememberDisplayedCameraSlots()
        applyAutomaticLayoutForCameraCount(tiles.size)
        rebuildGrid()
        Toast.makeText(this, "All camera slots reset to Automatic", Toast.LENGTH_SHORT).show()
    }

    /**
     * Resolve physical monitor positions without compacting holes. Explicit
     * slot assignments remain stable from 1 through 20 cameras.
     */
    private fun tilesForFixedSlots(): List<CameraTileView?> {
        val result = arrayOfNulls<CameraTileView>(slotAssignments.size)
        val used = HashSet<String>()

        for (slot in slotAssignments.indices) {
            val id = slotAssignments[slot] ?: continue
            val tile = tiles[id] ?: continue
            if (used.add(id)) result[slot] = tile
        }

        // Cameras without an explicit valid assignment fill only truly empty slots.
        // Their placement is stable once addCamera() writes slotAssignments.
        for ((id, tile) in tiles) {
            if (!used.add(id)) continue
            val free = result.indices.firstOrNull { result[it] == null && !cameraSlotMemory.isReserved(it) }
                ?: result.indexOfFirst { it == null }
            if (free >= 0) result[free] = tile
        }
        return result.toList()
    }

    private fun highestAssignedSlot(): Int = slotAssignments.indexOfLast { it != null && tiles.containsKey(it) }

    private fun saveCameraSlotMemory() {
        getSharedPreferences("camera_fixed_slots", Context.MODE_PRIVATE).edit()
            .putString("placements", cameraSlotMemory.encode()).apply()
    }

    private fun rememberDisplayedCameraSlots() {
        tilesForFixedSlots().forEachIndexed { slot, tile ->
            if (tile != null) {
                slotAssignments[slot] = tile.camera.id
                val identity = activeCameraIdentities[tile.camera.id] ?: CameraIdentity.of(tile.camera)
                cameraSlotMemory.remember(slot, identity)
            }
        }
        saveCameraSlotMemory()
    }

    private fun findExistingCamera(identity: CameraIdentity): String? {
        val matches = activeCameraIdentities.entries.filter { (_, known) -> known.sameEndpoint(identity) }
        return matches.firstOrNull { (_, known) -> identity.mac.isNotBlank() && known.mac == identity.mac }?.key
            ?: matches.firstOrNull { (_, known) -> identity.serial.isNotBlank() && known.serial == identity.serial }?.key
            ?: matches.firstOrNull { (_, known) -> identity.ip.isNotBlank() && known.ip == identity.ip }?.key
            ?: matches.firstOrNull()?.key
    }

    private fun collapseDuplicateCameras(survivorId: String, identity: CameraIdentity) {
        val duplicates = activeCameraIdentities.filter { (id, known) -> id != survivorId && known.sameEndpoint(identity) }.keys.toList()
        duplicates.forEach { id ->
            sessions.remove(id)?.close()
            tiles.remove(id)
            remoteColumns.remove(id)
            activeCameraIdentities.remove(id)
            slotAssignments.indices.filter { slotAssignments[it] == id }.forEach { slot ->
                slotAssignments[slot] = null
                cameraSlotMemory.forget(slot)
            }
            if (selectedLiveCameraId == id) {
                selectedLiveCameraId = survivorId
                tiles[survivorId]?.setLiveViewEnabled(true)
                sessions[survivorId]?.setLiveViewEnabled(true)
            }
        }
        if (duplicates.isNotEmpty()) rebuildGrid()
    }

    private fun togglePhoneHotspot() {
        // Monitor & Control style Tethering (Wi-Fi): use Android's real Portable
        // Hotspot/Internet Sharing network. LocalOnlyHotspot is intentionally not
        // used here because it is a different SoftAP product and Android may not
        // expose it/rout it the same way as tethering.
        if (hotspotManager.isRunning()) hotspotManager.stop()
        showHotspotConfigurationDialog()
    }

    /**
     * The app owns exactly one hotspot profile. Editing this dialog replaces the
     * previous SSID/password; there is no profile list and no multi-hotspot state.
     */
    private fun showHotspotConfigurationDialog() {
        val current = hotspotConfigStore.load()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val note = TextView(this).apply {
            text = "Tethering (Wi-Fi), similar to Sony Monitor & Control, uses Android Portable Hotspot. " +
                "Save the SSID/password below, then Android Hotspot settings will open so you can apply them. " +
                "When you return, SCAN checks the actual tethering subnet, including 10.x.x.x ranges."
            setTextColor(0xff444444.toInt())
            textSize = 13f
            setPadding(0, 0, 0, dp(10))
        }
        val ssidInput = EditText(this).apply {
            hint = "Hotspot name (SSID)"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            setText(current.ssid)
            selectAll()
        }
        val passwordInput = EditText(this).apply {
            hint = "Password (8-63 characters)"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(current.password)
        }
        container.addView(note)
        container.addView(ssidInput)
        container.addView(passwordInput)

        val positiveText = "SAVE & OPEN TETHERING"

        val dialog = AlertDialog.Builder(this)
            .setTitle("Hotspot")
            .setView(container)
            .setPositiveButton(positiveText, null)
            .setNegativeButton("CANCEL", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val config = HotspotConfig(
                    ssid = ssidInput.text.toString().trim(),
                    password = passwordInput.text.toString()
                )
                val error = config.validate()
                if (error != null) {
                    Toast.makeText(this, error, Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }

                // Saving overwrites the one and only hotspot profile.
                hotspotConfigStore.save(config)
                dialog.dismiss()

                // Always use the system Portable Hotspot for MC-style
                // Tethering (Wi-Fi). Third-party apps cannot reliably rewrite
                // tethering SSID/password on all Android builds.
                showSystemHotspotApplyDialog(config)
            }
        }
        dialog.show()
    }

    private fun showSystemHotspotApplyDialog(config: HotspotConfig) {
        AlertDialog.Builder(this)
            .setTitle("Tethering (Wi-Fi)")
            .setMessage(
                "SSID: ${config.ssid}\n\n" +
                    "Password: ${config.password}\n\n" +
                    "Set these exact values in Android Portable Hotspot and enable it. " +
                    "Then set the camera to Tethering (Wi-Fi)/Access Point Set and join this network. " +
                    "When you return, the app scans all tethering interfaces/subnets, including 10.x.x.x."
            )
            .setPositiveButton("OPEN SETTINGS") { _, _ -> openSystemHotspotSettings() }
            .setNegativeButton("CLOSE", null)
            .show()
    }

    private fun openSystemHotspotSettings() {
        waitingForSystemHotspotReturn = true
        val tetherIntent = Intent("android.settings.TETHER_SETTINGS")
        val fallbackIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
        runCatching { startActivity(tetherIntent) }
            .recoverCatching { startActivity(fallbackIntent) }
            .onFailure {
                Toast.makeText(this, "Unable to open Hotspot settings on this device", Toast.LENGTH_LONG).show()
            }
    }

    private fun startPhoneHotspot(config: HotspotConfig = hotspotConfigStore.load()) {
        hotspotButton.isEnabled = false
        hotspotButton.text = "START..."
        hotspotManager.start(config, object : PhoneHotspotManager.Callback {
            override fun onStarted(info: PhoneHotspotManager.HotspotInfo) {
                val saved = hotspotConfigStore.load()
                val exactMatch = info.customConfigurationApplied &&
                    info.ssid == saved.ssid && info.password == saved.password
                if (!exactMatch) {
                    // Never keep a framework-generated AndroidShare_xxxx hotspot when
                    // the user requested a specific SSID/password.
                    hotspotManager.stop()
                    systemHotspotMode = false
                    connectionMode = ConnectionMode.CAMERA_WIFI
                    updateHotspotButton()
                    showCustomHotspotUnavailableDialog(saved, info)
                    return
                }
                systemHotspotMode = false
                connectionMode = ConnectionMode.PHONE_HOTSPOT
                updateHotspotButton()
                startHotspotAutoDiscovery()
                showHotspotReadyDialog(info)
            }

            override fun onStopped() {
                hotspotAutoDiscovery.stop()
                connectionMode = ConnectionMode.CAMERA_WIFI
                updateHotspotButton()
            }

            override fun onFailed(reason: String) {
                connectionMode = ConnectionMode.CAMERA_WIFI
                updateHotspotButton()
            }
        })
    }

    private fun updateHotspotButton() {
        runOnUiThread {
            hotspotButton.isEnabled = true
            hotspotButton.text = when {
                hotspotManager.isRunning() -> "HOT ON"
                systemHotspotMode -> "TETHER ON"
                else -> "TETHER"
            }
        }
    }

    private fun showHotspotReadyDialog(info: PhoneHotspotManager.HotspotInfo) {
        val passwordText = if (info.password.isBlank()) "(no password)" else info.password
        val saved = hotspotConfigStore.load()
        val exactMatch = info.ssid == saved.ssid && info.password == saved.password
        val modeText = if (exactMatch && info.customConfigurationApplied) {
            "Android applied the requested SSID/password."
        } else {
            "Android returned hotspot credentials that differ from the saved configuration. Check system Hotspot settings."
        }
        AlertDialog.Builder(this)
            .setTitle("Phone Hotspot Ready")
            .setMessage(
                "SSID: ${info.ssid}\n\nPassword: $passwordText\n\n$modeText\n\n" +
                    "On the Sony camera: Network/Wi-Fi -> Access Point Set -> select the SSID above. " +
                    "After the camera receives an IP address, the app discovers and connects automatically. SCAN CAMERA is only a manual retry."
            )
            .setPositiveButton("SCAN CAMERA") { _, _ -> scan() }
            .setNeutralButton("EDIT SSID/PASSWORD") { _, _ ->
                hotspotAutoDiscovery.stop()
                hotspotManager.stop()
                connectionMode = ConnectionMode.CAMERA_WIFI
                updateHotspotButton()
                showHotspotConfigurationDialog()
            }
            .setNegativeButton("STOP HOTSPOT") { _, _ ->
                hotspotAutoDiscovery.stop()
                hotspotManager.stop()
                connectionMode = ConnectionMode.CAMERA_WIFI
                updateHotspotButton()
            }
            .show()
    }

    private fun showCustomHotspotUnavailableDialog(
        requested: HotspotConfig,
        actual: PhoneHotspotManager.HotspotInfo
    ) {
        AlertDialog.Builder(this)
            .setTitle("Android did not apply the SSID/password")
            .setMessage(
                "Requested by app:\nSSID: ${requested.ssid}\nPassword: ${requested.password}\n\n" +
                    "Android created: ${actual.ssid}. That generated hotspot has been stopped.\n\n" +
                    "Use system Hotspot settings to apply the requested SSID/password. When you return, camera discovery starts automatically."
            )
            .setPositiveButton("OPEN SYSTEM HOTSPOT") { _, _ -> openSystemHotspotSettings() }
            .setNegativeButton("CLOSE", null)
            .show()
    }

    private fun startHotspotAutoDiscovery() {
        if (hotspotAutoDiscovery.isRunning()) return
        val activeIds = sessions.filterValues { it.hasActiveTransport() || it.isConnecting() }.keys
        val hosts = activeIds.mapNotNull { activeCameraIdentities[it]?.ip?.takeIf(String::isNotBlank) }.toSet()
        val macs = activeIds.mapNotNull { activeCameraIdentities[it]?.mac?.takeIf(String::isNotBlank) }.toSet()
        hotspotAutoDiscovery.start(maxCameras, object : HotspotCameraAutoDiscovery.Callback {
            override fun onSearching(attempt: Int) = Unit

            override fun onCamera(camera: SonyCamera) {
                runOnUiThread { addCamera(camera) }
            }

            override fun onCycleFinished(attempt: Int, foundThisCycle: Int, subnet: String) = Unit

            override fun onError(message: String) = Unit
        }, excludeHosts = hosts, excludeMacs = macs)
    }

    private fun registerUsbReceiver() {
        val filter = IntentFilter().apply {
            addAction(ACTION_USB_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(usbReceiver, filter)
        }
    }

    @Suppress("DEPRECATION")
    private fun usbDeviceFromIntent(intent: Intent): UsbDevice? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE) as? UsbDevice
        }
    }

    private fun requestOrConnectUsbDevice(device: UsbDevice) {
        if (device.vendorId != SONY_VENDOR_ID || !SonyUsbCameraDiscovery.hasPtpInterface(device)) return
        val alreadyPresent = tiles.values.any { tile ->
            tile.camera.transport == CameraTransport.USB_PTP &&
                (tile.camera.usbDeviceName == device.deviceName || tile.camera.usbDeviceId == device.deviceId)
        }
        if (alreadyPresent) return
        if (usbManager.hasPermission(device)) {
            connectUsbDevice(device)
            return
        }
        val permissionIntent = Intent(ACTION_USB_PERMISSION).setPackage(packageName)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val pendingIntent = PendingIntent.getBroadcast(this, device.deviceId, permissionIntent, flags)
        usbManager.requestPermission(device, pendingIntent)
    }

    private fun connectUsbDevice(device: UsbDevice) {
        if (!usbManager.hasPermission(device)) return
        if (device.vendorId != SONY_VENDOR_ID || !SonyUsbCameraDiscovery.hasPtpInterface(device)) return
        val alreadyPresent = tiles.values.any { tile ->
            tile.camera.transport == CameraTransport.USB_PTP &&
                (tile.camera.usbDeviceName == device.deviceName || tile.camera.usbDeviceId == device.deviceId)
        }
        if (alreadyPresent || tiles.size >= maxCameras) return
        addCamera(SonyUsbCameraDiscovery.toSonyCamera(this, device))
    }

    private fun removeUsbCamera(device: UsbDevice) {
        val ids = tiles.entries
            .filter { (_, tile) ->
                tile.camera.transport == CameraTransport.USB_PTP &&
                    (tile.camera.usbDeviceName == device.deviceName || tile.camera.usbDeviceId == device.deviceId)
            }
            .map { it.key }
        if (ids.isEmpty()) return
        ids.forEach { id ->
            sessions.remove(id)?.close()
            tiles.remove(id)
            activeCameraIdentities.remove(id)
            remoteColumns.remove(id)
            for (slot in slotAssignments.indices) {
                if (slotAssignments[slot] == id) slotAssignments[slot] = null
            }
            if (selectedLiveCameraId == id) selectedLiveCameraId = null
        }
        updateLiveViewButton()
        rebuildGrid()
        updateGlobalSettingUi()
        Toast.makeText(this, "USB camera disconnected", Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != HotspotPermissionHelper.REQUEST_CODE) return
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        if (granted) {
            startPhoneHotspot(hotspotConfigStore.load())
        } else {
            Toast.makeText(this, "Wi-Fi/Nearby permission is required for Phone Hotspot", Toast.LENGTH_LONG).show()
        }
    }

    private fun scan() {
        if (scanning) return
        scanning = true
        scanButton.isEnabled = false

        // Capture active endpoints on the UI thread. SCAN adds discoveries;
        // it must not interrupt existing video, REC, LIVE selection or slot memory.
        val connectedIds = sessions.filterValues { it.hasActiveTransport() || it.isConnecting() }.keys
        val excludedHosts = connectedIds.mapNotNull { activeCameraIdentities[it]?.ip?.takeIf(String::isNotBlank) }.toSet()
        val excludedMacs = connectedIds.mapNotNull { activeCameraIdentities[it]?.mac?.takeIf(String::isNotBlank) }.toSet()
        val knownUsbPaths = connectedIds.mapNotNull { activeCameraIdentities[it]?.usbPath?.takeIf(String::isNotBlank) }.toSet()
        val existingCount = tiles.size
        val remaining = (maxCameras - existingCount).coerceAtLeast(0)
        if (remaining == 0) {
            scanning = false
            scanButton.isEnabled = true
            Toast.makeText(this, "All $maxCameras camera slots are occupied", Toast.LENGTH_SHORT).show()
            return
        }

        networkExecutor.execute {
            try {
                val usbDevices = SonyUsbCameraDiscovery.findSonyPtpDevices(this).filter { it.deviceName !in knownUsbPaths }
                val result = SonyPtpDiscovery(this).discover(maxCameras = remaining,
                    excludeHosts = excludedHosts, excludeMacs = excludedMacs)
                val candidateCount = (existingCount + usbDevices.size + result.cameras.size).coerceAtMost(maxCameras)
                if (candidateCount > 4) {
                    // Pre-arm CONTROL ONLY before the first camera session starts so
                    // a mixed Wi-Fi/USB fleet never briefly opens >4 JPEG streams.
                    runOnUiThread {
                        enterLargeCameraLiveSelectMode(showToast = false)
                        updateLiveViewButton()
                    }
                }

                runOnUiThread {
                    usbDevices.forEach { requestOrConnectUsbDevice(it) }
                }

                var usable = (existingCount + usbDevices.size).coerceAtMost(maxCameras)
                result.cameras.forEach { camera ->
                    if (!scanning || usable >= maxCameras) return@forEach
                    usable++
                    runOnUiThread { reconcileDiscoveredCamera(camera) }
                }
            } catch (_: Throwable) {
            } finally {
                scanning = false
                runOnUiThread { scanButton.isEnabled = true }
            }
        }
    }

    private fun showAddIpDialog() {
        val input = EditText(this).apply {
            hint = "Camera IP, e.g. 192.168.1.50"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Add Sony camera by IP")
            .setMessage("The app will try Sony unicast SSDP and Sony DD XML, then connect only by PTP/IP :15740.")
            .setView(input)
            .setPositiveButton("CONNECT") { _, _ ->
                val host = normalizeHost(input.text.toString())
                if (host.isBlank()) {
                    Toast.makeText(this, "Invalid IP/hostname", Toast.LENGTH_SHORT).show()
                } else {
                    addCameraByIp(host)
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun addCameraByIp(host: String) {
        networkExecutor.execute {
            val wifi = SonyNetworkRoute.findWifiNetworkForHost(this, host)
            val directDiscovery = SsdpDiscovery(this)
            val directLocations = runCatching { directDiscovery.discoverHost(host) }.getOrDefault(emptyList())
            var detectedCamera: SonyCamera? = null
            for (location in directLocations) {
                val candidate = runCatching { SonyDeviceDescription.fetch(location, wifi) }.getOrNull()
                if (candidate != null) {
                    detectedCamera = candidate
                    break
                }
            }
            if (detectedCamera == null) {
                detectedCamera = runCatching { SonyDeviceDescription.fetchByHost(host, wifi) }.getOrNull()
            }
            val camera = detectedCamera ?: SonyCamera.manual(host)
            runOnUiThread { addCamera(camera) }
        }
    }

    private fun normalizeHost(raw: String): String {
        var v = raw.trim()
        v = v.removePrefix("http://").removePrefix("https://")
        v = v.substringBefore('/').substringBefore(':').trim()
        return v.takeIf { it.matches(Regex("[A-Za-z0-9._-]+")) }.orEmpty()
    }

    private fun addCamera(incomingCamera: SonyCamera, preferredSlot: Int? = null) {
        val incomingIdentity = CameraIdentity.of(incomingCamera)
        val existingId = findExistingCamera(incomingIdentity)
        if (existingId != null) {
            val known = activeCameraIdentities.getValue(existingId)
            val changedBody = (known.mac.isNotBlank() && incomingIdentity.mac.isNotBlank() && known.mac != incomingIdentity.mac) ||
                (known.serial.isNotBlank() && incomingIdentity.serial.isNotBlank() && known.serial != incomingIdentity.serial)
            if (changedBody || (known.transport == CameraTransport.PTP_IP && known.ip != incomingIdentity.ip)) {
                if (!changedBody) collapseDuplicateCameras(existingId, known.enrichedBy(incomingIdentity))
                replaceDisconnectedCamera(existingId, incomingCamera, allowActive = true)
                return
            }
            val merged = known.enrichedBy(incomingIdentity)
            collapseDuplicateCameras(existingId, merged)
            activeCameraIdentities[existingId] = merged
            val slot = slotAssignments.indexOf(existingId)
            if (slot >= 0) cameraSlotMemory.remember(slot, merged)
            saveCameraSlotMemory()
            android.util.Log.i("SonyMultiLive", "Duplicate camera ignored: IP=${incomingIdentity.ip} MAC=${incomingIdentity.mac} existing=$existingId")
            return
        }
        // Some discovery services reuse a UDN for different bodies. Keep both
        // genuine endpoints without letting that shared ID overwrite a session.
        val camera = if (sessions.containsKey(incomingCamera.id) || tiles.containsKey(incomingCamera.id)) {
            incomingCamera.copy(id = incomingCamera.id + "@" + incomingIdentity.ip.ifBlank { incomingIdentity.usbPath })
        } else incomingCamera
        if (sessions.containsKey(camera.id) || tiles.containsKey(camera.id)) return
        if (tiles.size >= maxCameras) return
        val identity = incomingIdentity.copy(id = camera.id)
        activeCameraIdentities[camera.id] = identity
        val savedSlot = cameraSlotMemory.find(identity).takeIf { it >= 0 && slotAssignments[it] == null }
        val requestedSlot = preferredSlot?.takeIf { it in slotAssignments.indices && slotAssignments[it] == null }
            ?: savedSlot
            ?: slotAssignments.indices.firstOrNull { slotAssignments[it] == null && !cameraSlotMemory.isReserved(it) }
            ?: slotAssignments.indexOfFirst { it == null }.takeIf { it >= 0 }
        if (requestedSlot != null) {
            slotAssignments[requestedSlot] = camera.id
            cameraSlotMemory.remember(requestedSlot, identity)
            saveCameraSlotMemory()
        }

        val tile = CameraTileView(this, camera, decodeExecutor).also {
            tiles[camera.id] = it
            it.setFalseColorMode(falseColorMode)
            it.setHistogramVisible(histogramVisible)
        }
        val remoteColumn = RemoteCameraSettingColumnView(this, camera).also {
            remoteColumns[camera.id] = it
            it.setControlsLocked(globalHold)
        }
        applyAutomaticLayoutForCameraCount(tiles.size)
        updateLiveViewModeForCameraCount()
        rebuildGrid()

        val session = SonyCameraSession(
            context = this,
            camera = camera,
            executor = networkExecutor,
            onJpeg = { jpeg -> tile.offerJpeg(jpeg) },
            onState = { raw ->
                tile.setState(raw)
                remoteColumn.setState(raw)
            },
            onStats = {},
            onTelemetry = { telemetry ->
                tile.setTelemetry(telemetry)
                remoteColumn.setTelemetry(telemetry)
                window.decorView.post {
                    updateGlobalRecordUi()
                    updateGlobalSettingUi()
                }
            },
            onDeviceName = {
                tile.refreshCameraIdentity()
                remoteColumn.refreshCameraIdentity()
            },
            onNeedsAuth = { tile.setAuthRequired(true) }
        )
        val profile = currentProfile(tiles.size.coerceAtLeast(1))
        tile.setRenderResolution(renderWidth, renderHeight)
        tile.setOnFocusTapListener { x, y -> session.setTouchFocus(x, y) { ok -> tile.setFocusResult(ok) } }
        // Double-tap clears the local marker immediately and sends Sony's dedicated
        // Cancel Remote Touch Operation command (D2E5). No AF half-press is used.
        tile.setOnFocusClearListener { session.cancelTouchFocus() }
        // Touch focus remains per-camera; the old round AF button is removed.
        tile.setOnSettingsTapListener { showCameraControls(camera, session, tile) }
        tile.setOnSettingTapListener { key, anchor -> showSettingWheel(anchor, session, key) }
        tile.setOnSettingScrollListener(null)
        remoteColumn.setOnSettingsTapListener { showCameraControls(camera, session, tile) }
        remoteColumn.setOnSettingTapListener { key, anchor -> showSettingWheel(anchor, session, key) }
        // The custom 2-second frame hold replaces Android's short long-click.
        tile.isLongClickable = false
        session.setLiveViewProfile(profile)
        val liveEnabled = shouldCameraUseLiveView(camera.id)
        tile.setLiveViewEnabled(liveEnabled)
        session.setLiveViewEnabled(liveEnabled)
        sessions[camera.id] = session
        tile.setControlsLocked(globalHold)
        tile.setOsdVisible(osdVisible)
        tile.setPlaybackMode(false, false)
        session.start()
        updateGlobalRecordUi()
        updateGlobalSettingUi()
        window.decorView.postDelayed({ updateGlobalSettingUi() }, 900L)
        rebuildGrid()
    }

    private fun onCameraNetworkChanged() {
        // Clear cached route from the previous SSID and give Android a moment to publish
        // LinkProperties for the new DIRECT-* / normal Wi-Fi network.
        SonyNetworkRoute.clearProcessBinding(this)
        window.decorView.postDelayed({
            reconnectDisconnectedSessions(forceDiscovery = true)
        }, 900L)
    }

    private fun checkCameraReconnects() {
        if (isFinishing || isDestroyed) return
        val anyDisconnected = tiles.any { (id, tile) ->
            val session = sessions[id]
            session != null && !session.isConnecting() && !session.isPlaybackRequested() && session.isLiveViewEnabled() && tile.isStreamDisconnected(12_000L)
        }
        if (anyDisconnected) reconnectDisconnectedSessions(forceDiscovery = false)
    }

    private fun reconnectDisconnectedSessions(forceDiscovery: Boolean) {
        val now = SystemClock.elapsedRealtime()

        // Retry the existing PTP endpoint first. A short JPEG gap must never tear
        // down a healthy Sony command/event session.
        if (!forceDiscovery && now - lastDirectReconnectAttemptMs < 12_000L) return
        lastDirectReconnectAttemptMs = now

        var hasDisconnectedCamera = false
        tiles.forEach { (id, tile) ->
            val session = sessions[id] ?: return@forEach
            if (session.isPlaybackRequested() || session.isConnecting()) return@forEach
            val disconnected = session.isLiveViewEnabled() && tile.isStreamDisconnected(12_000L)
            if (disconnected || (forceDiscovery && tile.camera.transport == CameraTransport.PTP_IP)) {
                hasDisconnectedCamera = hasDisconnectedCamera || disconnected
                session.retryDirectPtp()
            }
        }

        // Do not run a subnet scan at the same time as the direct PTP recovery.
        if (!hasDisconnectedCamera && !forceDiscovery) return
        if (reconnectDiscoveryPending) return
        if (!forceDiscovery && now - lastReconnectAttemptMs < 30_000L) return

        reconnectDiscoveryPending = true
        window.decorView.postDelayed({
            reconnectDiscoveryPending = false
            if (isFinishing || isDestroyed || scanning || reconnectScanning) return@postDelayed

            val stillDisconnected = tiles.any { (id, tile) ->
                val session = sessions[id]
                session != null && !session.isConnecting() && !session.isPlaybackRequested() &&
                    session.isLiveViewEnabled() &&
                    tile.isStreamDisconnected(12_000L)
            }
            if (!stillDisconnected) return@postDelayed

            val scanNow = SystemClock.elapsedRealtime()
            if (!forceDiscovery && scanNow - lastReconnectAttemptMs < 30_000L) return@postDelayed
            lastReconnectAttemptMs = scanNow
            if (reconnectScanning || scanning) return@postDelayed

            val connected = sessions.filterValues { it.hasActiveTransport() || it.isConnecting() }.keys
            val excludeHosts = connected.mapNotNull { activeCameraIdentities[it]?.ip?.takeIf(String::isNotBlank) }.toSet()
            val excludeMacs = connected.mapNotNull { activeCameraIdentities[it]?.mac?.takeIf(String::isNotBlank) }.toSet()
            reconnectScanning = true
            networkExecutor.execute {
                try {
                    val result = SonyPtpDiscovery(this).discover(
                        maxCameras = maxCameras,
                        ssdpTimeoutMs = 700L,
                        connectTimeoutMs = 90,
                        includeSubnetScan = forceDiscovery,
                        excludeHosts = excludeHosts, excludeMacs = excludeMacs
                    )
                    result.cameras.forEach { discovered ->
                        runOnUiThread { reconcileDiscoveredCamera(discovered) }
                    }
                } catch (_: Throwable) {
                    // Keep current tiles; a later recovery pass can retry.
                } finally {
                    reconnectScanning = false
                }
            }
        }, if (forceDiscovery) 2_500L else 3_500L)
    }

    private fun reconcileDiscoveredCamera(discovered: SonyCamera) {
        val existingId = findExistingCamera(CameraIdentity.of(discovered))
        if (existingId != null) {
            if (sessions[existingId]?.isPlaybackRequested() == true) return
            addCamera(discovered) // Enrich aliases, or replace changed endpoint in the same slot.
            val tile = tiles[existingId]
            val session = sessions[existingId]
            if (tile != null && session != null && !session.isConnecting() &&
                session.isLiveViewEnabled() && tile.isStreamDisconnected(4_500L)) {
                session.retryDirectPtp()
            }
            return
        }
        // Never identify a camera by model/friendly name alone.
        addCamera(discovered)
    }

    private fun replaceDisconnectedCamera(oldId: String, discovered: SonyCamera, allowActive: Boolean = false) {
        val oldTile = tiles[oldId] ?: return
        if (!allowActive && !oldTile.isStreamDisconnected(4_500L)) return
        val slot = slotAssignments.indexOf(oldId)
        val known = activeCameraIdentities[oldId]
        val observed = CameraIdentity.of(discovered)
        val sameBody = known == null || !((known.mac.isNotBlank() && observed.mac.isNotBlank() && known.mac != observed.mac) ||
            (known.serial.isNotBlank() && observed.serial.isNotBlank() && known.serial != observed.serial))
        val replacement = discovered.copy(
            macAddress = discovered.macAddress.ifBlank { if (sameBody) known?.mac.orEmpty() else "" },
            serialNumber = discovered.serialNumber.ifBlank { if (sameBody) known?.serial.orEmpty() else "" }
        )
        val wasSelectedForLive = selectedLiveCameraId == oldId
        sessions.remove(oldId)?.close()
        tiles.remove(oldId)
        activeCameraIdentities.remove(oldId)
        remoteColumns.remove(oldId)
        if (slot >= 0) slotAssignments[slot] = null
        if (wasSelectedForLive) selectedLiveCameraId = null
        addCamera(replacement, preferredSlot = slot.takeIf { it >= 0 })
        if (wasSelectedForLive) selectLiveCamera(findExistingCamera(CameraIdentity.of(replacement)))
        rebuildGrid()
    }

    private fun toggleAllCameraRecording() {
        if (sessions.isEmpty()) {
            Toast.makeText(this, "No cameras connected", Toast.LENGTH_SHORT).show()
            return
        }

        // Keep command intent for REC/STOP toggling; each frame follows camera telemetry.
        val currentIntent = if (globalRecordCommandKnown) globalRecordRequested else false
        val shouldRecord = !currentIntent
        globalRecordCommandKnown = true
        globalRecordRequested = shouldRecord

        // Give every camera worker the same future monotonic barrier. Each PTP
        // session waits locally, then presses Sony REC as close to this instant
        // as its current GetObject transaction allows.
        val targetElapsedNs = SystemClock.elapsedRealtimeNanos() + 350_000_000L
        if (shouldRecord) {
            globalRecordTakeCounter = (globalRecordTakeCounter + 1).coerceAtLeast(1)
        }
        val take = globalRecordTakeCounter.coerceAtLeast(1)
        sessions.values.forEach { it.setMovieRecordingAt(shouldRecord, targetElapsedNs, take) }
        updateGlobalRecordUi()

        Toast.makeText(
            this,
            if (shouldRecord) String.format(java.util.Locale.US, "REC · R%02d", take) else "STOP",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun updateGlobalRecordUi() {
        if (!::globalRecordButton.isInitialized) return
        if (sessions.values.any { it.isPlaybackRequested() }) {
            if (::globalPlaybackButton.isInitialized) refreshPlaybackTransportUi()
            return
        }

        val active = sessions.values.any { it.isMovieRecording() }

        globalRecordButton.isEnabled = true
        globalRecordButton.alpha = 1f
        globalRecordButton.text = "REC"
        globalRecordButton.setTextColor(Color.WHITE)

        if (active) startGlobalRecordBlink() else stopGlobalRecordBlink()
    }

    private fun startGlobalRecordBlink() {
        if (!::globalRecordButton.isInitialized) return
        if (!globalRecordBlinkRunning) {
            globalRecordBlinkRunning = true
            globalRecordBlinkPhase = true
            applyGlobalRecordButtonStyle(recording = true, bright = true)
            globalRecordButton.removeCallbacks(globalRecordBlinkRunnable)
            globalRecordButton.postDelayed(globalRecordBlinkRunnable, 450L)
        } else {
            applyGlobalRecordButtonStyle(recording = true, bright = globalRecordBlinkPhase)
        }
    }

    private fun stopGlobalRecordBlink() {
        if (!::globalRecordButton.isInitialized) return
        globalRecordButton.removeCallbacks(globalRecordBlinkRunnable)
        globalRecordBlinkRunning = false
        globalRecordBlinkPhase = false
        if (sessions.values.none { it.isPlaybackRequested() }) {
            applyGlobalRecordButtonStyle(recording = false, bright = false)
        }
    }

    private fun applyGlobalRecordButtonStyle(recording: Boolean, bright: Boolean) {
        if (!::globalRecordButton.isInitialized) return
        globalRecordButton.background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.OVAL
            // The REC face is always red. At rest the ring is green. During REC
            // only the ring blinks red, so the operator never loses the familiar
            // red REC button while still getting an unambiguous recording flash.
            setColor(0xffd91625.toInt())
            if (recording) {
                setStroke(
                    dp(if (bright) 4 else 2),
                    if (bright) 0xffff3045.toInt() else 0x00ff3045
                )
            } else {
                setStroke(dp(2), 0xff36e06f.toInt())
            }
        }
    }

    private fun setGlobalHold(locked: Boolean) {
        globalHold = locked
        tiles.values.forEach { it.setControlsLocked(locked) }
        remoteColumns.values.forEach { it.setControlsLocked(locked) }
        if (::globalHoldButton.isInitialized) {
            globalHoldButton.text = if (locked) "HOLD  ●" else "HOLD  ○"
            globalHoldButton.setTextColor(if (locked) 0xffffdf54.toInt() else Color.WHITE)
        }
        updateGlobalSettingUi()
    }

    private fun showCameraControls(camera: SonyCamera, session: SonyCameraSession, tile: CameraTileView) {
        val telemetry = session.currentTelemetry()
        val displaySlot = tilesForFixedSlots().indexOfFirst { it?.camera?.id == camera.id }
            .takeIf { it >= 0 }
            ?.plus(1)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xff0a0c0f.toInt())
                cornerRadius = dp(4).toFloat()
            }
        }

        panel.addView(TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = UiFonts.MEDIUM
            includeFontPadding = false
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xff171a1f.toInt())
                setStroke(dp(1), 0xff4a4f56.toInt())
                cornerRadius = dp(3).toFloat()
            }
            text = buildString {
                append("CAMERA STATUS")
                if (displaySlot != null) append(" · CAM ").append(displaySlot)
                append("\n").append(tile.friendlyState())
            }
        })

        panel.addView(TextView(this).apply {
            setTextColor(0xffc7ccd2.toInt())
            textSize = 10.5f
            typeface = UiFonts.REGULAR
            includeFontPadding = false
            setLineSpacing(0f, 1.08f)
            setPadding(dp(2), dp(10), dp(2), dp(5))
            text = buildString {
                val name = camera.displayName
                append("Device Name: ").append(name)
                if (camera.friendlyName.isNotBlank() && camera.friendlyName != name && camera.friendlyName != camera.modelName) {
                    append("\nDiscovery Name: ").append(camera.friendlyName)
                }
                if (camera.modelName.isNotBlank() && camera.modelName != name) append("\nModel: ").append(camera.modelName)
                if (camera.manufacturer.isNotBlank()) append("\nManufacturer: ").append(camera.manufacturer)
                if (camera.transport == CameraTransport.USB_PTP) {
                    append("\nConnection: USB PTP")
                    append(" · VID:PID ")
                    append(String.format(java.util.Locale.US, "%04X:%04X", camera.usbVendorId, camera.usbProductId))
                } else {
                    append("\nIP: ").append(camera.host).append(" · PTP 15740")
                }
                if (camera.macAddress.isNotBlank()) append("\nMAC: ").append(camera.macAddress)
                if (camera.firmwareVersion.isNotBlank()) append("\nFirmware: ").append(camera.firmwareVersion)
                if (camera.serialNumber.isNotBlank()) append("\nSerial: ").append(camera.serialNumber)
                if (camera.serialVersion.isNotBlank()) append("\nSerialVersion: ").append(camera.serialVersion)
                if (camera.function.isNotBlank()) append("\nFunction: ").append(camera.function)
                if (camera.serverType.isNotBlank()) append("\nServer: ").append(camera.serverType)
                if (camera.ptpVersion.isNotBlank()) append("\nPTP version: ").append(camera.ptpVersion)
                if (camera.ptpPairingNecessity.isNotBlank()) append(" · Pairing: ").append(camera.ptpPairingNecessity)
                append("\nPTP remote: ")
                    .append(if (camera.ptpRemoteControlAdvertised) "advertised" else "not advertised")
                    .append(" · ")
                    .append(if (camera.ptpRemoteControlEnabled) "enabled" else "disabled")
                session.cameraPtpInfoSummary().takeIf { it.isNotBlank() }?.let {
                    append("\nPTP DeviceInfo: ").append(it)
                }
                append("\nMode: ").append(
                    when {
                        session.isPlaybackRequested() -> "PLAYBACK"
                        shouldCameraUseLiveView(camera.id) -> "LIVE VIEW + REMOTE"
                        else -> "REMOTE CONTROL ONLY"
                    }
                )
            }
        })

        panel.addView(TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 10.5f
            typeface = UiFonts.MEDIUM
            includeFontPadding = false
            setPadding(dp(2), dp(9), dp(2), dp(4))
            text = "CAMERA MEDIA / RECORD"
        })
        panel.addView(TextView(this).apply {
            setTextColor(0xffc7ccd2.toInt())
            textSize = 10.5f
            typeface = UiFonts.REGULAR
            includeFontPadding = false
            setLineSpacing(0f, 1.08f)
            setPadding(dp(2), 0, dp(2), dp(5))
            text = buildString {
                append("Recording: ").append(if (telemetry.recording) "REC" else "STOP")
                append(" · FPS: ").append(telemetry.recordFrameRate)
                append("\nBattery: ").append(telemetry.batteryPercent?.let { "$it%" } ?: "--")
                append(" · Card: ").append(telemetry.cardRemainingSeconds?.let(::formatCardRemainingForInfo) ?: "--")
                if (telemetry.storageLabel.isNotBlank()) append("\nStorage: ").append(telemetry.storageLabel)
                telemetry.storageFreeBytes?.let { free ->
                    append(" · Free ").append(formatBytesForInfo(free))
                }
                telemetry.storageCapacityBytes?.let { capacity ->
                    append(" / ").append(formatBytesForInfo(capacity))
                }
            }
        })

        val cachedSettings = session.cameraSettingDescriptors()
        panel.addView(TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 10.5f
            typeface = UiFonts.MEDIUM
            includeFontPadding = false
            setPadding(dp(2), dp(9), dp(2), dp(4))
            text = "CAMERA SETTINGS"
        })
        panel.addView(TextView(this).apply {
            setTextColor(0xffc7ccd2.toInt())
            textSize = 10f
            typeface = UiFonts.REGULAR
            includeFontPadding = false
            setLineSpacing(0f, 1.06f)
            setPadding(dp(2), 0, dp(2), dp(5))
            text = if (cachedSettings.isEmpty()) {
                "Camera setting cache is not ready."
            } else {
                cachedSettings.joinToString("\n") { descriptor ->
                    "${descriptor.title}: ${descriptor.currentLabel}"
                }
            }
        })

        val scroll = android.widget.ScrollView(this).apply {
            setBackgroundColor(0xff0a0c0f.toInt())
            isFillViewport = true
            addView(panel)
        }

        AlertDialog.Builder(this)
            .setTitle(camera.displayName)
            .setView(scroll)
            .setPositiveButton("CLOSE", null)
            .create()
            .apply {
                setCanceledOnTouchOutside(true)
                setOnShowListener {
                    window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0xff101216.toInt()))
                    getButton(AlertDialog.BUTTON_POSITIVE)?.apply {
                        setTextColor(0xff55e6d0.toInt())
                        typeface = UiFonts.MEDIUM
                    }
                }
                show()
            }
    }

    private fun formatCardRemainingForInfo(seconds: Long): String {
        val totalMinutes = (seconds.coerceAtLeast(0L) + 30L) / 60L
        val hours = totalMinutes / 60L
        val minutes = totalMinutes % 60L
        return if (hours > 0L) String.format(java.util.Locale.US, "%dh%02dm", hours, minutes)
        else String.format(java.util.Locale.US, "%dm", minutes)
    }

    private fun formatBytesForInfo(bytes: Long): String {
        val value = bytes.coerceAtLeast(0L).toDouble()
        val gb = value / (1024.0 * 1024.0 * 1024.0)
        return if (gb >= 1.0) String.format(java.util.Locale.US, "%.1f GB", gb)
        else String.format(java.util.Locale.US, "%.0f MB", value / (1024.0 * 1024.0))
    }

    private fun darkPopupMenu(anchor: View): PopupMenu =
        PopupMenu(android.view.ContextThemeWrapper(this, R.style.DarkPopupTheme), anchor)

    private fun globalSettingShortTitle(key: CameraSettingKey): String = when (key) {
        CameraSettingKey.FOCUS_MODE -> "FOCUS"
        CameraSettingKey.IRIS -> "IRIS"
        CameraSettingKey.ISO -> "ISO"
        CameraSettingKey.SHUTTER -> "SHUTTER"
        CameraSettingKey.EXPOSURE_COMPENSATION -> "EV"
        CameraSettingKey.WHITE_BALANCE -> "WB"
        CameraSettingKey.LOOK -> "LOOK"
        CameraSettingKey.RECORD_FRAME_RATE -> "FPS"
    }

    private fun globalSettingDisplayValue(key: CameraSettingKey, raw: String): String = when (key) {
        CameraSettingKey.ISO -> raw.removePrefix("ISO ").removePrefix("EI ")
        CameraSettingKey.IRIS -> raw.removePrefix("IRIS ")
        CameraSettingKey.SHUTTER -> raw.removePrefix("SHUTTER ")
        CameraSettingKey.WHITE_BALANCE -> raw.removePrefix("WB ")
        CameraSettingKey.LOOK -> raw.removePrefix("LOOK ")
        else -> raw
    }

    /**
     * Footer setting values are cache-only. This function never asks a camera for
     * a fresh property while Live View is streaming, so it cannot disturb FFFFC002.
     */
    private fun updateGlobalSettingUi() {
        if (globalSettingButtons.isEmpty()) return
        globalSettingButtons.forEach { (key, view) ->
            val descriptors = sessions.values.mapNotNull { session ->
                session.cameraSettingDescriptors().firstOrNull { it.key == key }
            }
            val rawValues = if (key == CameraSettingKey.EXPOSURE_COMPENSATION) {
                // In Manual exposure the monitor EV is Sony D1B5 MeteredManualLevel,
                // not the writable 0x5010 exposure-bias value. Mirror the tile EV here.
                sessions.values.map { it.currentTelemetry().exposureCompensation }
            } else {
                descriptors.map { it.currentLabel }
            }
            val values = rawValues
                .filter { it.isNotBlank() && it != "--" }
                .map { globalSettingDisplayValue(key, it) }
                .distinct()
            val value = when {
                values.isEmpty() -> "--"
                values.size == 1 -> values.first()
                else -> "MIX"
            }
            view.text = "${globalSettingShortTitle(key)}\n$value"
            if (key == CameraSettingKey.EXPOSURE_COMPENSATION) {
                val active = sessions.values.any { it.isExposureCompensationAdjustable() }
                view.isEnabled = active && !globalHold
                view.isClickable = active && !globalHold
                view.isFocusable = active && !globalHold
                view.alpha = if (globalHold || !active) 0.42f else 1f
            } else {
                val writable = descriptors.any { it.writable } ||
                    (key == CameraSettingKey.WHITE_BALANCE && descriptors.isNotEmpty())
                view.isEnabled = writable && !globalHold
                view.isClickable = writable && !globalHold
                view.isFocusable = writable && !globalHold
                view.alpha = when {
                    globalHold -> 0.42f
                    writable -> 1f
                    else -> 0.42f
                }
            }
        }
    }

    private fun showGlobalSettingWheel(anchor: View, key: CameraSettingKey) {
        if (globalHold) return
        if (sessions.isEmpty()) {
            Toast.makeText(this, "No cameras connected", Toast.LENGTH_SHORT).show()
            return
        }
        if (key == CameraSettingKey.WHITE_BALANCE) {
            showGlobalWhiteBalanceWheel(anchor, null)
            return
        }

        val descriptors = sessions.values.mapNotNull { session ->
            session.cameraSettingDescriptors().firstOrNull { it.key == key }?.let { session to it }
        }
        val reference = descriptors.firstOrNull { it.second.writable } ?: run {
            Toast.makeText(this, "${globalSettingShortTitle(key)}: not writable on connected cameras", Toast.LENGTH_SHORT).show()
            return
        }
        val descriptor = reference.second
        val commonRaw = descriptors.mapNotNull { it.second.currentRawValue }.distinct().singleOrNull()
        val commonLabel = descriptors.map { it.second.currentLabel }.filter { it.isNotBlank() && it != "--" }.distinct().singleOrNull()
        val entries = ArrayList<WheelEntry>()

        if (descriptor.options.isNotEmpty()) {
            descriptor.options.forEach { option ->
                entries.add(
                    WheelEntry(
                        label = option.label,
                        selected = if (key == CameraSettingKey.FOCUS_MODE) {
                            commonLabel != null && option.label == commonLabel
                        } else {
                            commonRaw != null && option.rawValue == commonRaw
                        },
                        action = { applyGlobalSetting(key, option.rawValue, option.label) }
                    )
                )
            }
        } else if (key == CameraSettingKey.IRIS || key == CameraSettingKey.ISO || key == CameraSettingKey.SHUTTER) {
            entries.add(WheelEntry("▲", false) { stepGlobalSetting(key, true) })
            entries.add(WheelEntry(if (commonRaw != null) globalSettingDisplayValue(key, descriptor.currentLabel) else "MIX", true) { })
            entries.add(WheelEntry("▼", false) { stepGlobalSetting(key, false) })
        }

        if (entries.isEmpty()) {
            Toast.makeText(this, "${descriptor.title}: no common value list", Toast.LENGTH_SHORT).show()
            return
        }
        showWheelPopup(anchor, entries, key)
    }

    private fun applyGlobalSetting(key: CameraSettingKey, rawValue: Long, label: String) {
        var targeted = 0
        sessions.values.forEach { session ->
            val descriptor = session.cameraSettingDescriptors().firstOrNull { it.key == key } ?: return@forEach
            if (!descriptor.writable) return@forEach
            when (key) {
                CameraSettingKey.ISO -> {
                    // ISO wire values are not portable between Sony bodies. Resolve
                    // the displayed ISO independently against each camera's own enum.
                    val logicalIso = globalSettingDisplayValue(CameraSettingKey.ISO, label)
                    session.setIso(logicalIso)
                    targeted++
                }
                CameraSettingKey.EXPOSURE_COMPENSATION -> {
                    if (!session.isExposureCompensationAdjustable()) return@forEach
                    val target = descriptor.options.firstOrNull { it.label == label }
                        ?: descriptor.options.firstOrNull {
                            globalSettingDisplayValue(key, it.label) == globalSettingDisplayValue(key, label)
                        }
                        ?: return@forEach
                    session.setCameraSetting(key, target.rawValue)
                    targeted++
                }
                CameraSettingKey.FOCUS_MODE -> {
                    // AF raw values differ across Sony bodies. Resolve the compact
                    // AF/MF label against each camera's own 0x500A enum.
                    val target = descriptor.options.firstOrNull { it.label == label } ?: return@forEach
                    session.setCameraSetting(key, target.rawValue)
                    targeted++
                }
                else -> {
                    // For enum properties, only send a raw value that the target body itself
                    // advertised. This makes mixed Sony bodies safe under one global control.
                    if (descriptor.options.isNotEmpty() && descriptor.options.none { it.rawValue == rawValue }) return@forEach
                    session.setCameraSetting(key, rawValue)
                    targeted++
                }
            }
        }
        if (targeted == 0) {
            Toast.makeText(this, "$label: no compatible cameras", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "$label → $targeted camera${if (targeted == 1) "" else "s"}", Toast.LENGTH_SHORT).show()
        window.decorView.postDelayed({ updateGlobalSettingUi() }, 300L)
        window.decorView.postDelayed({ updateGlobalSettingUi() }, 900L)
    }

    private fun stepGlobalSetting(key: CameraSettingKey, up: Boolean) {
        var targeted = 0
        sessions.values.forEach { session ->
            val descriptor = session.cameraSettingDescriptors().firstOrNull { it.key == key } ?: return@forEach
            if (!descriptor.writable) return@forEach
            session.stepCameraSetting(key, up)
            targeted++
        }
        if (targeted > 0) {
            window.decorView.postDelayed({ updateGlobalSettingUi() }, 300L)
            window.decorView.postDelayed({ updateGlobalSettingUi() }, 900L)
        }
    }

    private fun showGlobalWhiteBalanceWheel(anchor: View, section: String?) {
        val states = sessions.values.mapNotNull { session -> session.whiteBalanceUiState()?.let { session to it } }
        if (states.isEmpty()) {
            Toast.makeText(this, "WB: camera information is not ready", Toast.LENGTH_SHORT).show()
            return
        }
        val modes = states.mapNotNull { it.second.currentModeRaw?.toInt()?.and(0xffff) }.distinct()
        val commonMode = modes.singleOrNull()

        when (section) {
            "CUSTOM" -> {
                val entries = states.flatMap { it.second.customTemperatures }
                    .distinctBy { it.rawValue }.sortedBy { it.rawValue }.map { option ->
                    WheelEntry(
                        label = option.label,
                        selected = commonMode == 0x8012 && states.mapNotNull { it.second.currentTemperature }.distinct().singleOrNull() == option.rawValue,
                        action = { applyGlobalWhiteBalanceTemperature(option.rawValue, option.label) }
                    )
                }
                if (entries.isNotEmpty()) showWheelPopup(anchor, entries, CameraSettingKey.WHITE_BALANCE)
                else Toast.makeText(this, "WB: no choices reported by cameras", Toast.LENGTH_SHORT).show()
            }
            "PRESET" -> {
                val entries = states.flatMap { it.second.presetOptions }
                    .distinctBy { it.rawValue and 0xffffL }.map { option ->
                    WheelEntry(
                        label = option.label,
                        selected = states.mapNotNull { it.second.currentModeRaw }.distinct().singleOrNull() == option.rawValue,
                        action = { applyGlobalWhiteBalancePreset(option.rawValue, option.label) }
                    )
                }
                if (entries.isNotEmpty()) showWheelPopup(anchor, entries, CameraSettingKey.WHITE_BALANCE)
                else Toast.makeText(this, "WB: no choices reported by cameras", Toast.LENGTH_SHORT).show()
            }
            else -> {
                val entries = listOf(
                    WheelEntry("AUTO", commonMode == 0x0002) { applyGlobalWhiteBalanceAuto() },
                    WheelEntry("CUSTOM", commonMode == 0x8012) { showGlobalWhiteBalanceWheel(anchor, "CUSTOM") },
                    WheelEntry("PRESET", commonMode != null && commonMode != 0x0002 && commonMode != 0x8012) { showGlobalWhiteBalanceWheel(anchor, "PRESET") }
                )
                showWheelPopup(anchor, entries, CameraSettingKey.WHITE_BALANCE)
            }
        }
    }

    private fun applyGlobalWhiteBalanceAuto() {
        applyGlobalWhiteBalance("WB AUTO") { session, done -> session.setWhiteBalanceAuto(done) }
    }

    private fun applyGlobalWhiteBalancePreset(rawValue: Long, label: String) {
        applyGlobalWhiteBalance(label) { session, done -> session.setWhiteBalancePreset(rawValue, done) }
    }

    private fun applyGlobalWhiteBalanceTemperature(kelvin: Long, label: String) {
        applyGlobalWhiteBalance(label) { session, done -> session.setWhiteBalanceTemperature(kelvin, done) }
    }

    private fun applyGlobalWhiteBalance(
        label: String,
        command: (SonyCameraSession, (Boolean, String) -> Unit) -> Unit
    ) {
        // Capture all sessions once. Each worker refreshes its own capabilities;
        // stale UI enabled flags must never silently remove a camera from ALL CAM.
        val targets = sessions.values.toList()
        if (targets.isEmpty()) {
            Toast.makeText(this, "No cameras connected", Toast.LENGTH_SHORT).show()
            return
        }
        val results = ConcurrentHashMap<String, Pair<Boolean, String>>()
        val reported = java.util.concurrent.atomic.AtomicBoolean(false)
        Toast.makeText(this, "$label: applying to ${targets.size} cameras…", Toast.LENGTH_SHORT).show()
        targets.forEach { session ->
            command(session) { ok, reason ->
                results[session.camera.id] = ok to reason
                android.util.Log.i("SonyMultiLive", "ALL CAM $label [${session.camera.id}] ok=$ok reason=$reason")
                if (results.size == targets.size && reported.compareAndSet(false, true)) {
                    runOnUiThread {
                        updateGlobalSettingUi()
                        val succeeded = results.values.count { it.first }
                        Toast.makeText(this, "$label: $succeeded/${targets.size} cameras confirmed", Toast.LENGTH_LONG).show()
                        val failures = targets.mapNotNull { target ->
                            val result = results[target.camera.id] ?: return@mapNotNull null
                            if (result.first) null else "${target.camera.displayName}: ${result.second}"
                        }
                        if (failures.isNotEmpty() && !isFinishing) {
                            AlertDialog.Builder(this)
                                .setTitle("$label: $succeeded/${targets.size} cameras")
                                .setMessage(failures.joinToString("\n"))
                                .setPositiveButton("OK", null)
                                .show()
                        }
                    }
                }
            }
        }
    }

    private data class WheelEntry(
        val label: String,
        val selected: Boolean = false,
        val action: () -> Unit
    )

    private fun showSettingWheel(
        anchor: View,
        session: SonyCameraSession,
        key: CameraSettingKey
    ) {
        if (globalHold) return
        if (key == CameraSettingKey.WHITE_BALANCE) {
            showWhiteBalanceWheel(anchor, session, null)
            return
        }

        val descriptor = session.cameraSettingDescriptors().firstOrNull { it.key == key }
        if (descriptor == null || !descriptor.writable) {
            Toast.makeText(this, "${key.name}: camera does not expose a writable setting", Toast.LENGTH_SHORT).show()
            return
        }

        val entries = ArrayList<WheelEntry>()
        if (descriptor.options.isNotEmpty()) {
            descriptor.options.forEach { option ->
                entries.add(
                    WheelEntry(
                        label = option.label,
                        selected = option.rawValue == descriptor.currentRawValue ||
                            (key == CameraSettingKey.FOCUS_MODE && option.label == descriptor.currentLabel),
                        action = { session.setCameraSetting(key, option.rawValue) }
                    )
                )
            }
        } else if (key == CameraSettingKey.IRIS || key == CameraSettingKey.ISO || key == CameraSettingKey.SHUTTER) {
            // Some Sony bodies expose these as step-only controls. Keep the same
            // compact wheel interaction instead of falling back to a dialog.
            entries.add(WheelEntry("▲", false) { session.stepCameraSetting(key, true) })
            entries.add(WheelEntry(descriptor.currentLabel, true) { })
            entries.add(WheelEntry("▼", false) { session.stepCameraSetting(key, false) })
        }

        if (entries.isEmpty()) {
            Toast.makeText(this, "${descriptor.title}: camera does not expose a value list", Toast.LENGTH_SHORT).show()
            return
        }
        showWheelPopup(anchor, entries, key)
    }

    private fun showWhiteBalanceWheel(
        anchor: View,
        session: SonyCameraSession,
        section: String?
    ) {
        val state = session.whiteBalanceUiState() ?: run {
            Toast.makeText(this, "WB: camera does not expose this property", Toast.LENGTH_SHORT).show()
            return
        }
        if (!state.modeWritable) return

        val mode = state.currentModeRaw?.toInt()?.and(0xffff)
        when (section) {
            "CUSTOM" -> {
                val entries = state.customTemperatures.map { option ->
                    WheelEntry(
                        label = option.label,
                        selected = mode == 0x8012 && option.rawValue == state.currentTemperature,
                        action = { session.setWhiteBalanceTemperature(option.rawValue) }
                    )
                }
                if (entries.isNotEmpty()) showWheelPopup(anchor, entries, CameraSettingKey.WHITE_BALANCE)
            }
            "PRESET" -> {
                val entries = state.presetOptions.map { option ->
                    WheelEntry(
                        label = option.label,
                        selected = option.rawValue == state.currentModeRaw,
                        action = { session.setWhiteBalancePreset(option.rawValue) }
                    )
                }
                if (entries.isNotEmpty()) showWheelPopup(anchor, entries, CameraSettingKey.WHITE_BALANCE)
            }
            else -> {
                val entries = listOf(
                    WheelEntry("AUTO", mode == 0x0002) { session.setWhiteBalanceAuto() },
                    WheelEntry("CUSTOM", mode == 0x8012) { showWhiteBalanceWheel(anchor, session, "CUSTOM") },
                    WheelEntry("PRESET", mode != 0x0002 && mode != 0x8012) { showWhiteBalanceWheel(anchor, session, "PRESET") }
                )
                showWheelPopup(anchor, entries, CameraSettingKey.WHITE_BALANCE)
            }
        }
    }

    private fun showWheelPopup(
        anchor: View,
        entries: List<WheelEntry>,
        key: CameraSettingKey
    ) {
        if (entries.isEmpty()) return

        val rowHeight = dp(34)
        val visibleRows = min(7, entries.size.coerceAtLeast(3))
        val popupHeight = rowHeight * visibleRows
        val popupWidth = when (key) {
            CameraSettingKey.LOOK -> dp(230)
            CameraSettingKey.WHITE_BALANCE -> dp(170)
            CameraSettingKey.SHUTTER -> dp(118)
            else -> dp(108)
        }

        val listView = ListView(this).apply {
            dividerHeight = 0
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setPadding(dp(3), dp(3), dp(3), dp(3))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xee08090b.toInt())
                setStroke(dp(1), 0xff676b70.toInt())
                cornerRadius = dp(3).toFloat()
            }
        }

        var selectedIndex = entries.indexOfFirst { it.selected }
        if (selectedIndex < 0) selectedIndex = 0

        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = entries.size
            override fun getItem(position: Int): Any = entries[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val entry = entries[position]
                val text = (convertView as? TextView) ?: TextView(this@MainActivity).apply {
                    gravity = Gravity.CENTER
                    textSize = 9.5f
                    typeface = UiFonts.REGULAR
                    setPadding(dp(6), 0, dp(6), 0)
                    maxLines = 1
                }
                text.text = entry.label
                if (position == selectedIndex) {
                    text.setTextColor(Color.BLACK)
                    text.setBackgroundColor(0xffd2d3d4.toInt())
                    text.typeface = UiFonts.MEDIUM
                } else {
                    text.setTextColor(Color.WHITE)
                    text.setBackgroundColor(Color.TRANSPARENT)
                    text.typeface = UiFonts.REGULAR
                }
                text.layoutParams = android.widget.AbsListView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    rowHeight
                )
                return text
            }
        }
        listView.adapter = adapter

        val popup = PopupWindow(listView, popupWidth, popupHeight, true).apply {
            isOutsideTouchable = true
            isTouchable = true
            elevation = dp(7).toFloat()
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        }

        listView.setOnItemClickListener { _, _, position, _ ->
            selectedIndex = position
            popup.dismiss()
            entries[position].action()
        }

        val location = IntArray(2)
        anchor.getLocationOnScreen(location)
        val metrics = resources.displayMetrics
        val anchorCenterX = location[0] + anchor.width / 2
        val anchorCenterY = location[1] + anchor.height / 2
        val x = (anchorCenterX - popupWidth / 2).coerceIn(dp(4), metrics.widthPixels - popupWidth - dp(4))
        val y = (anchorCenterY - popupHeight / 2).coerceIn(dp(4), metrics.heightPixels - popupHeight - dp(4))
        popup.showAtLocation(window.decorView, Gravity.TOP or Gravity.START, x, y)
        listView.post {
            listView.setSelectionFromTop(selectedIndex, popupHeight / 2 - rowHeight / 2)
        }
    }

    private fun setOsdVisible(visible: Boolean) {
        osdVisible = visible
        if (::osdButton.isInitialized) {
            osdButton.text = if (visible) "OSD ON" else "OSD OFF"
            osdButton.setTextColor(if (visible) Color.WHITE else 0xff8b8f94.toInt())
        }
        tiles.values.forEach { it.setOsdVisible(visible) }
    }

    private fun applyAutomaticLayoutForCameraCount(count: Int) {
        // 1-4 keep the original compact monitor layouts. Above four cameras the
        // active presentation is either the horizontal CONTROL ONLY matrix or one
        // selected full-size Live View camera; legacy larger grid modes are retained
        // only for source compatibility.
        gridLayoutMode = GridLayoutMode.forCameraCount(max(count, highestAssignedSlot() + 1))
        if (::layoutButton.isInitialized) layoutButton.text = gridLayoutMode.buttonLabel()
    }

    private fun rebuildGrid() {
        grid.removeAllViews()

        val expanded = expandedCameraId?.let { tiles[it] }
        if (expanded != null) {
            val slot = tilesForFixedSlots().indexOfFirst { it?.camera?.id == expanded.camera.id }
            expanded.setDisplayIndex(if (slot >= 0) slot + 1 else 1)
            expanded.setTelemetryDensity(1)
            (expanded.parent as? ViewGroup)?.removeView(expanded)
            val cell = AspectRatioCell(this).apply {
                setBackgroundColor(0xff08090b.toInt())
                addView(expanded)
            }
            grid.weightSum = 1f
            grid.addView(cell, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            if (::layoutButton.isInitialized) layoutButton.text = "x1 · CAM ${if (slot >= 0) slot + 1 else 1}"
            updateLiveViewButton()
            return
        }
        expandedCameraId = null

        val fleetSelectMode = largeCameraLiveSelectMode || (tiles.size > 4 || highestAssignedSlot() >= 4)
        val controlOnlyMatrix = selectedLiveCameraId == null && (fleetSelectMode || !liveViewAllEnabled)

        // LIVE OFF never reserves a video surface. The whole monitor area becomes
        // a horizontal CONTROL ONLY matrix: one camera per column, up to 20.
        if (controlOnlyMatrix) {
            grid.weightSum = 1f
            if (::layoutButton.isInitialized) {
                layoutButton.text = "CONTROL · ${tiles.size} CAM"
            }

            val strip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.TOP
                setPadding(dp(2), dp(2), dp(2), dp(2))
                setBackgroundColor(Color.BLACK)
            }

            tilesForFixedSlots().forEachIndexed { slot, tile ->
                val cameraId = tile?.camera?.id ?: return@forEachIndexed
                val column = remoteColumns[cameraId] ?: return@forEachIndexed
                column.setDisplayIndex(slot + 1)
                column.setControlsLocked(globalHold)
                (column.parent as? ViewGroup)?.removeView(column)
                strip.addView(
                    column,
                    LinearLayout.LayoutParams(dp(205), LinearLayout.LayoutParams.MATCH_PARENT).apply {
                        marginEnd = dp(3)
                    }
                )
            }

            val scroll = HorizontalScrollView(this).apply {
                isFillViewport = false
                isHorizontalScrollBarEnabled = true
                overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
                addView(
                    strip,
                    ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
            }
            grid.addView(
                scroll,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            )
            updateLiveViewButton()
            return
        }

        // Above four connected cameras only the selected body may stream. Present
        // that camera exactly like the normal one-camera monitor and hide the
        // CONTROL ONLY columns until LIVE is switched OFF again.
        if (fleetSelectMode && selectedLiveCameraId != null) {
            val selectedId = selectedLiveCameraId ?: return
            val tile = tiles[selectedId]
            if (tile != null) {
                val displayIndex = tilesForFixedSlots().indexOfFirst { it?.camera?.id == selectedId }
                    .let { if (it >= 0) it + 1 else 1 }
                val profile = currentProfile(1)
                tile.setDisplayIndex(displayIndex)
                tile.setTelemetryDensity(1)
                tile.setDecodeSampleSize(1)
                tile.setRenderResolution(renderWidth, renderHeight)
                sessions[selectedId]?.setLiveViewProfile(profile)
                (tile.parent as? ViewGroup)?.removeView(tile)

                val cell = AspectRatioCell(this).apply {
                    setBackgroundColor(0xff08090b.toInt())
                    addView(tile)
                }
                grid.weightSum = 1f
                grid.addView(
                    cell,
                    LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
                        setMargins(dp(1), dp(1), dp(1), dp(1))
                    }
                )
                if (::layoutButton.isInitialized) layoutButton.text = "x1 · LIVE CAM $displayIndex"
            }
            updateLiveViewButton()
            return
        }

        // Normal 1-4 camera Live View keeps the existing production monitor grid.
        val activeLiveCount = sessions.values.count { it.isLiveViewEnabled() }.coerceAtLeast(1)
        val profile = currentProfile(activeLiveCount)
        val fixedSlots = tilesForFixedSlots()

        fixedSlots.forEachIndexed { slot, tile ->
            if (tile != null) {
                tile.setDisplayIndex(slot + 1)
                tile.setTelemetryDensity(gridLayoutMode.cameraSlots)
                tile.setDecodeSampleSize(1)
                tile.setRenderResolution(renderWidth, renderHeight)
            }
        }
        sessions.values.forEach { it.setLiveViewProfile(profile) }

        fun cameraCell(slot: Int, tile: CameraTileView?): View {
            if (tile != null) {
                (tile.parent as? ViewGroup)?.removeView(tile)
                return AspectRatioCell(this).apply {
                    setBackgroundColor(0xff08090b.toInt())
                    addView(tile)
                }
            }

            return FrameLayout(this).apply {
                setBackgroundColor(0xff050607.toInt())
                addView(TextView(this@MainActivity).apply {
                    text = "${slot + 1}"
                    setTextColor(0xff42464b.toInt())
                    textSize = 18f
                    typeface = UiFonts.MEDIUM
                    gravity = Gravity.CENTER
                }, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            }
        }

        fun addFixedRow(slotIndices: IntArray, weight: Float = 1f) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = slotIndices.size.toFloat()
                gravity = Gravity.CENTER
            }
            slotIndices.forEach { slot ->
                row.addView(
                    cameraCell(slot, fixedSlots.getOrNull(slot)),
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply {
                        setMargins(dp(1), dp(1), dp(1), dp(1))
                    }
                )
            }
            grid.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, weight))
        }

        val rows = gridLayoutMode.rows()
        grid.weightSum = rows.size.toFloat().coerceAtLeast(1f)
        rows.forEach { addFixedRow(it) }
        if (::layoutButton.isInitialized) layoutButton.text = gridLayoutMode.buttonLabel()

        updateLiveViewButton()
    }

    private fun updateResolutionUi() {
        val low = renderWidth == 640
        resolutionButton.text = if (low) "RES LOW" else "RES HIGH"
        tiles.values.forEach { it.setRenderResolution(renderWidth, renderHeight) }
        // Change the source signal at the camera as well as the local render size.
        sessions.values.forEach { it.setLowResolutionMode(low) }
        rebuildGrid()
        Toast.makeText(
            this,
            if (low) "Camera Live View source: LOW" else "Camera Live View source: HIGH",
            Toast.LENGTH_SHORT
        ).show()
    }

    private enum class GridLayoutMode(
        val cameraSlots: Int,
        val menuItemId: Int,
        val menuLabel: String
    ) {
        ONE(1, 101, "x1 : 1 Camera"),
        TWO(2, 102, "x2 : 2 Camera"),
        TWO_PLUS_ONE(3, 103, "2+1 : 3 Camera"),
        TWO_BY_TWO(4, 104, "2x2 : 4 Camera"),
        THREE_BY_TWO(6, 106, "3x2 : 6 Camera"),
        FOUR_BY_TWO(8, 108, "4x2 : 8 Camera"),
        FIVE_BY_TWO(10, 110, "5x2 : 10 Camera"),
        FOUR_BY_THREE(12, 112, "4x3 : 12 Camera");

        fun buttonLabel(): String = "$menuLabel ▼"

        fun rows(): List<IntArray> = when (this) {
            ONE -> listOf(intArrayOf(0))
            TWO -> listOf(intArrayOf(0, 1))
            TWO_PLUS_ONE -> listOf(intArrayOf(0, 1), intArrayOf(2))
            TWO_BY_TWO -> listOf(intArrayOf(0, 1), intArrayOf(2, 3))
            THREE_BY_TWO -> listOf(intArrayOf(0, 1, 2), intArrayOf(3, 4, 5))
            FOUR_BY_TWO -> listOf(intArrayOf(0, 1, 2, 3), intArrayOf(4, 5, 6, 7))
            FIVE_BY_TWO -> listOf(intArrayOf(0, 1, 2, 3, 4), intArrayOf(5, 6, 7, 8, 9))
            FOUR_BY_THREE -> listOf(
                intArrayOf(0, 1, 2, 3),
                intArrayOf(4, 5, 6, 7),
                intArrayOf(8, 9, 10, 11)
            )
        }

        companion object {
            fun fromMenuItemId(itemId: Int): GridLayoutMode? =
                values().firstOrNull { it.menuItemId == itemId }

            fun forCameraCount(count: Int): GridLayoutMode = when {
                count <= 0 -> TWO_BY_TWO
                count == 1 -> ONE
                count == 2 -> TWO
                count == 3 -> TWO_PLUS_ONE
                count == 4 -> TWO_BY_TWO
                count <= 6 -> THREE_BY_TWO
                count <= 8 -> FOUR_BY_TWO
                count <= 10 -> FIVE_BY_TWO
                else -> FOUR_BY_THREE
            }
        }
    }

    private fun currentProfile(count: Int): LiveViewProfile = if (renderWidth == 640) {
        LiveViewProfile(
            activeCameraCount = count, width = 640, height = 360, fps = 25,
            legacySizeHint = "M",
            modernJpegQuality = LiveViewProfile.QUALITY_LOW,
            label = "LOW 640-class"
        )
    } else {
        LiveViewProfile(
            activeCameraCount = count, width = 1024, height = 576, fps = 25,
            legacySizeHint = "L",
            modernJpegQuality = LiveViewProfile.QUALITY_HIGH,
            label = "SOURCE HIGH 1024-class"
        )
    }

    private fun cancelFrameHold() {
        window.decorView.removeCallbacks(expandFrameHold)
        frameHoldDownEvent?.recycle()
        frameHoldDownEvent = null
    }

    private fun cancelFrameChildTouch(event: MotionEvent) {
        super.dispatchTouchEvent(event)
    }

    private fun restoreExpandedFrame() {
        if (expandedCameraId == null) return
        expandedCameraId = null
        rebuildGrid()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                cancelFrameHold()
                val rect = android.graphics.Rect()
                val tile = if (expandedCameraId == null) tiles.values.firstOrNull {
                    it.isAttachedToWindow && it.isShown && it.getGlobalVisibleRect(rect) &&
                        rect.contains(ev.rawX.toInt(), ev.rawY.toInt())
                } else null
                frameGesture.begin(tile?.camera?.id, ev.rawX, ev.rawY, SystemClock.uptimeMillis())
                if (tile != null) {
                    frameHoldDownEvent = MotionEvent.obtain(ev)
                    window.decorView.postDelayed(expandFrameHold, 2_000L)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                frameGesture.move(ev.rawX, ev.rawY)
                if (!frameGesture.pendingHold) cancelFrameHold()
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                frameGesture.multiplePointers()
                cancelFrameHold()
            }
            MotionEvent.ACTION_UP -> {
                cancelFrameHold()
                val consumedHold = frameGesture.held
                val down = frameGesture.swipeDown(ev.rawX, ev.rawY, dp(70).toFloat())
                val up = frameGesture.swipeUp(ev.rawX, ev.rawY, dp(70).toFloat())
                frameGesture.end()
                if (consumedHold) return true
                if (down && expandedCameraId != null) {
                    val cancel = MotionEvent.obtain(ev)
                    cancel.action = MotionEvent.ACTION_CANCEL
                    cancelFrameChildTouch(cancel)
                    cancel.recycle()
                    restoreExpandedFrame()
                    return true
                }
                if (up) setControlsHidden(true)
                else if (down) setControlsHidden(false)
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelFrameHold()
                frameGesture.end()
            }
        }
        if (frameGesture.held) return true
        return super.dispatchTouchEvent(ev)
    }

    private fun setControlsHidden(hidden: Boolean) {
        if (controlsHidden == hidden) return
        controlsHidden = hidden
        topControls.visibility = if (hidden) View.GONE else View.VISIBLE
        bottomControls.visibility = if (hidden) View.GONE else View.VISIBLE
        // System bars stay hidden in both modes; swiping only toggles our monitor controls.
        enterSystemFullscreen()
    }

    private fun enterSystemFullscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { controller ->
                controller.hide(
                    android.view.WindowInsets.Type.statusBars() or
                        android.view.WindowInsets.Type.navigationBars()
                )
                controller.systemBarsBehavior =
                    android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterSystemFullscreen()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

}
