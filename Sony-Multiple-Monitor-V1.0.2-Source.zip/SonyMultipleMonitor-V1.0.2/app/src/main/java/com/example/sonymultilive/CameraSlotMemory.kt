package com.example.sonymultilive

import java.io.StringReader
import java.io.StringWriter
import java.util.Properties

/** UI-thread-owned slots, including reservations for cameras currently offline. */
class CameraSlotMemory(val size: Int = 20) {
    private val slots = arrayOfNulls<CameraIdentity>(size)
    fun isReserved(slot: Int) = slots.getOrNull(slot) != null
    fun find(identity: CameraIdentity): Int {
        if (identity.mac.isNotBlank()) {
            val strong = slots.indexOfFirst { it?.transport == identity.transport && it.mac == identity.mac }
            if (strong >= 0) return strong
        }
        if (identity.serial.isNotBlank()) {
            val strong = slots.indexOfFirst { it?.transport == identity.transport && it.serial == identity.serial }
            if (strong >= 0) return strong
        }
        return slots.indexOfFirst { it?.matchesSaved(identity) == true }
    }
    fun remember(slot: Int, identity: CameraIdentity) {
        if (slot !in slots.indices) return
        val previous = find(identity)
        val merged = slots.getOrNull(previous)?.enrichedBy(identity) ?: identity
        if (previous >= 0 && previous != slot) slots[previous] = slots[slot]
        slots[slot] = merged
        // Late MAC/serial discovery can link an IP-only reservation to a known
        // body. Keep exactly one saved reservation for that physical identity.
        for (i in slots.indices) if (i != slot && slots[i]?.matchesSaved(merged) == true) slots[i] = null
    }
    fun forget(slot: Int) { if (slot in slots.indices) slots[slot] = null }
    fun clear() = slots.fill(null)
    fun encode(): String {
        val p = Properties()
        slots.forEachIndexed { i, identity ->
            if (identity != null) {
                p.setProperty("$i.transport", identity.transport.name)
                p.setProperty("$i.id", identity.id); p.setProperty("$i.ip", identity.ip)
                p.setProperty("$i.mac", identity.mac); p.setProperty("$i.serial", identity.serial)
                p.setProperty("$i.usb", identity.usbPath)
            }
        }
        return StringWriter().also { p.store(it, "Camera fixed slots") }.toString()
    }
    fun load(encoded: String) {
        clear()
        val p = Properties()
        if (runCatching { p.load(StringReader(encoded)) }.isFailure) return
        for (i in slots.indices) {
            val transport = runCatching { CameraTransport.valueOf(p.getProperty("$i.transport")) }.getOrNull() ?: continue
            val identity = CameraIdentity(transport, p.getProperty("$i.id", ""),
                CameraIdentity.normalizeIp(p.getProperty("$i.ip", "")), CameraIdentity.normalizeMac(p.getProperty("$i.mac", "")),
                CameraIdentity.normalizeSerial(p.getProperty("$i.serial", "")), p.getProperty("$i.usb", ""))
            if (identity.id.isBlank() && identity.ip.isBlank() && identity.mac.isBlank() && identity.serial.isBlank() && identity.usbPath.isBlank()) continue
            if (slots.filterNotNull().any { it.matchesSaved(identity) }) continue
            slots[i] = identity
        }
    }
}
