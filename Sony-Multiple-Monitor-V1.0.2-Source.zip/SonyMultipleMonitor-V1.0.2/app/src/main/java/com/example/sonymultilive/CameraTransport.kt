package com.example.sonymultilive

enum class CameraTransport {
    PTP_IP,
    USB_PTP
}
