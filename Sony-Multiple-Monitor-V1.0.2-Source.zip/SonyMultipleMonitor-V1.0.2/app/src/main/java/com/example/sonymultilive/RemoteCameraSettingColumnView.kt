package com.example.sonymultilive

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.text.TextUtils
import android.util.TypedValue
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

/**
 * CONTROL ONLY presentation used when Live View is disabled.
 * One instance represents one connected camera. It contains no JPEG surface;
 * only Sony PTP status/telemetry and setting controls are shown.
 */
class RemoteCameraSettingColumnView(
    context: Context,
    val camera: SonyCamera
) : LinearLayout(context) {

    @Volatile private var displayIndex = 1
    @Volatile private var telemetry = CameraTelemetry()
    @Volatile private var connectionState = "SONY PTP/IP · CONNECTING"
    @Volatile private var controlsLocked = false
    @Volatile private var settingsTapListener: (() -> Unit)? = null
    @Volatile private var settingTapListener: ((CameraSettingKey, View) -> Unit)? = null

    private var recordBlinkPhase = false
    private var recordBlinkRunning = false
    private val recordBlinkRunnable = object : Runnable {
        override fun run() {
            if (!isRecordingForUi() || !isAttachedToWindow) {
                recordBlinkRunning = false
                recordBlinkPhase = false
                applyRecordingFrame()
                return
            }
            recordBlinkPhase = !recordBlinkPhase
            applyRecordingFrame()
            postDelayed(this, 450L)
        }
    }

    private val regularTypeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private val mediumTypeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    private val header = TextView(context).apply {
        setTextColor(Color.WHITE)
        textSize = 10.5f
        typeface = mediumTypeface
        gravity = Gravity.CENTER
        includeFontPadding = false
        setLineSpacing(0f, 0.94f)
        setPadding(dp(8), dp(5), dp(8), dp(5))
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        setHorizontallyScrolling(true)
        background = normalHeaderBackground()
        isClickable = true
        isFocusable = true
        setOnClickListener { if (!controlsLocked) settingsTapListener?.invoke() }
    }

    private val cameraInfo = TextView(context).apply {
        setTextColor(0xffb9c0c8.toInt())
        textSize = 8.5f
        typeface = regularTypeface
        gravity = Gravity.CENTER
        includeFontPadding = false
        setLineSpacing(0f, 0.92f)
        setPadding(dp(8), dp(3), dp(8), dp(3))
        maxLines = 3
        ellipsize = TextUtils.TruncateAt.END
        setHorizontallyScrolling(true)
        background = normalInfoBackground()
        isClickable = true
        isFocusable = true
        setOnClickListener { if (!controlsLocked) settingsTapListener?.invoke() }
    }

    private val fields = LinkedHashMap<CameraSettingKey, TextView>()

    init {
        orientation = VERTICAL
        gravity = Gravity.TOP
        setPadding(dp(2), dp(2), dp(2), dp(2))
        background = normalColumnBackground()

        addView(header, LayoutParams(LayoutParams.MATCH_PARENT, dp(42)))
        addView(cameraInfo, LayoutParams(LayoutParams.MATCH_PARENT, dp(56)).apply {
            topMargin = dp(2)
        })
        addSetting("FPS", CameraSettingKey.RECORD_FRAME_RATE)
        addSetting("FOCUS", CameraSettingKey.FOCUS_MODE)
        addSetting("IRIS", CameraSettingKey.IRIS)
        addSetting("ISO", CameraSettingKey.ISO)
        addSetting("SHUTTER", CameraSettingKey.SHUTTER)
        addSetting("EV", CameraSettingKey.EXPOSURE_COMPENSATION)
        addSetting("WB", CameraSettingKey.WHITE_BALANCE)
        addSetting("LOOK", CameraSettingKey.LOOK)

        refresh()
    }

    private fun addSetting(title: String, key: CameraSettingKey) {
        val field = TextView(context).apply {
            tag = key
            setTextColor(Color.WHITE)
            textSize = 9.5f
            typeface = regularTypeface
            gravity = Gravity.CENTER
            includeFontPadding = false
            setLineSpacing(0f, 0.92f)
            setPadding(dp(8), dp(3), dp(8), dp(3))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setHorizontallyScrolling(true)
            setAutoSizeTextTypeUniformWithConfiguration(7, 10, 1, TypedValue.COMPLEX_UNIT_SP)
            text = "$title   --"
            background = GradientDrawable().apply {
                setColor(0xff0b0d10.toInt())
                setStroke(dp(1), 0xff2d3136.toInt())
            }
            isClickable = true
            isFocusable = true
            setOnClickListener {
                if (!controlsLocked) settingTapListener?.invoke(key, this)
            }
        }
        fields[key] = field
        addView(field, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f).apply {
            topMargin = dp(2)
        })
    }

    fun refreshCameraIdentity() { post(::refresh) }

    fun setDisplayIndex(index: Int) {
        displayIndex = index.coerceAtLeast(1)
        post { refresh() }
    }

    fun setTelemetry(value: CameraTelemetry) {
        telemetry = value
        post { refresh() }
    }

    private fun isRecordingForUi(): Boolean = telemetry.recording

    fun setState(value: String) {
        connectionState = value
        post { refreshCameraInfo() }
    }

    fun setControlsLocked(locked: Boolean) {
        controlsLocked = locked
        post {
            header.alpha = if (locked) 0.48f else 1f
            cameraInfo.alpha = if (locked) 0.58f else 1f
            fields.forEach { (key, field) ->
                field.alpha = if (locked || (key == CameraSettingKey.EXPOSURE_COMPENSATION && !telemetry.evDisplayEnabled)) 0.42f else 1f
            }
        }
    }

    fun setOnSettingsTapListener(listener: (() -> Unit)?) {
        settingsTapListener = listener
    }

    fun setOnSettingTapListener(listener: ((CameraSettingKey, View) -> Unit)?) {
        settingTapListener = listener
    }

    private fun refresh() {
        val cameraName = camera.displayName
        val rec = if (isRecordingForUi()) "  ·  REC" else ""
        header.text = "CAM $displayIndex  ·  $cameraName$rec"

        refreshCameraInfo()
        updateRecordingBlink()
        setField(CameraSettingKey.RECORD_FRAME_RATE, "FPS", telemetry.recordFrameRate)
        setField(CameraSettingKey.FOCUS_MODE, "FOCUS", telemetry.focusMode)
        setField(CameraSettingKey.IRIS, "IRIS", telemetry.iris.removePrefix("IRIS "))
        setField(CameraSettingKey.ISO, "ISO", telemetry.iso.removePrefix("ISO ").removePrefix("EI "))
        setField(CameraSettingKey.SHUTTER, "SHUTTER", telemetry.shutter.removePrefix("SHUTTER "))
        setField(CameraSettingKey.EXPOSURE_COMPENSATION, "EV", telemetry.exposureCompensation)
        setField(CameraSettingKey.WHITE_BALANCE, "WB", telemetry.whiteBalance.removePrefix("WB "))
        setField(CameraSettingKey.LOOK, "LOOK", telemetry.look.removePrefix("LOOK "))

        fields[CameraSettingKey.EXPOSURE_COMPENSATION]?.alpha =
            if (controlsLocked || !telemetry.evDisplayEnabled) 0.42f else 1f
    }

    private fun refreshCameraInfo() {
        val model = camera.modelName.ifBlank { camera.manufacturer.ifBlank { "Sony" } }
        val battery = telemetry.batteryPercent?.let { "BAT ${it.coerceIn(0, 100)}%" } ?: "BAT --"
        val card = telemetry.cardRemainingSeconds?.let { "CARD ${formatCardRemaining(it)}" } ?: "CARD --"
        val status = compactState(connectionState)
        cameraInfo.text = "$model · ${camera.connectionDisplay}\n$battery · $card\n$status"
        cameraInfo.setTextColor(if (status.startsWith("ERROR") || status.startsWith("OFFLINE")) 0xffff8a8f.toInt() else 0xffb9c0c8.toInt())
    }

    private fun compactState(raw: String): String {
        val s = raw.lowercase(Locale.US)
        return when {
            s.contains("control only") -> "REMOTE READY · LIVE OFF"
            s.contains("first frame") || s.contains("fast pull") -> "LIVE VIEW ACTIVE"
            s.contains("playback") -> "PLAYBACK"
            s.contains("disconnected") || s.contains("closed") -> "OFFLINE · PTP DISCONNECTED"
            s.contains("error") || s.contains("failed") || s.contains("ehostunreach") || s.contains("no route") -> "ERROR · CHECK CAMERA"
            s.contains("wait") || s.contains("init") || s.contains("handshake") || s.contains("connecting") -> "PTP CONNECTING"
            else -> "PTP REMOTE ACTIVE"
        }
    }

    private fun setField(key: CameraSettingKey, title: String, value: String) {
        fields[key]?.text = "$title   ${value.ifBlank { "--" }}"
    }

    private fun updateRecordingBlink() {
        if (isRecordingForUi() && isAttachedToWindow) {
            if (!recordBlinkRunning) {
                recordBlinkRunning = true
                recordBlinkPhase = true
                applyRecordingFrame()
                postDelayed(recordBlinkRunnable, 450L)
            } else {
                applyRecordingFrame()
            }
        } else {
            removeCallbacks(recordBlinkRunnable)
            recordBlinkRunning = false
            recordBlinkPhase = false
            applyRecordingFrame()
        }
    }

    private fun applyRecordingFrame() {
        if (isRecordingForUi()) {
            val active = recordBlinkPhase
            background = recordingColumnBackground(active)
            header.background = recordingHeaderBackground(active)
            cameraInfo.background = recordingInfoBackground(active)
            header.setTextColor(if (active) Color.WHITE else 0xffff7d86.toInt())
        } else {
            background = normalColumnBackground()
            header.background = normalHeaderBackground()
            cameraInfo.background = normalInfoBackground()
            header.setTextColor(Color.WHITE)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateRecordingBlink()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(recordBlinkRunnable)
        recordBlinkRunning = false
        recordBlinkPhase = false
        super.onDetachedFromWindow()
    }

    private fun normalColumnBackground() = GradientDrawable().apply {
        setColor(0xff050607.toInt())
        setStroke(dp(1), 0xff34383d.toInt())
    }

    private fun normalHeaderBackground() = GradientDrawable().apply {
        setColor(0xff101317.toInt())
        setStroke(dp(1), 0xff55585d.toInt())
    }

    private fun normalInfoBackground() = GradientDrawable().apply {
        setColor(0xff090b0e.toInt())
        setStroke(dp(1), 0xff2d3136.toInt())
    }

    private fun recordingColumnBackground(active: Boolean) = GradientDrawable().apply {
        setColor(if (active) 0xff160407.toInt() else 0xff050607.toInt())
        setStroke(dp(if (active) 3 else 2), if (active) 0xffff3045.toInt() else 0xff8a1825.toInt())
    }

    private fun recordingHeaderBackground(active: Boolean) = GradientDrawable().apply {
        setColor(if (active) 0xffb40d22.toInt() else 0xff26070c.toInt())
        setStroke(dp(2), if (active) 0xffff6675.toInt() else 0xff941628.toInt())
    }

    private fun recordingInfoBackground(active: Boolean) = GradientDrawable().apply {
        setColor(if (active) 0xff3a070e.toInt() else 0xff120609.toInt())
        setStroke(dp(2), if (active) 0xffff3045.toInt() else 0xff78101d.toInt())
    }

    private fun formatCardRemaining(seconds: Long): String {
        val totalMinutes = (seconds.coerceAtLeast(0L) + 30L) / 60L
        val hours = totalMinutes / 60L
        val minutes = totalMinutes % 60L
        return if (hours > 0L) String.format(Locale.US, "%dh%02dm", hours, minutes)
        else String.format(Locale.US, "%dm", minutes)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
