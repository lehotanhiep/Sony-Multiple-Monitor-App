package com.example.sonymultilive

import android.graphics.Typeface

/** Built-in Android fonts used explicitly so OEM/user font substitutions do not distort the monitor UI. */
object UiFonts {
    val REGULAR: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    val MEDIUM: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
}
