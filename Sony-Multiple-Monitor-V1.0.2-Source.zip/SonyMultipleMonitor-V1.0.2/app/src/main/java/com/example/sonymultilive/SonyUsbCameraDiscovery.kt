package com.example.sonymultilive

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager

object SonyUsbCameraDiscovery {
    private const val SONY_VENDOR_ID = 0x054c

    fun findSonyPtpDevices(context: Context): List<UsbDevice> {
        val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        return manager.deviceList.values
            .filter { device ->
                device.vendorId == SONY_VENDOR_ID && hasPtpInterface(device)
            }
            .sortedWith(compareBy<UsbDevice>({ it.vendorId }, { it.productId }, { it.deviceId }))
    }

    fun hasPtpInterface(device: UsbDevice): Boolean {
        // Standard Still Image/PTP is authoritative. Keep Sony vendor-class as a
        // compatibility fallback for bodies that expose Camera Control that way.
        for (wantedClass in intArrayOf(UsbConstants.USB_CLASS_STILL_IMAGE, UsbConstants.USB_CLASS_VENDOR_SPEC)) {
            for (index in 0 until device.interfaceCount) {
                val usbInterface = device.getInterface(index)
                if (usbInterface.interfaceClass != wantedClass) continue
                var hasBulkIn = false
                var hasBulkOut = false
                for (epIndex in 0 until usbInterface.endpointCount) {
                    val endpoint = usbInterface.getEndpoint(epIndex)
                    if (endpoint.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                    if (endpoint.direction == UsbConstants.USB_DIR_IN) hasBulkIn = true
                    if (endpoint.direction == UsbConstants.USB_DIR_OUT) hasBulkOut = true
                }
                if (hasBulkIn && hasBulkOut) return true
            }
        }
        return false
    }

    fun toSonyCamera(context: Context, device: UsbDevice): SonyCamera {
        val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        val granted = manager.hasPermission(device)
        val manufacturer = runCatching { device.manufacturerName.orEmpty() }.getOrDefault("")
        val model = runCatching { device.productName.orEmpty() }.getOrDefault("")
            .ifBlank { "Sony USB Camera" }
        val serial = if (granted) {
            runCatching { device.serialNumber.orEmpty() }.getOrDefault("")
        } else {
            ""
        }
        val stableId = if (serial.isNotBlank()) {
            "usb:${device.vendorId.toString(16)}:${device.productId.toString(16)}:$serial"
        } else {
            "usb:${device.deviceName}"
        }
        return SonyCamera(
            id = stableId,
            friendlyName = model,
            modelName = model,
            locationUrl = "",
            host = "USB",
            manufacturer = manufacturer.ifBlank { "Sony" },
            serialNumber = serial,
            ptpRemoteControlAdvertised = true,
            ptpRemoteControlEnabled = true,
            transport = CameraTransport.USB_PTP,
            usbDeviceName = device.deviceName,
            usbDeviceId = device.deviceId,
            usbVendorId = device.vendorId,
            usbProductId = device.productId
        )
    }
}
