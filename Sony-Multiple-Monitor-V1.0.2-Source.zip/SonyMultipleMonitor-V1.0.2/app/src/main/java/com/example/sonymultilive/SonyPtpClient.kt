package com.example.sonymultilive

/**
 * Common Sony PTP transaction transport used by both PTP/IP (Wi-Fi) and
 * standard PTP over Android USB Host.
 */
interface SonyPtpClient : AutoCloseable {
    data class PtpResult(
        val responseCode: Int,
        val params: IntArray,
        val data: ByteArray
    ) {
        val ok: Boolean get() = responseCode == RC_OK
    }

    data class PtpEvent(
        val code: Int,
        val transactionId: Long,
        val params: IntArray
    )

    fun connect(timeoutMs: Int = 5000)
    fun openSession(sessionId: Int = 1): PtpResult
    fun transaction(
        opCode: Int,
        params: IntArray = intArrayOf(),
        dataOut: ByteArray? = null
    ): PtpResult

    companion object {
        const val RC_OK = 0x2001
        const val RC_SESSION_NOT_OPEN = 0x2003
        const val RC_SESSION_ALREADY_OPEN = 0x201E
    }
}
