package com.example.sonymultilive

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.hardware.usb.UsbRequest
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Standard PTP-over-USB transport for Sony cameras through Android USB Host.
 *
 * The Sony SDIO/vendor operations remain in SonyPtpLiveViewController; this class
 * only replaces the transport framing that PTP/IP normally provides.
 */
class SonyUsbPtpClient(
    context: Context,
    private val usbDeviceName: String,
    private val usbDeviceId: Int? = null,
    private val onEvent: (SonyPtpClient.PtpEvent) -> Unit = {}
) : SonyPtpClient {
    companion object {
        private const val CONTAINER_COMMAND = 1
        private const val CONTAINER_DATA = 2
        private const val CONTAINER_RESPONSE = 3
        private const val CONTAINER_EVENT = 4
        private const val MAX_CONTAINER_BYTES = 128 * 1024 * 1024
        private const val READ_CHUNK = 16 * 1024
        private const val READ_SLICE_TIMEOUT_MS = 250
        private const val DEFAULT_IO_TIMEOUT_MS = 5000
        private const val OP_OPEN_SESSION = 0x1002
        private const val OP_CLOSE_SESSION = 0x1003
    }

    private val app = context.applicationContext
    private val manager = app.getSystemService(Context.USB_SERVICE) as UsbManager
    private val commandLock = ReentrantLock(true)
    private val running = AtomicBoolean(false)
    private val nextTransaction = AtomicInteger(1)

    @Volatile private var ioTimeoutMs = DEFAULT_IO_TIMEOUT_MS
    @Volatile private var device: UsbDevice? = null
    @Volatile private var connection: UsbDeviceConnection? = null
    @Volatile private var ptpInterface: UsbInterface? = null
    @Volatile private var bulkIn: UsbEndpoint? = null
    @Volatile private var bulkOut: UsbEndpoint? = null
    @Volatile private var interruptIn: UsbEndpoint? = null
    @Volatile private var eventThread: Thread? = null
    private var inputReader: UsbEndpointReader? = null
    @Volatile private var interfaceSummary: String = "USB interface not selected"
    @Volatile private var lastIoStage: String = "USB idle"
    @Volatile private var sessionOpen = false

    fun diagnostics(): String = "$interfaceSummary · $lastIoStage"

    override fun connect(timeoutMs: Int) {
        close()
        ioTimeoutMs = timeoutMs.coerceAtLeast(1200)

        val usbDevice = manager.deviceList.values.firstOrNull {
            it.deviceName == usbDeviceName || (usbDeviceId != null && it.deviceId == usbDeviceId)
        } ?: throw IOException("USB camera is not attached")

        if (!manager.hasPermission(usbDevice)) {
            throw SecurityException("USB permission not granted")
        }

        val selection = selectPtpInterface(usbDevice)
            ?: throw IOException("Sony USB device has no PTP still-image interface")
        val conn = manager.openDevice(usbDevice)
            ?: throw IOException("Cannot open Sony USB device")
        if (!conn.claimInterface(selection.usbInterface, true)) {
            conn.close()
            throw IOException("Cannot claim Sony PTP USB interface")
        }

        interfaceSummary = describeSelection(selection)
        // Camera Remote Command PTP-V3 on current Sony bodies expects the freshly
        // claimed Still-Image interface to receive OpenSession directly. Do not
        // send Still-Image class CancelRequest/DeviceReset here: Monitor & Control
        // and Sony-compatible CrCmd implementations do not reset the class before
        // opening the remote session, and doing so can leave ZV-E10M2 silent on
        // the very first bulk command.
        lastIoStage = "USB CLAIMED · CRCMD V3 READY"

        device = usbDevice
        connection = conn
        ptpInterface = selection.usbInterface
        bulkIn = selection.bulkIn
        bulkOut = selection.bulkOut
        interruptIn = selection.interruptIn
        inputReader = UsbEndpointReader(
            connection = conn,
            endpoint = selection.bulkIn,
            isStillAttached = { manager.deviceList.values.any { it.deviceName == usbDeviceName } }
        )
        lastIoStage = "USB READY"
        running.set(true)
        selection.interruptIn?.let { startEventReader(conn, it) }
    }

    override fun openSession(sessionId: Int): SonyPtpClient.PtpResult {
        // Camera Remote Command starts the fresh USB transaction sequence at 1.
        // Some Sony bodies keep the PTP session alive for a short period after an
        // Android process/app releases the USB interface. In that case OpenSession
        // returns 0x201E (SessionAlreadyOpen). This is a recoverable camera state,
        // not a transport failure: close the stale session and reopen cleanly.
        nextTransaction.set(1)
        sessionOpen = false

        val firstTx = nextTransaction.getAndIncrement()
        lastIoStage = "OPEN SESSION · SEND 0x1002 · TX=$firstTx"
        try {
            val first = transactionWithId(firstTx, OP_OPEN_SESSION, intArrayOf(sessionId), null)
            lastIoStage = "OPEN SESSION · RESPONSE 0x%04X · TX=$firstTx".format(first.responseCode)
            if (first.responseCode == SonyPtpClient.RC_OK) {
                sessionOpen = true
                return first
            }
            if (first.responseCode != SonyPtpClient.RC_SESSION_ALREADY_OPEN) {
                return first
            }

            val closeTx = nextTransaction.getAndIncrement()
            lastIoStage = "OPEN SESSION · 0x201E STALE · CLOSE 0x1003 · TX=$closeTx"
            // Sony PC-Remote bodies need the session id echoed on CloseSession;
            // otherwise some firmware ACKs 0x1003 but leaves the session open.
            val closed = transactionWithId(closeTx, OP_CLOSE_SESSION, intArrayOf(sessionId), null)
            if (closed.responseCode != SonyPtpClient.RC_OK &&
                closed.responseCode != SonyPtpClient.RC_SESSION_NOT_OPEN) {
                lastIoStage = "STALE SESSION CLOSE FAILED · RESPONSE 0x%04X · TX=$closeTx"
                    .format(closed.responseCode)
                return closed
            }

            // Give the camera's remote task a short window to release the old
            // session before opening the new one. No USB class reset is issued.
            Thread.sleep(180L)

            val reopenTx = nextTransaction.getAndIncrement()
            lastIoStage = "OPEN SESSION · REOPEN 0x1002 · TX=$reopenTx"
            val reopened = transactionWithId(reopenTx, OP_OPEN_SESSION, intArrayOf(sessionId), null)
            lastIoStage = "OPEN SESSION · REOPEN RESPONSE 0x%04X · TX=$reopenTx"
                .format(reopened.responseCode)
            sessionOpen = reopened.responseCode == SonyPtpClient.RC_OK
            return reopened
        } catch (t: Throwable) {
            lastIoStage = "OPEN SESSION · RECOVERY FAILED"
            throw IOException(
                "USB CrCmd V3 OpenSession failed: ${t.message ?: t.javaClass.simpleName}",
                t
            )
        }
    }

    override fun transaction(
        opCode: Int,
        params: IntArray,
        dataOut: ByteArray?
    ): SonyPtpClient.PtpResult {
        return transactionWithId(nextTransaction.getAndIncrement(), opCode, params, dataOut)
    }

    private fun transactionWithId(
        transactionId: Int,
        opCode: Int,
        params: IntArray,
        dataOut: ByteArray?
    ): SonyPtpClient.PtpResult = commandLock.withLock {
        val conn = connection ?: error("USB PTP not connected")
        val out = bulkOut ?: error("USB PTP OUT endpoint missing")
        val reader = inputReader ?: error("USB PTP IN endpoint missing")

        val commandBody = ByteBuffer.allocate(params.size * 4)
            .order(ByteOrder.LITTLE_ENDIAN)
            .apply { params.forEach { putInt(it) } }
            .array()
        val opLabel = "0x%04X".format(opCode)
        try {
            lastIoStage = "$opLabel TX=$transactionId · WRITE COMMAND"
            writeContainer(conn, out, CONTAINER_COMMAND, opCode, transactionId, commandBody)

            if (dataOut != null) {
                lastIoStage = "$opLabel TX=$transactionId · WRITE DATA ${dataOut.size}B"
                writeContainer(conn, out, CONTAINER_DATA, opCode, transactionId, dataOut)
            }

            var data = ByteArrayOutputStream(64 * 1024)
            while (true) {
                lastIoStage = "$opLabel TX=$transactionId · WAIT BULK IN"
                val container = reader.readContainer(ioTimeoutMs)
            if (container.transactionId != transactionId) {
                throw IOException(
                    "USB PTP transaction mismatch ${container.transactionId} != $transactionId"
                )
            }
            when (container.type) {
                CONTAINER_DATA -> {
                    if (container.code != opCode) {
                        throw IOException(
                            "USB PTP data opcode mismatch 0x${container.code.toString(16)} != 0x${opCode.toString(16)}"
                        )
                    }
                    if (data.size() == 0 && container.payload.size > 64 * 1024) {
                        data = ByteArrayOutputStream(container.payload.size)
                    }
                    data.write(container.payload)
                }
                CONTAINER_RESPONSE -> {
                    val responseParams = IntArray(container.payload.size / 4) { index ->
                        ByteBuffer.wrap(container.payload, index * 4, 4)
                            .order(ByteOrder.LITTLE_ENDIAN)
                            .int
                    }
                    return@withLock SonyPtpClient.PtpResult(
                        container.code,
                        responseParams,
                        data.toByteArray()
                    )
                }
                else -> throw IOException("Unexpected USB PTP container type=${container.type}")
            }
            }
        } catch (t: Throwable) {
            val detail = t.message ?: t.javaClass.simpleName
            throw IOException("$opLabel TX=$transactionId · $lastIoStage · $detail", t)
        }
        @Suppress("UNREACHABLE_CODE")
        SonyPtpClient.PtpResult(0, intArrayOf(), byteArrayOf())
    }

    override fun close() {
        // Best-effort graceful session shutdown. We intentionally do not wait for
        // the CloseSession response here because close() can be called while the
        // live-view worker is being stopped. If the command lock is immediately
        // available, putting 0x1003 on Bulk OUT is enough to let the camera release
        // the remote session before the USB interface disappears.
        val conn = connection
        val out = bulkOut
        if (sessionOpen && conn != null && out != null && commandLock.tryLock()) {
            try {
                val tx = nextTransaction.getAndIncrement()
                lastIoStage = "CLOSE SESSION · SEND 0x1003 · TX=$tx"
                runCatching {
                    val closePayload = ByteBuffer.allocate(4)
                        .order(ByteOrder.LITTLE_ENDIAN)
                        .putInt(1)
                        .array()
                    writeContainer(conn, out, CONTAINER_COMMAND, OP_CLOSE_SESSION, tx, closePayload)
                }
                sessionOpen = false
                Thread.sleep(35L)
            } finally {
                commandLock.unlock()
            }
        }

        running.set(false)
        val iface = ptpInterface
        runCatching { eventThread?.interrupt() }
        eventThread = null
        inputReader = null
        bulkIn = null
        bulkOut = null
        interruptIn = null
        ptpInterface = null
        device = null
        connection = null
        sessionOpen = false
        if (conn != null && iface != null) runCatching { conn.releaseInterface(iface) }
        runCatching { conn?.close() }
    }

    private data class InterfaceSelection(
        val usbInterface: UsbInterface,
        val bulkIn: UsbEndpoint,
        val bulkOut: UsbEndpoint,
        val interruptIn: UsbEndpoint?
    )

    private fun selectPtpInterface(device: UsbDevice): InterfaceSelection? {
        // Score every interface instead of taking the first bulk pair. Sony bodies can
        // expose MTP/auxiliary interfaces beside PC Remote. The standard PTP tuple
        // class=6, subclass=1, protocol=1 wins, then other Still Image interfaces,
        // then Sony vendor-class fallback.
        val candidates = mutableListOf<Pair<Int, InterfaceSelection>>()
        for (index in 0 until device.interfaceCount) {
            val iface = device.getInterface(index)
            var inEp: UsbEndpoint? = null
            var outEp: UsbEndpoint? = null
            var eventEp: UsbEndpoint? = null
            for (epIndex in 0 until iface.endpointCount) {
                val ep = iface.getEndpoint(epIndex)
                when {
                    ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK &&
                        ep.direction == UsbConstants.USB_DIR_IN -> inEp = ep
                    ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK &&
                        ep.direction == UsbConstants.USB_DIR_OUT -> outEp = ep
                    ep.type == UsbConstants.USB_ENDPOINT_XFER_INT &&
                        ep.direction == UsbConstants.USB_DIR_IN -> eventEp = ep
                }
            }
            if (inEp == null || outEp == null) continue
            val score = when {
                iface.interfaceClass == UsbConstants.USB_CLASS_STILL_IMAGE &&
                    iface.interfaceSubclass == 1 && iface.interfaceProtocol == 1 -> 300
                iface.interfaceClass == UsbConstants.USB_CLASS_STILL_IMAGE -> 200
                iface.interfaceClass == UsbConstants.USB_CLASS_VENDOR_SPEC -> 100
                else -> 0
            }
            if (score == 0) continue
            candidates += score to InterfaceSelection(iface, inEp, outEp, eventEp)
        }
        return candidates.maxByOrNull { it.first }?.second
    }

    private fun describeSelection(selection: InterfaceSelection): String {
        val i = selection.usbInterface
        fun ep(e: UsbEndpoint?): String = if (e == null) "--" else
            "0x${e.address.toString(16)} mps=${e.maxPacketSize}"
        return "IF#${i.id} alt=${i.alternateSetting} " +
            "class=${i.interfaceClass}/${i.interfaceSubclass}/${i.interfaceProtocol} " +
            "BIN=${ep(selection.bulkIn)} BOUT=${ep(selection.bulkOut)} INT=${ep(selection.interruptIn)}"
    }

    /**
     * Put the USB Still-Image/PTP interface into a clean session state before
     * OpenSession. Sony bodies can keep a stale PTP/PC-Remote transaction after
     * an Android process is killed or a cable is replugged quickly. A class-level
     * PTP DeviceReset followed by endpoint clear/drain is substantially more
     * reliable than treating the first bulk-IN timeout as a disconnect.
     */
    private fun preparePtpDevice(
        connection: UsbDeviceConnection,
        selection: InterfaceSelection
    ) {
        // Best-effort PTP CancelRequest then DeviceReset. Some Android/Sony
        // combinations return -1 for CancelRequest; DeviceReset is the important
        // operation and both requests are intentionally non-fatal here.
        runCatching {
            connection.controlTransfer(
                0x21, 0x64, 0, selection.usbInterface.id, null, 0, 1200
            )
        }
        Thread.sleep(80)
        runCatching {
            connection.controlTransfer(
                0x21, 0x66, 0, selection.usbInterface.id, null, 0, 2500
            )
        }
        Thread.sleep(120)

        clearAndDrain(connection, selection.bulkIn, selection.bulkOut)
        // Sony PC-Remote firmware needs a brief settle after the class reset.
        Thread.sleep(450)
    }

    private fun clearAndDrain(
        connection: UsbDeviceConnection,
        inEndpoint: UsbEndpoint,
        outEndpoint: UsbEndpoint
    ) {
        runCatching {
            connection.controlTransfer(0x02, 0x01, 0, outEndpoint.address, null, 0, 900)
        }
        runCatching {
            connection.controlTransfer(0x02, 0x01, 0, inEndpoint.address, null, 0, 900)
        }
        val scratch = ByteArray(maxOf(512, inEndpoint.maxPacketSize.coerceAtLeast(64) * 4))
        repeat(16) {
            val n = runCatching {
                connection.bulkTransfer(inEndpoint, scratch, scratch.size, 35)
            }.getOrDefault(-1)
            if (n <= 0) return
        }
    }

    /** Recover only the bulk pipes; do not issue another class DeviceReset in the
     * middle of a transaction retry because the camera may already have accepted
     * OpenSession and merely lost the response packet. */
    private fun recoverBulkPipes() {
        val conn = connection ?: return
        val input = bulkIn ?: return
        val output = bulkOut ?: return
        runCatching { clearAndDrain(conn, input, output) }
        inputReader?.reset()
        lastIoStage = "USB PIPE RECOVERED"
    }

    private fun writeContainer(
        connection: UsbDeviceConnection,
        endpoint: UsbEndpoint,
        type: Int,
        code: Int,
        transactionId: Int,
        payload: ByteArray
    ) {
        val total = 12L + payload.size
        require(total <= MAX_CONTAINER_BYTES) { "USB PTP container too large: $total" }
        val bytes = ByteBuffer.allocate(total.toInt())
            .order(ByteOrder.LITTLE_ENDIAN)
            .putInt(total.toInt())
            .putShort(type.toShort())
            .putShort(code.toShort())
            .putInt(transactionId)
            .put(payload)
            .array()
        var offset = 0
        while (offset < bytes.size) {
            val written = connection.bulkTransfer(
                endpoint,
                bytes,
                offset,
                bytes.size - offset,
                ioTimeoutMs
            )
            if (written <= 0) throw IOException("USB PTP write failed at $offset/${bytes.size}")
            offset += written
        }

    }

    private fun startEventReader(connection: UsbDeviceConnection, endpoint: UsbEndpoint) {
        eventThread = Thread({
            var request: UsbRequest? = null
            try {
                request = UsbRequest()
                if (!request.initialize(connection, endpoint)) return@Thread
                val packetBytes = maxOf(512, endpoint.maxPacketSize.coerceAtLeast(64) * 4)
                while (running.get()) {
                    val buffer = ByteBuffer.allocate(packetBytes)
                    if (!request.queue(buffer)) break
                    val completed = runCatching { connection.requestWait(1200L) }.getOrNull()
                    if (!running.get()) break
                    if (completed !== request) continue
                    val count = buffer.position()
                    if (count < 12) continue
                    buffer.flip()
                    val bytes = ByteArray(count)
                    buffer.get(bytes)
                    parseEventContainer(bytes)?.let(onEvent)
                }
            } catch (_: Throwable) {
                // The command channel stays usable even when a body exposes no
                // working interrupt event endpoint; setting reads still occur via PTP.
            } finally {
                runCatching { request?.cancel() }
                runCatching { request?.close() }
            }
        }, "Sony-USB-PTP-Events").apply {
            isDaemon = true
            start()
        }
    }

    private fun parseEventContainer(bytes: ByteArray): SonyPtpClient.PtpEvent? {
        if (bytes.size < 12) return null
        val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val length = b.int
        val type = b.short.toInt() and 0xffff
        val code = b.short.toInt() and 0xffff
        val tx = b.int.toLong() and 0xffffffffL
        if (length < 12 || length > bytes.size || type != CONTAINER_EVENT) return null
        val count = (length - 12) / 4
        val params = IntArray(count) { b.int }
        return SonyPtpClient.PtpEvent(code, tx, params)
    }

    private data class UsbContainer(
        val type: Int,
        val code: Int,
        val transactionId: Int,
        val payload: ByteArray
    )

    /** Streaming reader so USB packet boundaries never have to align to PTP containers.
     *
     * Android UsbDeviceConnection.bulkTransfer() returns a negative value both for
     * real transport errors and ordinary read timeouts. A single -1 therefore must
     * not be treated as EOF. We read in short slices until one overall deadline,
     * preserving partial PTP bytes between USB transfers.
     */
    private class UsbEndpointReader(
        private val connection: UsbDeviceConnection,
        private val endpoint: UsbEndpoint,
        private val isStillAttached: () -> Boolean
    ) {
        private var pending = ByteArray(0)
        private var pendingOffset = 0

        fun reset() {
            pending = ByteArray(0)
            pendingOffset = 0
        }

        fun readContainer(timeoutMs: Int): UsbContainer {
            val deadlineNs = System.nanoTime() + timeoutMs.coerceAtLeast(250) * 1_000_000L
            val header = readExact(12, deadlineNs, "header")
            val h = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
            val length = h.int
            val type = h.short.toInt() and 0xffff
            val code = h.short.toInt() and 0xffff
            val tx = h.int
            if (length !in 12..MAX_CONTAINER_BYTES) {
                throw IOException("Bad USB PTP container length=$length")
            }
            val payload = if (length == 12) ByteArray(0) else {
                readExact(length - 12, deadlineNs, "payload")
            }
            return UsbContainer(type, code, tx, payload)
        }

        private fun readExact(length: Int, deadlineNs: Long, part: String): ByteArray {
            if (length == 0) return ByteArray(0)
            val output = ByteArray(length)
            var offset = 0
            var negativeReads = 0
            var zeroReads = 0

            while (offset < length) {
                val available = pending.size - pendingOffset
                if (available > 0) {
                    val take = minOf(available, length - offset)
                    System.arraycopy(pending, pendingOffset, output, offset, take)
                    pendingOffset += take
                    offset += take
                    if (pendingOffset >= pending.size) reset()
                    continue
                }

                if (!isStillAttached()) {
                    throw IOException("USB device detached while reading $part $offset/$length")
                }

                val remainingNs = deadlineNs - System.nanoTime()
                if (remainingNs <= 0L) {
                    throw IOException(
                        "USB PTP read timeout $part $offset/$length " +
                            "(-1=$negativeReads, zlp=$zeroReads)"
                    )
                }
                val remainingMs = ((remainingNs + 999_999L) / 1_000_000L).toInt().coerceAtLeast(1)
                val sliceMs = minOf(READ_SLICE_TIMEOUT_MS, remainingMs)
                val chunk = ByteArray(READ_CHUNK)
                val read = connection.bulkTransfer(endpoint, chunk, chunk.size, sliceMs)

                when {
                    read > 0 -> {
                        negativeReads = 0
                        zeroReads = 0
                        pending = if (read == chunk.size) chunk else chunk.copyOf(read)
                        pendingOffset = 0
                    }
                    read == 0 -> {
                        // A device may terminate a max-packet-aligned transfer with a
                        // ZLP. It carries no PTP bytes; continue to the next USB transfer.
                        zeroReads++
                    }
                    else -> {
                        // Android reports timeout as a negative bulkTransfer result.
                        // Keep waiting until the transaction deadline instead of
                        // converting the first timeout into EOF/disconnect.
                        negativeReads++
                        if (!isStillAttached()) {
                            throw IOException("USB device detached while waiting for $part")
                        }
                        if (negativeReads % 4 == 0) Thread.sleep(2)
                    }
                }
            }
            return output
        }
    }

}
