package com.example.sonymultilive

/** Camera metadata used by Sony Multiple Monitor. */
data class SonyCamera(
    val id: String,
    val friendlyName: String,
    val modelName: String,
    @Volatile var deviceName: String = "",
    val locationUrl: String,
    val host: String,
    val manufacturer: String = "",
    val macAddress: String = "",
    val function: String = "",
    val serverType: String = "",
    val firmwareVersion: String = "",
    val serialNumber: String = "",
    val serialVersion: String = "",
    val digitalImagingScpdUrl: String = "",
    val ptpRemoteControlAdvertised: Boolean = true,
    val ptpRemoteControlEnabled: Boolean = true,
    val ptpVersion: String = "",
    val ptpPairingNecessity: String = "",
    val transport: CameraTransport = CameraTransport.PTP_IP,
    val usbDeviceName: String = "",
    val usbDeviceId: Int = -1,
    val usbVendorId: Int = 0,
    val usbProductId: Int = 0
) {
    val displayName: String
        get() = deviceName.trim().ifBlank { friendlyName.trim().ifBlank { modelName.trim().ifBlank { "Sony Camera" } } }

    val endpointLabel: String
        get() = if (transport == CameraTransport.USB_PTP) "USB" else host

    val transportLabel: String
        get() = if (transport == CameraTransport.USB_PTP) "USB PTP" else "PTP/IP"

    val connectionDisplay: String
        get() = if (transport == CameraTransport.USB_PTP) "USB PTP" else "PTP/IP $host"

    companion object {
        fun manual(host: String): SonyCamera = SonyCamera(
            id = "manual:$host",
            friendlyName = "Sony camera ($host)",
            modelName = "Sony",
            locationUrl = "",
            host = host,
            ptpRemoteControlAdvertised = true,
            ptpRemoteControlEnabled = true
        )
    }
}
