# Sony Multiple Monitor currently uses the default Android shrinker rules.
# Keep this file so release builds can enable minification later without restructuring the project.
