plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.sonymultilive"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.sonymultilive"
        minSdk = 28
        targetSdk = 35
        versionCode = 10002
        versionName = "1.0.2"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

dependencies {
}
