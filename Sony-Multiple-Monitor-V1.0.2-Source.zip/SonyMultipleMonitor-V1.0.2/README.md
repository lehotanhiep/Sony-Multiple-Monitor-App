# Sony Multiple Monitor V1.0.2

Ứng dụng Android giám sát và điều khiển nhiều camera Sony qua Wi-Fi PTP/IP hoặc USB PTP. V1.0.2 tổng hợp các thay đổi từ V1.0.1 và các bản sửa đến FIX12.

## Phiên bản và cấu hình

| Mục | Giá trị |
| --- | --- |
| Tên app | Sony Multiple Monitor V1.0.2 |
| versionName | 1.0.2 |
| versionCode | 10002 |
| applicationId / namespace | com.example.sonymultilive |
| minSdk / targetSdk / compileSdk | 28 / 35 / 35 |
| Java | 17 |

Giữ applicationId để bản mới có thể nâng cấp app cũ nếu được ký bằng cùng khóa.

## Kết nối và bố cục camera

- Hỗ trợ tối đa 20 kết nối, gồm Wi-Fi PTP/IP, Sony USB PTP và đội camera dùng cả hai loại kết nối.
- SCAN tìm camera Wi-Fi/AP và USB đang gắn. Thao tác quét thêm giữ các session và khung hiện có; bỏ qua IP đang có transport hoặc đang kết nối trước bước đọc DD XML/quét cổng. MAC đã biết được loại khỏi kết quả tìm mới. SSDP vẫn gửi multicast chung trên mạng.
- Quét hotspot tự động bỏ qua host đã tìm thấy trong các chu kỳ trước. Discovery phục vụ reconnect loại trừ camera đang hoạt động.
- USB gắn khi app đang chạy được phát hiện tự động; app xin quyền USB trước khi kết nối nếu chưa được cấp.
- Mỗi IP/MAC Wi-Fi chỉ có một khung/session. Chuẩn hóa danh tính, xử lý alias xuất hiện muộn và ID discovery bị trùng. Các máy cùng model/tên không bị gộp chỉ vì giống tên.
- Ghi nhớ camera ở khung nào khi mở lại app, thay đổi thứ tự discovery hoặc reconnect. Ưu tiên MAC/serial đã biết; khi thiếu danh tính ổn định thì dùng endpoint. Giữ vị trí dành cho camera offline; hỗ trợ đổi vị trí và RESET ALL - AUTOMATIC.
- Nhãn camera ưu tiên Sony Device Name, tên responder/discovery, sau đó mới dùng model. Giảm đọc tên Wi-Fi mang tính thăm dò để không làm chậm khởi tạo.

### LIVE ON / OFF

Với 1–4 camera, LIVE ON hiển thị lưới camera. LIVE OFF dừng kéo JPEG nhưng giữ session điều khiển; vùng monitor chuyển thành các cột điều khiển ngang.

Với hơn 4 camera hoặc bố trí dùng khung vượt vị trí thứ tư, mặc định dùng CONTROL ONLY để hạn chế số luồng JPEG. LIVE selector cho phép bật Live View cho một camera được chọn. Trở về LIVE OFF giữ các session và hiển thị lại các cột điều khiển.

## Live View, RES và FPS

- RES HIGH/LOW đổi nguồn trên cùng session PTP/IP tại ranh giới giao dịch GetObject; không đóng/mở lại toàn bộ kết nối. Cập nhật cache D26A và prime lại FFFFC002 cho các lần đổi liên tiếp. USB giữ nguồn JPEG native của camera.
- Luồng decode giữ ảnh mới nhất, chia lượt xử lý giữa các camera và giới hạn hàng đợi để tránh tích tụ ảnh/đói render. Giới hạn pool decode tối đa 4 worker.
- Nguồn chậm được làm mượt bằng hòa trộn hai ảnh thực qua alpha ImageView ở nhịp mục tiêu 25 Hz. Nguồn nhanh được hiển thị ngay; thời gian hòa trộn tối đa 120 ms. Ảnh mới sau khoảng mất nguồn dài được hiển thị ngay.
- OSD chỉ hiển thị FPS hiển thị hiện tại; không hiển thị SRC. Đây là nhịp trình bày hình, không tăng FPS thực camera gửi và không đổi FPS ghi hình trên camera.
- Hòa trộn không dùng optical flow; chuyển động nhanh có thể có bóng kép. Nhịp thực tế phụ thuộc camera, mạng và tải điện thoại.

## REC và WB ALL CAM

### REC riêng từng camera

- REC/STOP gửi lệnh với cùng mốc thời gian monotonic để giảm lệch thời điểm giữa các camera. USB và PTP/IP dùng D2C8=2 để REC, D2C8=1 để STOP.
- Khung đỏ, dấu REC và bộ đếm thời gian theo trạng thái camera xác nhận. Lệnh được chấp nhận không tự tạo trạng thái đang ghi.
- Camera nào báo đang REC thì khung của camera đó chớp. Camera không báo REC thì không chớp; không yêu cầu tất cả camera cùng REC. Camera A dừng không làm camera B đang ghi ngừng chớp.
- Sau lệnh REC/STOP, mỗi session đọc xác nhận trạng thái D21D riêng, không phụ thuộc hoàn toàn sự kiện C203. Các lần thăm dò xác nhận cách nhau tối thiểu 700 ms trong cửa sổ 8 giây. Yêu cầu sự kiện bị throttle được giữ lại để đọc sau.
- Camera xác nhận STOP thì khung ngừng chớp. Nút REC chung chớp khi có ít nhất một camera xác nhận REC. Vẫn giữ ý định lệnh riêng để gửi STOP khi REC chưa được xác nhận.
- Camera không cung cấp trạng thái REC hợp lệ sẽ không chớp khung, dù đã nhận lệnh.

### WB ALL CAM

- Đọc descriptor WB mới và kiểm tra khả năng ghi riêng từng camera trước khi áp dụng AUTO, preset hoặc Kelvin.
- Với Kelvin, đổi sang chế độ Color Temperature trước rồi kiểm tra/ghi nhiệt độ màu.
- Xác nhận readback và báo kết quả từng camera, gồm máy từ chối, khóa hoặc không hỗ trợ giá trị; không bỏ qua âm thầm theo trạng thái UI cũ.

## Thao tác màn hình

- App dùng sensorLandscape: xoay được ngang thường và ngang ngược; không chọn hướng dọc.
- Giữ một khung đang hiển thị trong **2 giây** để phóng riêng camera đó thành một khung lớn.
- **Vuốt xuống** theo hướng dọc hơn 70dp để thoát phóng khung, trở lại bố cục trước đó. Vị trí camera đã lưu không đổi; phóng/thu không tạo hoặc đóng session camera.
- Di chuyển quá 14dp, thêm ngón tay, hủy thao tác hoặc đưa app xuống nền sẽ hủy bộ đếm giữ. Nhấc tay sau khi phóng không gửi thêm lệnh lấy nét.
- Chạm ảnh để lấy nét; chạm kép để bỏ marker và gửi Cancel Remote Touch Operation. Chạm header camera để mở bảng điều khiển; giữ 2 giây thay thế long-click cũ.
- Ngoài chế độ phóng khung, vuốt lên/xuống ẩn/hiện các thanh điều khiển. Chọn menu layout thoát chế độ phóng khung.

## Reconnect và đồng bộ trạng thái

- Rút ngắn warm-up khi đã có descriptor sử dụng được; retry khi camera Busy, dừng khi kênh khởi tạo timeout thay vì tiếp tục trên kênh không chắc chắn.
- Không restart generation đang kết nối. Thay đổi capability Wi-Fi không tự gây vòng lặp reconnect.
- Watchdog mất stream dùng ngưỡng 12 giây và giới hạn tần suất reconnect/discovery. Recovery định kỳ tránh subnet scan; quét đầy đủ dành cho quét chủ động hoặc phục hồi mạng.
- Đồng bộ cài đặt theo sự kiện C203, giới hạn đọc trạng thái động để giảm cạnh tranh với JPEG. Đọc xác nhận REC/STOP có cửa sổ riêng như mô tả trên.
- Sửa lỗi Kotlin `Expecting an expression` do điều kiện throttle thiếu `return` trong bản nền.

Các log SkJpegCodec/HWUI và cảnh báo vendor JPEG được gửi trước đây không đủ để kết luận nguyên nhân disconnect. Khi cần chẩn đoán, xem log SonyMultiLive và exception/timeout tại đúng thời điểm mất hình.

## Cấu trúc source và phần đã dọn

- `app/src/main/java/com/example/sonymultilive/`: UI, session và các lớp transport/discovery.
- `MainActivity.kt`: điều phối camera, bố cục, discovery, USB và thao tác phóng/thu khung.
- `CameraTileView.kt`, `RemoteCameraSettingColumnView.kt`: hiển thị camera và trạng thái REC riêng.
- `SonyCameraSession.kt`: lifecycle, cài đặt và xác nhận trạng thái của từng camera.
- `SonyPtpIpClient.kt`, `SonyUsbPtpClient.kt`, `SonyPtpLiveViewController.kt`: giao tiếp PTP và Live View.
- `CameraIdentity.kt`, `CameraSlotMemory.kt`: nhận diện camera và lưu vị trí.
- `FrameBlendClock.kt`, `CameraFrameGesture.kt`: nhịp hòa trộn và quyết định thao tác giữ/vuốt.
- `tools/`: kiểm tra hồi quy JVM/Python và các stub chỉ dùng cho test.

V1.0.2 bỏ các biến/hàm FPS/profile của tile không còn được sử dụng, bỏ cập nhật UI từ thống kê nguồn không hiển thị, gộp ghi chú FIX vào README này và loại cache/build khỏi gói source. Giữ các test và transport hiện tại. `.gitignore` loại cấu hình máy cá nhân, output build và cache Python.

## Build và kiểm tra

Mở thư mục dự án bằng Android Studio với JDK 17 và Android SDK tương ứng. `local.properties.example` là mẫu cấu hình SDK; cấu hình đường dẫn SDK của máy nếu cần.

Gói source kế thừa cấu hình Gradle hiện có. **Chưa kèm `gradle-wrapper.jar`**; để chạy `gradlew`, cần khôi phục wrapper hoặc dùng Gradle tương ứng trên máy phát triển. Đây là gói source, không phải APK đã build.

Để chạy bộ kiểm tra Python, cần Python, JDK, Kotlin compiler; đặt `KOTLINC` và `KOTLIN_STDLIB` tới compiler và kotlin-stdlib.jar trên máy:

```bash
python tools/ResLowRenderSelfTest.py
python tools/RunReconnectSelfTests.py
python tools/RunCameraIdentitySelfTests.py
python tools/RunSmoothDiscoverySelfTests.py
python tools/RunConfirmedRecUiSelfTest.py
python tools/RunPerCameraBlinkSelfTest.py
python tools/RunFrameExpandSelfTests.py
```

`RunReconnectSelfTests.py` gồm kiểm tra WB và xác nhận REC riêng từng camera. Không đưa `tools/DiscoveryExclusionStubs.kt` hoặc `tools/jvm-wb-stubs/` vào source của app.

Kiểm tra phát hành V1.0.2: biên dịch toàn bộ Kotlin với các lớp Android API 35; chạy các runner trên; kiểm tra XML, định danh phiên bản và ZIP. Các kiểm tra JVM dùng camera/UI giả lập. Chưa build APK hoặc xác minh toàn bộ hiệu năng và hành vi camera thật trong môi trường này.
