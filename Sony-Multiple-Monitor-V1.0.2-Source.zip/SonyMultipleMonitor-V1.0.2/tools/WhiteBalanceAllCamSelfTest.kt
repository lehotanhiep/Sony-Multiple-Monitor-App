import android.content.Context
import com.example.sonymultilive.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executor

private fun u16(v: Int) = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(v.toShort()).array()
private fun u64(v: Long) = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(v).array()

private class WbCamera(
    val modeCode: Int,
    var mode: Int = 2,
    var kelvin: Int = 3200,
    var rejectMode: Boolean = false,
    var staleReadback: Boolean = false,
    var rejectRead: Boolean = false,
    var modeWritable: Boolean = true,
    var hasColorMode: Boolean = true
) : SonyPtpClient {
    val writes = mutableListOf<Pair<Int, Int>>()
    var reads = 0
    override fun connect(timeoutMs: Int) {}
    override fun openSession(sessionId: Int) = error("WB must not open a session")
    override fun close() = error("WB must not close transport")
    override fun transaction(opCode: Int, params: IntArray, dataOut: ByteArray?): SonyPtpClient.PtpResult {
        val data = when (opCode) {
            0x9209 -> {
                reads++
                if (rejectRead) return SonyPtpClient.PtpResult(0x2019, intArrayOf(), byteArrayOf())
                val modes = if (hasColorMode) listOf(2, 4, 0x8012) else listOf(2, 4)
                val wb = u16(modeCode) + u16(4) + byteArrayOf(0, if (modeWritable) 1 else 0) +
                    u16(2) + u16(mode) + byteArrayOf(2) + u16(modes.size) + modes.flatMap { u16(it).toList() }.toByteArray()
                // Color Temperature is disabled in AUTO, enabled only AFTER the mode write.
                val temp = u16(0xD20F) + u16(4) + byteArrayOf(0, if (mode == 0x8012) 1 else 0) +
                    u16(3200) + u16(kelvin) + byteArrayOf(1) + u16(2500) + u16(9900) + u16(100)
                u64(2) + wb + temp
            }
            0x9205 -> {
                val code = params[0]
                val target = ByteBuffer.wrap(dataOut!!).order(ByteOrder.LITTLE_ENDIAN).short.toInt() and 0xffff
                if (code == modeCode && rejectMode) return SonyPtpClient.PtpResult(0x200f, intArrayOf(), byteArrayOf())
                check(code == modeCode || code == 0xD20F)
                if (code == 0xD20F) check(mode == 0x8012) { "Kelvin sent while still in AUTO" }
                writes.add(code to target)
                if (!staleReadback) {
                    if (code == modeCode) mode = target else kelvin = target
                }
                byteArrayOf()
            }
            else -> error("WB unexpected opcode: ${opCode.toString(16)}")
        }
        return SonyPtpClient.PtpResult(0x2001, intArrayOf(), data)
    }
}

private fun session(id: String, camera: WbCamera): SonyCameraSession {
    val s = SonyCameraSession(Context(), SonyCamera.manual(id), Executor { it.run() }, {}, {}, {})
    val ctrl = SonyPtpLiveViewController(camera) {}
    val props = ctrl.refreshExtDevicePropInfo()!!
    // Intentionally stale UI flags: each command must read the real camera again.
    val stale = props.mapValues { (_, p) -> p.copy(enabled = 0) }
    SonyCameraSession::class.java.getDeclaredField("controller").apply { isAccessible = true }.set(s, ctrl)
    SonyCameraSession::class.java.getDeclaredField("propertyCache").apply { isAccessible = true }.set(s, stale)
    return s
}

private fun expect(s: SonyCameraSession, action: (SonyCameraSession, (Boolean, String) -> Unit) -> Unit, ok: Boolean) {
    var callbacks = 0
    action(s) { applied, reason -> callbacks++; check(applied == ok) { "Expected ok=$ok, got $applied: $reason" } }
    check(callbacks == 1)
}

fun main() {
    val cameras = listOf(WbCamera(0x5005), WbCamera(0xD00C))
    val sessions = cameras.mapIndexed { i, c -> session("camera-$i", c) }
    for (s in sessions) expect(s, { cam, done -> cam.setWhiteBalanceTemperature(5600, done) }, true)
    check(cameras.all { it.mode == 0x8012 && it.kelvin == 5600 })
    check(cameras.all { it.writes.map { w -> w.first } == listOf(it.modeCode, 0xD20F) })
    for (s in sessions) expect(s, { cam, done -> cam.setWhiteBalanceAuto(done) }, true)
    check(cameras.all { it.mode == 2 })
    for (s in sessions) expect(s, { cam, done -> cam.setWhiteBalancePreset(4, done) }, true)
    check(cameras.all { it.mode == 4 })

    val rejected = WbCamera(0x5005, rejectMode = true)
    expect(session("reject", rejected), { cam, done -> cam.setWhiteBalanceTemperature(5600, done) }, false)
    check(rejected.writes.isEmpty())
    val stale = WbCamera(0x5005, staleReadback = true)
    expect(session("stale", stale), { cam, done -> cam.setWhiteBalancePreset(4, done) }, false)
    val locked = WbCamera(0x5005, modeWritable = false)
    expect(session("locked", locked), { cam, done -> cam.setWhiteBalanceAuto(done) }, true) // already AUTO
    expect(session("locked2", locked), { cam, done -> cam.setWhiteBalancePreset(4, done) }, false)
    val unsupported = WbCamera(0x5005, hasColorMode = false)
    expect(session("unsupported", unsupported), { cam, done -> cam.setWhiteBalanceTemperature(5600, done) }, false)
    val invalid = WbCamera(0x5005, mode = 0x8012)
    expect(session("invalid", invalid), { cam, done -> cam.setWhiteBalanceTemperature(5650, done) }, false)
    check(invalid.writes.isEmpty())
    val noRead = WbCamera(0x5005)
    val noReadSession = session("no-read", noRead)
    noRead.rejectRead = true
    expect(noReadSession, { cam, done -> cam.setWhiteBalanceAuto(done) }, false)
    println("WB ALL CAM SELF-TEST PASS: mixed WB properties, AUTO/PRESET/Kelvin, disabled D20F in AWB, stale UI flags, rejection/lock/range/readback errors, exactly one callback per camera")
}
