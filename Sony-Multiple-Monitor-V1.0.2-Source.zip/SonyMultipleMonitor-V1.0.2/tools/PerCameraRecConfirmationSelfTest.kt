import android.content.Context
import com.example.sonymultilive.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

private class RecCamera(var active: Boolean, val reject: Boolean = false) : SonyPtpClient {
    var reads = 0
    override fun connect(timeoutMs: Int) {}
    override fun openSession(sessionId: Int) = error("must preserve session")
    override fun close() = error("must preserve transport")
    override fun transaction(opCode: Int, params: IntArray, dataOut: ByteArray?): SonyPtpClient.PtpResult {
        if (opCode == 0x9207) return SonyPtpClient.PtpResult(if (reject) 0x200f else 0x2001, intArrayOf(), byteArrayOf())
        check(opCode == 0x9209) { "unexpected ${opCode.toString(16)}" }
        reads++
        val table = ByteBuffer.allocate(17).order(ByteOrder.LITTLE_ENDIAN)
            .putLong(1).putShort(0xD21D.toShort()).putShort(2).put(0).put(1).put(0)
            .put(if (active) 1.toByte() else 0.toByte()).put(0).array()
        return SonyPtpClient.PtpResult(0x2001, intArrayOf(), table)
    }
}
private fun field(s: SonyCameraSession, name: String): Any? = SonyCameraSession::class.java.getDeclaredField(name).apply { isAccessible=true }.get(s)
private fun make(id: String, camera: RecCamera): Pair<SonyCameraSession,SonyPtpLiveViewController> {
    val s = SonyCameraSession(Context(), SonyCamera.manual(id), Executor { it.run() }, {}, {}, {})
    val ctrl = SonyPtpLiveViewController(camera) {}
    SonyCameraSession::class.java.getDeclaredField("controller").apply { isAccessible=true }.set(s, ctrl)
    (field(s,"stopped") as AtomicBoolean).set(false)
    (field(s,"generation") as AtomicInteger).set(1)
    return s to ctrl
}
private fun sync(pair: Pair<SonyCameraSession,SonyPtpLiveViewController>) {
    SonyCameraSession::class.java.getDeclaredMethod("maybeSyncOneChangedProperty",SonyPtpLiveViewController::class.java, Int::class.javaPrimitiveType).apply { isAccessible=true }.invoke(pair.first,pair.second,1)
}
fun main() {
    val camA=RecCamera(true); val camB=RecCamera(false); val camC=RecCamera(true)
    val a=make("a",camA); val b=make("b",camB); val c=make("c",camC)
    listOf(a,b,c).forEach { it.first.setMovieRecordingAt(true,0L,1) }
    check(listOf(a,b,c).none { it.first.isMovieRecording() }) // Command ACK is not REC.
    listOf(a,b,c).forEach(::sync) // No event socket/C203 is supplied.
    check(a.first.isMovieRecording() && !b.first.isMovieRecording() && c.first.isMovieRecording())
    check(camA.reads==1 && camB.reads==1 && camC.reads==1)
    // B remains non-recording and emits no event: it cannot turn A/C off.
    sync(b)
    check(a.first.isMovieRecording() && c.first.isMovieRecording())
    camA.active=false; a.first.setMovieRecordingAt(false,0L,1)
    check(a.first.isMovieRecording()) // Still recording until confirmed STOP.
    sync(a) // Recent REC read throttles immediate STOP read.
    check(a.first.isMovieRecording())
    check((field(a.first,"queuedPropertyCodes") as Set<*>).contains(0xD21D))
    (field(a.first,"lastC203BulkSnapshotMs") as AtomicLong).set(0)
    (field(a.first,"lastAutoPropertyReadMs") as AtomicLong).set(0)
    sync(a)
    check(!a.first.isMovieRecording() && c.first.isMovieRecording())
    // Confirmation window expires without an endless full-property polling loop.
    val before=camB.reads
    SonyCameraSession::class.java.getDeclaredField("pendingMovieRecordingRequestAtMs").apply { isAccessible=true }.setLong(b.first, android.os.SystemClock.elapsedRealtime()-9_000L)
    (field(b.first,"lastRecordingConfirmationProbeMs") as AtomicLong).set(0)
    sync(b); check(camB.reads==before)
    println("PER CAMERA REC PASS: A/C REC, B idle; independent confirmation without C203, independent STOP and bounded reads")
}
