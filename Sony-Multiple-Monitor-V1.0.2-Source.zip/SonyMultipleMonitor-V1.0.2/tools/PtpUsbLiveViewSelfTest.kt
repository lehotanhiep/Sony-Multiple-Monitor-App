import com.example.sonymultilive.SonyPtpClient
import com.example.sonymultilive.SonyPtpLiveViewController
import java.nio.ByteBuffer
import java.nio.ByteOrder

private class FakeUsbPtp : SonyPtpClient {
    val ops = mutableListOf<Int>()
    val sdioPhases = mutableListOf<Int>()
    val extInfoParams = mutableListOf<List<Int>>()
    val getAllParams = mutableListOf<List<Int>>()

    override fun connect(timeoutMs: Int) {}

    override fun openSession(sessionId: Int): SonyPtpClient.PtpResult {
        check(sessionId == 1)
        ops += 0x1002
        return SonyPtpClient.PtpResult(0x2001, intArrayOf(), byteArrayOf())
    }

    override fun transaction(
        opCode: Int,
        params: IntArray,
        dataOut: ByteArray?
    ): SonyPtpClient.PtpResult {
        ops += opCode
        return when (opCode) {
            0x1001 -> SonyPtpClient.PtpResult(0x2001, intArrayOf(), byteArrayOf())
            0x9201 -> {
                sdioPhases += params.firstOrNull() ?: -1
                SonyPtpClient.PtpResult(0x2001, intArrayOf(), ByteArray(0))
            }
            0x9202 -> {
                extInfoParams += params.toList()
                check(params.contentEquals(intArrayOf(0x012C, 1))) {
                    "unexpected USB ExtDeviceInfo params=${params.toList()}"
                }
                val b = byteArrayOf(
                    0x2c, 0x01,             // returned version 0x012C
                    0, 0, 0, 0,             // supported property count
                    0, 0, 0, 0              // supported control count
                )
                SonyPtpClient.PtpResult(0x2001, intArrayOf(), b)
            }
            0x9209 -> {
                getAllParams += params.toList()
                check(params.contentEquals(intArrayOf(1))) {
                    "PTP-V3 USB 0x9209 must use parameter 1: ${params.toList()}"
                }
                SonyPtpClient.PtpResult(0x2001, intArrayOf(), byteArrayOf())
            }
            0x1004 -> error("USB GetStorageIDs must not block first Live View startup")
            0x1008 -> error("USB Live View must not require GetObjectInfo(FFFFC002)")
            0x1009 -> {
                val jpeg = byteArrayOf(
                    0xff.toByte(), 0xd8.toByte(), 0x01, 0x02, 0xff.toByte(), 0xd9.toByte()
                )
                val wrapper = ByteBuffer.allocate(8 + jpeg.size)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .putInt(8)
                    .putInt(jpeg.size)
                    .put(jpeg)
                    .array()
                SonyPtpClient.PtpResult(0x2001, intArrayOf(), wrapper)
            }
            else -> error("unexpected op 0x${opCode.toString(16)}")
        }
    }

    override fun close() {}
}

fun main() {
    val client = FakeUsbPtp()
    val log = mutableListOf<String>()
    val ctrl = SonyPtpLiveViewController(client) { log += it }

    check(ctrl.initialize(usbTransport = true) == SonyPtpLiveViewController.Protocol.PTP3_SDIO)
    check(client.sdioPhases == listOf(1, 2)) {
        "CrCmd V3 USB startup must use SDIO phases 1/2 only: ${client.sdioPhases}"
    }
    check(client.extInfoParams == listOf(listOf(0x012C, 1)))
    check(client.getAllParams.isEmpty()) { "0x9209 must be deferred until after first frame" }
    check(client.ops == listOf(0x1002, 0x9201, 0x9201, 0x9202)) {
        "unexpected USB startup ops: ${client.ops.map { "0x%04X".format(it) }}"
    }
    check(log.any { it.startsWith("USB CRCMD V3 · OPEN SESSION") })
    check(log.none { it.startsWith("USB CRCMD V3 · SDIO 3") })
    check(log.any { it.startsWith("USB CRCMD V3 · REMOTE READY") })

    val before = client.ops.size
    val jpg = ctrl.getLiveViewJpegUsb()
    check(jpg.contentEquals(byteArrayOf(0xff.toByte(), 0xd8.toByte(), 0x01, 0x02, 0xff.toByte(), 0xd9.toByte())))
    val frameOps = client.ops.drop(before)
    check(frameOps == listOf(0x1009)) { "bad USB frame order: $frameOps" }

    // Properties are intentionally after first image and must retain the PTP-V3 param=1 form.
    ctrl.getAllExtDevicePropInfo()
    check(client.getAllParams == listOf(listOf(1)))
    check(client.ops.last() == 0x9209)

    println("USB CrCmd V3 self-test OK: TX1 OpenSession -> SDIO 1/2 -> ExtInfo(012C,1) -> wrapped FFFFC002 first -> 9209(1); phase3 not used at startup")
}
