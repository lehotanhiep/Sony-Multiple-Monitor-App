"""Run pure identity/placement tests and actual MainActivity identity flow with UI stubs."""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from ResLowRenderSelfTest import method

root = Path(__file__).resolve().parents[1]
java = root / 'app/src/main/java/com/example/sonymultilive'
source = (java / 'MainActivity.kt').read_text()
compiler = os.environ.get('KOTLINC', 'kotlinc')
compiler_path = Path(shutil.which(compiler) or compiler).resolve()
stdlib = os.environ.get('KOTLIN_STDLIB', str(compiler_path.parent.parent / 'lib/kotlin-stdlib.jar'))
production = [java / (n + '.kt') for n in ['SonyCamera', 'CameraTransport', 'CameraIdentity', 'CameraSlotMemory']]
add = method(source, 'private fun addCamera(incomingCamera: SonyCamera')
# Execute the production decisions before Android view creation. Only the actual
# view/session construction is stubbed, so no Android service/socket is required.
add = add[:add.index('        val tile = CameraTileView')] + '''
        tiles[camera.id] = Tile(camera)
        sessions[camera.id] = Session()
        remoteColumns[camera.id] = Any()
        starts++
    }
'''
helpers = '\n'.join(method(source, signature) for signature in [
    'private fun findExistingCamera(identity: CameraIdentity)',
    'private fun collapseDuplicateCameras(survivorId: String',
    'private fun replaceDisconnectedCamera(oldId: String'])
stubs = r'''
import com.example.sonymultilive.*
class Tile(val camera: SonyCamera) {
    fun setLiveViewEnabled(enabled: Boolean) {}
    fun isStreamDisconnected(ms: Long) = false
}
class Session {
    var closed = false
    fun close() { closed = true }
    fun setLiveViewEnabled(enabled: Boolean) {}
}
class Harness(encoded: String = "") {
    val tiles = linkedMapOf<String, Tile>()
    val sessions = linkedMapOf<String, Session>()
    val remoteColumns = linkedMapOf<String, Any>()
    val activeCameraIdentities = HashMap<String, CameraIdentity>()
    val cameraSlotMemory = CameraSlotMemory().also { it.load(encoded) }
    val slotAssignments = arrayOfNulls<String>(20)
    val maxCameras = 20
    var selectedLiveCameraId: String? = null
    var starts = 0
    var saved = encoded
    fun saveCameraSlotMemory() { saved = cameraSlotMemory.encode() }
    fun rebuildGrid() {}
    fun selectLiveCamera(id: String?) { selectedLiveCameraId = id }
    fun add(c: SonyCamera) { addCamera(c) }
'''
checks = r'''
}
fun cam(id: String, ip: String, mac: String = "") = SonyCamera(id, "ZV-E10M2", "ZV-E10M2", locationUrl = "", host = ip, macAddress = mac)
fun main() {
    val h = Harness()
    h.add(cam("uuid1", "172.31.104.238"))
    h.add(cam("manual:172.31.104.238", "172.31.104.238", "AA:BB:CC:DD:EE:01"))
    check(h.tiles.size == 1 && h.sessions.size == 1 && h.starts == 1)
    val first = h.sessions.values.single()
    h.add(cam("uuid-changed", "172.31.104.99", "aabb.ccdd.ee01"))
    check(first.closed)
    check(h.tiles.size == 1 && h.sessions.size == 1 && h.starts == 2)
    check(h.slotAssignments[0] == h.tiles.keys.single())
    h.add(cam("another-same-model", "172.31.104.22", "AA:BB:CC:DD:EE:02"))
    check(h.tiles.size == 2)
    val restored = Harness(h.saved)
    restored.add(cam("another-new-id", "172.31.104.22", "AA:BB:CC:DD:EE:02"))
    check(restored.slotAssignments[1] == restored.tiles.keys.single())
    restored.add(cam("first-new-id", "172.31.104.111", "AA:BB:CC:DD:EE:01"))
    check(restored.slotAssignments[0] == "first-new-id")

    val bridge = Harness()
    bridge.add(cam("ip-only", "10.0.0.1"))
    bridge.add(cam("known-mac", "10.0.0.2", "AA:BB:CC:DD:EE:03"))
    val old = bridge.sessions.values.toList()
    bridge.add(cam("enriched", "10.0.0.1", "AA:BB:CC:DD:EE:03"))
    check(bridge.tiles.size == 1 && bridge.sessions.size == 1)
    check(old.all { it.closed })
    check(bridge.slotAssignments[1] == bridge.tiles.keys.single())
    check(bridge.slotAssignments[0] == null)

    val badId = Harness()
    badId.add(cam("shared-udn", "10.0.0.10"))
    badId.add(cam("shared-udn", "10.0.0.11"))
    check(badId.tiles.size == 2 && badId.sessions.size == 2)
    badId.add(cam("shared-udn", "10.0.0.11"))
    check(badId.tiles.size == 2 && badId.starts == 2)
    println("MAIN IDENTITY FLOW PASS: duplicate IP/MAC creates one frame/session, DHCP closes old session, late MAC collapses duplicates, reopen restores slots in reverse discovery, bad UDN does not merge different endpoints")
}
'''
with tempfile.TemporaryDirectory() as temp:
    for name, extra in [('CameraIdentitySlotsSelfTest', [root / 'tools/CameraIdentitySlotsSelfTest.kt']),
                        ('MainIdentityHarness', [])]:
        if not extra:
            kt = Path(temp) / (name + '.kt')
            kt.write_text(stubs + add + helpers + checks)
            extra = [kt, root / 'tools/jvm-wb-stubs/AndroidLogStub.kt']
        jar = str(Path(temp) / (name + '.jar'))
        subprocess.run([compiler, '-nowarn', '-no-stdlib', '-no-reflect', '-classpath', stdlib,
                        '-d', jar] + [str(p) for p in production + extra], check=True)
        subprocess.run(['java', '-cp', jar + os.pathsep + stdlib, name + 'Kt'], check=True)
