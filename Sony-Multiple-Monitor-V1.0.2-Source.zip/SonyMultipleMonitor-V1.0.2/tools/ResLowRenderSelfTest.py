"""Run the production decode/render methods with deterministic JVM bitmap stubs.
Requires kotlinc and java on PATH (or KOTLINC environment override).
No Android device, network, or project files are modified by this test.
"""
import os
from pathlib import Path
import subprocess
import shutil
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'app/src/main/java/com/example/sonymultilive/CameraTileView.kt'


def method(source, signature):
    start = source.index(signature)
    brace = source.index('{', start)
    depth = 0
    for i in range(brace, len(source)):
        if source[i] == '{':
            depth += 1
        elif source[i] == '}':
            depth -= 1
            if depth == 0:
                return source[start:i + 1]
    raise AssertionError(f'Unclosed method: {signature}')


STUBS = r'''
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.Executor

object SystemClock { fun elapsedRealtime() = 1000L }
class Bitmap(val width: Int, val height: Int) {
    enum class Config { RGB_565, ARGB_8888 }
    var isRecycled = false
    fun recycle() { check(!isRecycled); isRecycled = true }
    companion object {
        fun createScaledBitmap(b: Bitmap, w: Int, h: Int, filter: Boolean): Bitmap {
            check(!b.isRecycled); return Bitmap(w, h)
        }
    }
}
object BitmapFactory {
    class Options {
        var inPreferredConfig = Bitmap.Config.RGB_565
        var inMutable = false
        var inSampleSize = 1
    }
    var decoded = 0
    var afterDecode: () -> Unit = {}
    fun decodeByteArray(b: ByteArray, offset: Int, length: Int, options: Options): Bitmap? {
        decoded++
        afterDecode()
        return Bitmap(1024, 576)
    }
}
object FalseColorPalette {
    const val OFF = 0
    fun process(b: Bitmap, mode: Int) = b
}
class Ui {
    val queue = java.util.ArrayDeque<() -> Unit>()
    fun post(block: () -> Unit) { queue.add(block) }
    fun postAtFrontOfQueue(block: () -> Unit) { queue.addFirst(block) }
    fun drain() { while (!queue.isEmpty()) queue.removeFirst()() }
}
class Histogram { fun updateFrom(b: Bitmap) {} }
class Harness {
    val latestJpeg = AtomicReference<ByteArray?>(null)
    val latestBitmap = AtomicReference<Bitmap?>(null)
    val decodeRunning = AtomicBoolean(false)
    val renderPosted = AtomicBoolean(false)
    val droppedFrames = AtomicInteger(0)
    val tasks = java.util.ArrayDeque<Runnable>()
    val decodeExecutor = Executor { tasks.add(it) }
    val ui = Ui()
    val histogramView = Histogram()
    var histogramVisible = false
    var lastHistogramMs = 0L
    var falseColorMode = 0
    var decodeSampleSize = 1
    var sourceWidth = 0
    var sourceHeight = 0
    private data class RenderSize(val width: Int, val height: Int)
    private var renderSize = RenderSize(640, 360)
    // Also allow running this test against the earlier source.
    var renderWidth = 640
    var renderHeight = 360
    var presented = 0
    var outputWidth = 0
    fun presentBitmap(b: Bitmap) {
        check(!b.isRecycled)
        presented++
        outputWidth = b.width
    }
    fun run() {
        BitmapFactory.decoded = 0
        BitmapFactory.afterDecode = {
            // A newer JPEG ALWAYS arrives during decode until the burst ends.
            // The earlier code dropped every completed frame in this condition.
            ui.drain()
            if (BitmapFactory.decoded == 32) {
                check(presented > 0) { "No frame presented while JPEGs keep arriving" }
            }
            latestJpeg.set(if (BitmapFactory.decoded <= 64) byteArrayOf(1) else null)
        }
        latestJpeg.set(byteArrayOf(1))
        scheduleDecode()
        while (!tasks.isEmpty()) {
            val before = BitmapFactory.decoded
            tasks.removeFirst().run()
            check(BitmapFactory.decoded - before <= 1) { "One camera monopolized the shared decoder" }
        }
        ui.drain()
        check(BitmapFactory.decoded == 65)
        check(presented >= 1) { "Decoder starved presentation under continuous arrivals" }
        check(outputWidth == 640) { "RES LOW was not rendered at 640" }
        check(latestJpeg.get() == null && latestBitmap.get() == null)
        check(!decodeRunning.get() && !renderPosted.get())
    }
'''


def main():
    source = SOURCE.read_text()
    methods = '\n'.join(method(source, name) for name in (
        'private fun scheduleDecode()', 'private fun scheduleRender()'))
    # Also guard the user-intent race in the RES setter.
    session = (SOURCE.parent / 'SonyCameraSession.kt').read_text()
    setter = method(session, 'fun setLowResolutionMode(low: Boolean)')
    assert 'liveViewRequested =' not in setter
    assert 'executor.execute' not in setter and 'startPtpSession()' not in setter
    with tempfile.TemporaryDirectory() as temp:
        kt = Path(temp) / 'ResLowRenderHarness.kt'
        kt.write_text(STUBS + methods + '\n}\nfun main() { Harness().run(); println("RES LOW RENDER SELF-TEST PASS: no starvation, fair decode tasks, bounded handoff, 640 output; RES preserves LIVE intent") }\n')
        jar = Path(temp) / 'test.jar'
        compiler = os.environ.get('KOTLINC', 'kotlinc')
        compiler_path = Path(shutil.which(compiler) or compiler).resolve()
        stdlib = os.environ.get('KOTLIN_STDLIB', str(compiler_path.parent.parent / 'lib/kotlin-stdlib.jar'))
        subprocess.run([compiler, str(kt), '-no-stdlib', '-no-reflect', '-classpath', stdlib, '-d', str(jar)], check=True)
        subprocess.run(['java', '-cp', str(jar) + os.pathsep + stdlib, 'ResLowRenderHarnessKt'], check=True)


if __name__ == '__main__':
    main()
