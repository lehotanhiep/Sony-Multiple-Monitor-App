import java.io.File

fun main() {
    val source = File("app/src/main/java/com/example/sonymultilive/SonyCameraSession.kt").readText()

    fun blockAfter(signature: String): String {
        val start = source.indexOf(signature)
        check(start >= 0) { "missing $signature" }
        val brace = source.indexOf('{', start)
        check(brace >= 0)
        var depth = 0
        for (i in brace until source.length) {
            when (source[i]) {
                '{' -> depth++
                '}' -> {
                    depth--
                    if (depth == 0) return source.substring(brace + 1, i)
                }
            }
        }
        error("unterminated block for $signature")
    }

    val toggle = blockAfter("fun setLiveViewEnabled(enabled: Boolean)")
    check("startPtpSession()" !in toggle) { "LIVE toggle must not reopen PTP" }
    check("closeTransport()" !in toggle) { "LIVE toggle must not close PTP" }
    check("liveViewRequested = enabled" in toggle)

    val modeLoop = blockAfter("private fun remoteModeLoop")
    check("controlOnlyLoop(ctrl, myGeneration)" in modeLoop)
    check("streamFrames(ctrl, myGeneration, sourceHigh)" in modeLoop)
    check("startPtpSession()" !in modeLoop) { "mode switch must remain in the same session" }
    check("closeTransport()" !in modeLoop) { "mode switch must remain in the same session" }
    check("SAME SESSION" in modeLoop || "SESSION KEPT" in modeLoop)

    val stream = blockAfter("private fun streamFrames")
    check("liveViewRequested" in stream) { "stream loop must stop when LIVE OFF is requested" }
    check("!playbackRequested" in stream)

    val control = blockAfter("private fun controlOnlyLoop")
    check("!liveViewRequested" in control) { "control loop must stay active only while LIVE OFF" }

    println("LIVE OFF SESSION SELF-TEST PASS: LIVE toggle stops/starts FFFFC002 without reopening or closing PTP")
}
