import com.example.sonymultilive.*

private fun camera(id: String, ip: String, mac: String = "", serial: String = "") =
    SonyCamera(id, "ZV-E10M2", "ZV-E10M2", locationUrl = "", host = ip, macAddress = mac, serialNumber = serial)

fun main() {
    val a = CameraIdentity.of(camera("uuid-a", "172.31.104.238", "AA:BB:CC:DD:EE:01"))
    val alias = CameraIdentity.of(camera("manual:172.31.104.238", "http://172.31.104.238:15740/", "aa-bb-cc-dd-ee-01"))
    check(a.sameEndpoint(alias))
    check(a.mac == alias.mac && a.ip == alias.ip)
    val moved = CameraIdentity.of(camera("new-uuid", "172.31.104.99", "aabb.ccdd.ee01"))
    check(a.sameEndpoint(moved))
    val b = CameraIdentity.of(camera("uuid-b", "172.31.104.22", "AA:BB:CC:DD:EE:02"))
    check(!a.sameEndpoint(b)) // Same model/name is not evidence of identity.
    val reusedIp = CameraIdentity.of(camera("uuid-c", a.ip, b.mac))
    check(a.sameEndpoint(reusedIp)) // One active frame per endpoint, even after DHCP reuse.
    check(!a.matchesSaved(reusedIp)) // Do not give another physical body A's remembered slot.
    check(!CameraIdentity.of(camera("shared-bad-uuid", "10.0.0.1")).sameEndpoint(
        CameraIdentity.of(camera("shared-bad-uuid", "10.0.0.2"))))
    check(CameraIdentity.normalizeIp("010.000.001.022") == "10.0.1.22")
    check(CameraIdentity.normalizeMac("00:00:00:00:00:00").isEmpty())
    check(CameraIdentity.normalizeMac("not a MAC").isEmpty())

    val memory = CameraSlotMemory()
    memory.remember(3, a)
    memory.remember(0, b)
    val reopened = CameraSlotMemory().also { it.load(memory.encode()) }
    // Discovery order changes, MAC formatting changes, DHCP changes: same physical slots.
    check(reopened.find(b) == 0)
    check(reopened.find(alias) == 3)
    check(reopened.find(moved) == 3)
    check(reopened.isReserved(3)) // Offline A remains reserved while B comes back first.
    reopened.remember(3, moved)
    reopened.remember(0, moved) // Explicit move swaps B to A's old frame.
    check(reopened.find(moved) == 0 && reopened.find(b) == 3)
    val secondRestart = CameraSlotMemory().also { it.load(reopened.encode()) }
    check(secondRestart.find(moved) == 0 && secondRestart.find(b) == 3)
    secondRestart.forget(3)
    check(secondRestart.find(b) == -1)
    secondRestart.clear()
    check((0 until 20).none { secondRestart.isReserved(it) })

    // Late MAC information links an IP-only observation to a saved body.
    val late = CameraSlotMemory()
    val ipOnly = CameraIdentity.of(camera("manual-ip", moved.ip))
    late.remember(1, a)
    late.remember(2, ipOnly)
    check(late.find(moved) == 1) // Strong MAC beats a weak IP reservation.
    late.remember(1, moved)
    check(!late.isReserved(2))
    val restoredLate = CameraSlotMemory().also { it.load(late.encode()) }
    check(restoredLate.find(moved) == 1)
    check((0 until 20).count { restoredLate.isReserved(it) } == 1)

    val usb = CameraIdentity.of(camera("usb-one", "").copy(transport = CameraTransport.USB_PTP, usbDeviceName = "/dev/bus/usb/001/001", serialNumber = "USB123"))
    val reattached = CameraIdentity.of(camera("usb-two", "").copy(transport = CameraTransport.USB_PTP, usbDeviceName = "/dev/bus/usb/001/002", serialNumber = "USB123"))
    check(usb.sameEndpoint(reattached))
    val usbMemory = CameraSlotMemory().also { it.remember(19, usb) }
    check(CameraSlotMemory().also { it.load(usbMemory.encode()) }.find(reattached) == 19)
    check(!usb.sameEndpoint(a))
    println("CAMERA IDENTITY/SLOTS PASS: IP/MAC aliases, no model merging, DHCP, late MAC, disk roundtrip/reverse discovery, slot swap/offline reservation/reset, USB serial")
}
