import com.example.sonymultilive.*
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.nio.ByteOrder

private class StartupTimeoutCamera : SonyPtpClient {
    var readinessCalls = 0
    override fun connect(timeoutMs: Int) {}
    override fun openSession(sessionId: Int) = result()
    override fun close() {}
    private fun result(data: ByteArray = byteArrayOf()) = SonyPtpClient.PtpResult(0x2001, intArrayOf(), data)
    override fun transaction(opCode: Int, params: IntArray, dataOut: ByteArray?): SonyPtpClient.PtpResult {
        if (opCode == 0x9209) { readinessCalls++; throw SocketTimeoutException("fake readiness timeout") }
        if (opCode == 0x9202) return result(ByteBuffer.allocate(10).order(ByteOrder.LITTLE_ENDIAN).putShort(0x012c.toShort()).putInt(0).putInt(0).array())
        if (opCode == 0x1004) return result(ByteArray(4))
        return result()
    }
}

fun main() {
    val camera = StartupTimeoutCamera()
    val ctrl = SonyPtpLiveViewController(camera) {}
    val failed = runCatching { ctrl.initialize(fastStartup = true) }.exceptionOrNull()
    check(failed is SocketTimeoutException)
    check(camera.readinessCalls == 1) { "Must not retry reads after a transport timeout" }
    println("STARTUP TIMEOUT SELF-TEST PASS: failed channel stops after one timeout")
}
