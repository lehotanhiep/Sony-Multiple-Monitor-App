"""Run actual tile/Remote telemetry methods with queued UI stubs."""
import os
from pathlib import Path
import subprocess
import tempfile
from ResLowRenderSelfTest import method
root = Path(__file__).resolve().parents[1]
source = root / 'app/src/main/java/com/example/sonymultilive'
compiler = os.environ.get('KOTLINC', 'kotlinc')
stdlib = os.environ['KOTLIN_STDLIB']
classes = []
for name in ['CameraTileView', 'RemoteCameraSettingColumnView']:
    text = (source / (name + '.kt')).read_text()
    state = next(line for line in text.splitlines() if 'private fun isRecordingForUi()' in line)
    body = method(text, 'fun setTelemetry(value: CameraTelemetry)')
    classes.append('class ' + name + ''' {
        private var telemetry = CameraTelemetry()
        val ui = Queue()
        val exposureField = Field()
        var controlsLocked = false
        var blinking = false
        fun post(r: () -> Unit) { ui.post(r) }
        fun refresh() { blinking = isRecordingForUi() }
        fun refreshOverlay() { blinking = isRecordingForUi() }
        fun updateRecordingBlink(active: Boolean) { blinking = active }
        fun confirmed() = isRecordingForUi()
    ''' + state + '\n' + body + '\n}\n')
main = '''
fun main() {
 val a = CameraTileView(); val b = CameraTileView(); val remote = RemoteCameraSettingColumnView()
 check(!a.confirmed() && !b.confirmed() && !remote.confirmed())
 // Only camera A acknowledges REC; B has no recording signal.
 a.setTelemetry(CameraTelemetry(recording=true)); b.setTelemetry(CameraTelemetry(recording=false))
 remote.setTelemetry(CameraTelemetry(recording=true))
 a.ui.flush(); b.ui.flush(); remote.ui.flush()
 check(a.blinking && !b.blinking && remote.blinking)
 a.setTelemetry(CameraTelemetry(recording=false)); remote.setTelemetry(CameraTelemetry(recording=false))
 a.ui.flush(); remote.ui.flush()
 check(!a.blinking && !remote.blinking)
 // Fast REC/STOP updates queued together must not leave a stale red frame.
 a.setTelemetry(CameraTelemetry(recording=true)); a.setTelemetry(CameraTelemetry(recording=false)); a.ui.flush()
 check(!a.blinking)
 println("CONFIRMED REC UI PASS: per-camera acknowledgment, no-signal idle, confirmed STOP and queued update race")
}
'''
main_source = (source / 'MainActivity.kt').read_text()
assert 'setRecordingCommandState' not in main_source
for name in ['CameraTileView', 'RemoteCameraSettingColumnView']:
    assert 'setRecordingCommandState' not in (source / (name+'.kt')).read_text()
assert 'SRC %.1f' not in (source / 'CameraTileView.kt').read_text()
with tempfile.TemporaryDirectory() as temp:
    harness = Path(temp) / 'ConfirmedRecHarness.kt'
    harness.write_text('''import com.example.sonymultilive.CameraTelemetry
class Queue { val tasks=mutableListOf<() -> Unit>(); fun post(r: () -> Unit) {tasks+=r}; fun flush() {val copy=tasks.toList(); tasks.clear(); copy.forEach {it()}} }
class Field { var alpha=1f }
''' + '\n'.join(classes) + main)
    jar = str(Path(temp) / 'test.jar')
    subprocess.run([compiler, '-nowarn', '-no-stdlib', '-no-reflect', '-classpath', stdlib, '-d', jar, str(harness), str(source / 'CameraTelemetry.kt')], check=True)
    subprocess.run(['java', '-cp', jar + os.pathsep + stdlib, 'ConfirmedRecHarnessKt'], check=True)
