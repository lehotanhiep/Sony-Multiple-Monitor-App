"""Test the real WB session/controller code with fake cameras and Android stubs.
Requires Python, Kotlin and JDK. Stubs in tools/ are never packaged in the app.
"""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
compiler = os.environ.get('KOTLINC', 'kotlinc')
compiler_path = Path(shutil.which(compiler) or compiler).resolve()
stdlib = os.environ.get('KOTLIN_STDLIB', str(compiler_path.parent.parent / 'lib/kotlin-stdlib.jar'))
classes = ['SonyCameraSession', 'SonyCamera', 'CameraTransport', 'CameraSetting',
           'CameraTelemetry', 'LiveViewProfile', 'LiveViewStats', 'SonyExposureLogic',
           'SonyCameraValueFormatter', 'SonyPtpClient', 'SonyPtpIpClient', 'SonyPtpLiveViewController']
sources = [root / 'app/src/main/java/com/example/sonymultilive' / (name + '.kt') for name in classes]
sources += sorted((root / 'tools/jvm-wb-stubs').glob('*.kt'))
sources += [root / 'tools/WhiteBalanceAllCamSelfTest.kt']
with tempfile.TemporaryDirectory() as temp:
    jar = str(Path(temp) / 'wb-test.jar')
    subprocess.run([compiler, '-nowarn', '-no-stdlib', '-no-reflect', '-classpath', stdlib,
                    '-d', jar] + [str(p) for p in sources], check=True)
    subprocess.run(['java', '-cp', jar + os.pathsep + stdlib, 'WhiteBalanceAllCamSelfTestKt'], check=True)
