"""Exercise actual tile ticker/update/telemetry code for mixed recording cameras."""
import os
from pathlib import Path
import subprocess
import tempfile
from ResLowRenderSelfTest import method
root = Path(__file__).resolve().parents[1]
java = root / 'app/src/main/java/com/example/sonymultilive'
s = (java / 'CameraTileView.kt').read_text()
ticker = method(s[s.index('private val recordingBorderTicker'):], 'override fun run()').replace('override fun run()', 'fun tick()').replace('ui.postDelayed(this,', 'ui.postDelayed(recordingBorderTicker,')
telemetry = method(s, 'fun setTelemetry(value: CameraTelemetry)')
update = method(s, 'private fun updateRecordingBlink(recording: Boolean)')
is_rec = next(line for line in s.splitlines() if 'private fun isRecordingForUi()' in line)
harness = '''
import com.example.sonymultilive.CameraTelemetry
class Field {var alpha=1f}
class Ui {
 val pending=mutableListOf<Runnable>()
 fun post(r:()->Unit) { r() }
 fun postDelayed(r:Runnable, ms:Long) {pending+=r}
 fun removeCallbacks(r:Runnable) {pending.removeAll {it===r}}
 fun step() {val copy=pending.toList();pending.clear();copy.forEach {it.run()}}
}
class Tile {
 private var telemetry=CameraTelemetry()
 val ui=Ui(); val exposureField=Field(); var controlsLocked=false
 var isAttachedToWindow=true; var recordBorderBright=false; var recordingBlinkRunning=false
 var borderRecording=false
 val recordingBorderTicker=Runnable {tick()}
 fun applyRecordingBorder(recording:Boolean) {borderRecording=recording}
 fun refreshOverlay() {}
''' + ticker + '\n' + telemetry + '\n' + update + '\n' + is_rec + '''
}
fun main() {
 val a=Tile(); val b=Tile(); val c=Tile()
 a.setTelemetry(CameraTelemetry(recording=true)); b.setTelemetry(CameraTelemetry(recording=false)); c.setTelemetry(CameraTelemetry(recording=true))
 check(a.borderRecording && !b.borderRecording && c.borderRecording)
 repeat(4) {
   val beforeA=a.recordBorderBright; val beforeC=c.recordBorderBright
   a.ui.step(); b.ui.step(); c.ui.step()
   check(a.recordBorderBright!=beforeA && c.recordBorderBright!=beforeC)
   check(!b.borderRecording && b.ui.pending.isEmpty())
   // B's STOP telemetry and A's repeated REC status must not stop/reset any other blink.
   b.setTelemetry(CameraTelemetry(recording=false))
   val phase=a.recordBorderBright
   a.setTelemetry(CameraTelemetry(recording=true)); check(a.recordBorderBright==phase)
 }
 a.setTelemetry(CameraTelemetry(recording=false))
 val beforeC=c.recordBorderBright
 a.ui.step(); b.ui.step(); c.ui.step()
 check(!a.borderRecording && a.ui.pending.isEmpty())
 check(c.borderRecording && c.recordBorderBright!=beforeC)
 println("PER CAMERA BLINK PASS: actual tickers A/C blink with B idle; A STOP leaves C blinking; repeated telemetry preserves phase")
}
'''
compiler=os.environ.get('KOTLINC','kotlinc');stdlib=os.environ['KOTLIN_STDLIB']
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp)/'PerCameraBlinkHarness.kt'; p.write_text(harness)
 jar=str(Path(temp)/'test.jar')
 subprocess.run([compiler,'-nowarn','-no-stdlib','-no-reflect','-classpath',stdlib,'-d',jar,str(p),str(java/'CameraTelemetry.kt')],check=True)
 subprocess.run(['java','-cp',jar+os.pathsep+stdlib,'PerCameraBlinkHarnessKt'],check=True)
