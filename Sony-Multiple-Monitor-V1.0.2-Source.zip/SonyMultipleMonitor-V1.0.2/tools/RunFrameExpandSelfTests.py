"""Test gesture decisions and actual MainActivity expanded-layout/restore branch."""
import os
from pathlib import Path
import subprocess
import tempfile
from ResLowRenderSelfTest import method
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/example/sonymultilive'
s=(java/'MainActivity.kt').read_text()
branch=method(s,'private fun rebuildGrid()')
branch=branch[:branch.index('        val fleetSelectMode')] + '        normalBuilds++\n    }\n'
restore=method(s,'private fun restoreExpandedFrame()')
harness='''
class ViewGroup {fun removeView(v:Any) {}}
class LinearLayout {class LayoutParams(val w:Int,val h:Int,val weight:Float) {companion object {const val MATCH_PARENT=-1}}}
object Color {const val BLACK=0}
class Camera(val id:String)
class CameraTileView(id:String) {val camera=Camera(id); val parent:Any?=null; @JvmField var displayIndex=0; var density=0
 fun setDisplayIndex(i:Int) {displayIndex=i}; fun setTelemetryDensity(i:Int) {density=i}}
class AspectRatioCell(c:Any) {var tile:CameraTileView?=null; fun setBackgroundColor(c:Int) {}; fun addView(t:CameraTileView) {tile=t}}
class Grid {var weightSum=0f; val cells=mutableListOf<AspectRatioCell>(); fun removeAllViews() {cells.clear()}; fun addView(c:AspectRatioCell,p:LinearLayout.LayoutParams) {cells+=c}}
class Button {var text=""}
class Harness {
 val grid=Grid(); var expandedCameraId:String?=null; val tiles=linkedMapOf<String,CameraTileView>()
 val slots=arrayOfNulls<CameraTileView>(3); lateinit var layoutButton:Button
 var normalBuilds=0; var gridLayoutMode="2+1"; var recordingState="REC A only"
 fun tilesForFixedSlots()=slots
 fun updateLiveViewButton() {}
 fun build()=rebuildGrid(); fun restore()=restoreExpandedFrame()
'''+branch+restore+'''
}
fun main() {
 val h=Harness(); val a=CameraTileView("a"); val b=CameraTileView("b"); val c=CameraTileView("c")
 h.tiles["a"]=a;h.tiles["b"]=b;h.tiles["c"]=c; h.slots[0]=a;h.slots[1]=b;h.slots[2]=c
 val saved=h.slots.copyOf(); h.expandedCameraId="b";h.build()
 check(h.grid.cells.size==1 && h.grid.cells.single().tile===b && b.displayIndex==2)
 check(h.slots.contentEquals(saved) && h.gridLayoutMode=="2+1" && h.recordingState=="REC A only")
 h.restore();check(h.expandedCameraId==null && h.normalBuilds==1 && h.slots.contentEquals(saved))
 h.expandedCameraId="b"; h.tiles.remove("b"); h.build()
 check(h.expandedCameraId==null && h.normalBuilds==2)
 println("EXPANDED LAYOUT PASS: chosen camera only, saved slots/layout unchanged, restore and missing-camera fallback")
}
'''
compiler=os.environ.get('KOTLINC','kotlinc');stdlib=os.environ['KOTLIN_STDLIB']
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp)/'ExpandedLayoutHarness.kt';p.write_text(harness)
 for test,files in [('CameraFrameGestureSelfTest',[java/'CameraFrameGesture.kt',root/'tools/CameraFrameGestureSelfTest.kt']),('ExpandedLayoutHarness',[p])]:
  jar=str(Path(temp)/(test+'.jar'))
  subprocess.run([compiler,'-nowarn','-no-stdlib','-no-reflect','-classpath',stdlib,'-d',jar]+[str(f) for f in files],check=True)
  subprocess.run(['java','-cp',jar+os.pathsep+stdlib,test+'Kt'],check=True)
