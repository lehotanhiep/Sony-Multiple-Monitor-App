import com.example.sonymultilive.CameraTransport
import com.example.sonymultilive.SonyCamera
import com.example.sonymultilive.SonyPtpClient
import com.example.sonymultilive.SonyPtpLiveViewController

private class FriendlyNamePtp(private val deviceName: String) : SonyPtpClient {
    override fun connect(timeoutMs: Int) {}
    override fun openSession(sessionId: Int) = SonyPtpClient.PtpResult(SonyPtpClient.RC_OK, intArrayOf(), byteArrayOf())
    override fun transaction(opCode: Int, params: IntArray, dataOut: ByteArray?): SonyPtpClient.PtpResult {
        if (opCode == 0x1015 && params.contentEquals(intArrayOf(0xD402))) {
            val count = deviceName.length + 1
            val out = ByteArray(1 + count * 2)
            out[0] = count.toByte()
            deviceName.forEachIndexed { index, c ->
                out[1 + index * 2] = (c.code and 0xff).toByte()
                out[2 + index * 2] = ((c.code ushr 8) and 0xff).toByte()
            }
            return SonyPtpClient.PtpResult(SonyPtpClient.RC_OK, intArrayOf(), out)
        }
        return SonyPtpClient.PtpResult(0x2005, intArrayOf(), byteArrayOf())
    }
    override fun close() {}
}

fun main() {
    val controller = SonyPtpLiveViewController(FriendlyNamePtp("CAM-A-WIDE")) {}
    check(controller.readCameraDeviceNameBestEffort() == "CAM-A-WIDE")

    val camera = SonyCamera(
        id = "usb:test",
        friendlyName = "ZV-E10M2",
        modelName = "ZV-E10M2",
        locationUrl = "",
        host = "",
        transport = CameraTransport.USB_PTP
    )
    check(camera.displayName == "ZV-E10M2")
    camera.deviceName = "CAM-A-WIDE"
    check(camera.displayName == "CAM-A-WIDE")

    println("DEVICE NAME SELF-TEST PASS: D402 overrides model/discovery label")
}
