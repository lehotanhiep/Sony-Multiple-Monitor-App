import com.example.sonymultilive.CameraFrameGesture
fun main() {
 val g=CameraFrameGesture(14f)
 g.begin("cam2",100f,100f,1000)
 check(g.takeHold(2999)==null)
 check(g.takeHold(3000)=="cam2" && g.held)
 check(g.takeHold(4000)==null) // Exactly one expansion.
 check(!g.swipeDown(100f,250f,70f)) // Release of hold cannot also close preview.
 g.end()
 g.begin(null,100f,100f,4000)
 g.move(105f,210f)
 check(g.swipeDown(105f,210f,70f))
 check(!g.swipeUp(105f,210f,70f))
 g.end()
 g.begin("cam1",0f,0f,5000); g.move(15f,0f)
 check(g.takeHold(7000)==null) // Drag cancels hold even if finger returns.
 g.begin("cam1",0f,0f,5000); g.multiplePointers()
 check(g.takeHold(7000)==null && !g.swipeDown(0f,200f,70f))
 g.begin("cam1",0f,0f,5000); g.end(); check(g.takeHold(7000)==null)
 g.begin(null,0f,0f,5000); check(g.takeHold(7000)==null)
 check(!g.swipeDown(200f,90f,70f)) // Horizontal/diagonal drag does not exit.
 check(g.swipeUp(2f,-100f,70f))
 println("FRAME GESTURE PASS: 2-second hold, one trigger, release suppression, swipe down/up, move/multitouch/cancel")
}
