import com.example.sonymultilive.FrameBlendClock

fun main() {
    val clock = FrameBlendClock()
    clock.frameArrived(0, false)
    check(clock.alpha(0) == 1f)
    clock.frameArrived(100, true)
    check(clock.alpha(100) == 0f)
    check(kotlin.math.abs(clock.alpha(140) - 0.4f) < 0.001f)
    check(kotlin.math.abs(clock.alpha(180) - 0.8f) < 0.001f)
    check(clock.alpha(200) == 1f)
    clock.frameArrived(600, true)
    check(clock.alpha(720) == 1f) // Bound extra presentation latency to 120ms.
    clock.frameArrived(630, true)
    check(clock.alpha(630) == 1f) // Fast source must display immediately.
    clock.frameArrived(2000, true)
    check(clock.alpha(2000) == 1f) // Resume after a stale/disconnected source.
    clock.resetTicker()
    check(clock.delayToNextTick(2000) == 40L)
    check(clock.delayToNextTick(2040) == 40L)
    check(clock.delayToNextTick(2250) == 40L) // No catch-up burst after a stalled UI.
    println("PASS: low-FPS blend, fast source, stale resume, bounded delay and 25Hz scheduling")
}
