import com.example.sonymultilive.SonyPtpClient
import com.example.sonymultilive.SonyPtpLiveViewController

private data class RecCall(val op: Int, val params: List<Int>, val data: List<Int>)

private class FakeRecPtp : SonyPtpClient {
    val calls = mutableListOf<RecCall>()
    override fun connect(timeoutMs: Int) {}
    override fun openSession(sessionId: Int) = SonyPtpClient.PtpResult(SonyPtpClient.RC_OK, intArrayOf(), byteArrayOf())
    override fun transaction(opCode: Int, params: IntArray, dataOut: ByteArray?): SonyPtpClient.PtpResult {
        calls += RecCall(opCode, params.toList(), dataOut?.map { it.toInt() and 0xff } ?: emptyList())
        return SonyPtpClient.PtpResult(SonyPtpClient.RC_OK, intArrayOf(), byteArrayOf())
    }
    override fun close() {}
}

private fun setUsbMode(ctrl: SonyPtpLiveViewController, enabled: Boolean) {
    val f = SonyPtpLiveViewController::class.java.getDeclaredField("usbCrCmdV3")
    f.isAccessible = true
    f.setBoolean(ctrl, enabled)
}

private fun verify(label: String, usb: Boolean) {
    val ptp = FakeRecPtp()
    val ctrl = SonyPtpLiveViewController(ptp) {}
    setUsbMode(ctrl, usb)

    check(ctrl.setMovieRecording(true))
    check(ctrl.setMovieRecording(false))

    val d2c8 = ptp.calls.filter { it.op == 0x9207 && it.params == listOf(0xD2C8) }
    check(d2c8.size == 2) { "$label expected two D2C8 calls, got $d2c8" }
    check(d2c8[0].data == listOf(2, 0)) { "$label REC must be D2C8=2, got ${d2c8[0]}" }
    check(d2c8[1].data == listOf(1, 0)) { "$label STOP must be D2C8=1, got ${d2c8[1]}" }
}

fun main() {
    verify("PTP/IP", usb = false)
    verify("USB", usb = true)
    println("REC POLARITY SELF-TEST PASS: USB + PTP/IP use D2C8 REC=2 / STOP=1")
}
