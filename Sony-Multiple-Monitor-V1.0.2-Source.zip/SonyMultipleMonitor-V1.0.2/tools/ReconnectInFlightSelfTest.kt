import android.content.Context
import com.example.sonymultilive.*
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

fun main() {
    var queued = 0
    val s = SonyCameraSession(Context(), SonyCamera.manual("127.0.0.1"), Executor { queued++ }, {}, {}, {})
    val type = SonyCameraSession::class.java
    fun field(name: String): Any = type.getDeclaredField(name).apply { isAccessible = true }.get(s)
    (field("stopped") as AtomicBoolean).set(false)
    (field("generation") as AtomicInteger).set(5)
    (field("connectingGeneration") as AtomicInteger).set(5)
    check(s.isConnecting())
    repeat(10) { s.retryDirectPtp() }
    check(queued == 0) { "An in-flight connection was restarted" }
    (field("connectingGeneration") as AtomicInteger).set(4)
    check(!s.isConnecting()) { "Older generation must not block recovery" }
    (field("connectingGeneration") as AtomicInteger).set(0)
    check(!s.isConnecting())
    println("RECONNECT IN-FLIGHT SELF-TEST PASS: repeated retry does not restart connecting session; generation ownership preserved")
}
