import android.content.Context
import com.example.sonymultilive.*
fun main() {
 val result = SonyPtpDiscovery(Context()).discover(maxCameras=4, excludeHosts=setOf("192.168.1.10"))
 check(ProbeTrace.fetched == listOf("192.168.1.11")) { "Connected camera was queried again" }
 check(result.cameras.map { it.host } == listOf("192.168.1.11"))
 check(ProbeTrace.exclusions.containsAll(listOf("192.168.1.10", "192.168.1.11"))) { "Subnet scan would reprobe known hosts" }
 println("PASS: connected SSDP host skipped before fetch; subnet skips connected and newly discovered hosts")
}
