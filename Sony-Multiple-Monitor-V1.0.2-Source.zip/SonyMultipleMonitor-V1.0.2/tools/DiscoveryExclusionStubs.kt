package com.example.sonymultilive
import android.content.Context
import java.net.InetAddress
object ProbeTrace { val fetched = mutableListOf<String>(); var exclusions = emptySet<String>() }
class SsdpDiscovery(c: Context) {
 data class Stats(val packets:Int=2,val locations:Int=2,val sonyServerPackets:Int=2)
 val lastStats=Stats()
 fun discover(t:Long)=listOf("http://192.168.1.10/dd.xml", "http://192.168.1.11/dd.xml")
}
object SonyNetworkRoute { fun findWifiNetworkForHost(c:Context,h:String,t:Int): Any?=null }
object TetheringNetworkRoute { fun findForHost(c:Context,h:String): Any?=null }
object SonyDeviceDescription {
 fun fetch(l:String,n:Any?):SonyCamera { val h=java.net.URL(l).host; ProbeTrace.fetched+=h; return SonyCamera.manual(h) }
 fun fetchByHost(h:String,n:Any?):SonyCamera { error("Unrouted fixed fallback must not probe") }
}
object SonyAccessPointDiscovery {
 data class Probe(val host:String,val ddOpen:Boolean=false,val ptpOpen:Boolean=false)
 data class Result(val cameras:List<SonyCamera>,val subnetLabel:String,val probedHosts:Int,val serviceHosts:Int,val probes:List<Probe>)
 fun scan(context:Context,maxCameras:Int,connectTimeoutMs:Int,excludeHosts:Set<String>,excludeMacs:Set<String>):Result {
 ProbeTrace.exclusions=excludeHosts; return Result(emptyList(),"test",0,0,emptyList()) }
}
object LocalNetworkAddress {
 data class Address(val ip:InetAddress,val prefixLength:Int,val interfaceName:String)
 fun findAll(c:Context)=emptyList<Address>()
}
