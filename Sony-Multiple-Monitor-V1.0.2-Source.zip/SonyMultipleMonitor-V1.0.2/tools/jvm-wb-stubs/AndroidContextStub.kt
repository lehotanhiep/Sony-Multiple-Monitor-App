package android.content
open class Context {
    val applicationContext: Context get() = this
    fun getSharedPreferences(name: String, mode: Int) = Preferences()
    companion object { const val MODE_PRIVATE = 0 }
}
class Preferences {
    fun getString(key: String, default: String?): String? = default
    fun edit() = Editor()
}
class Editor {
    fun putString(key: String, value: String) = this
    fun apply() {}
}
