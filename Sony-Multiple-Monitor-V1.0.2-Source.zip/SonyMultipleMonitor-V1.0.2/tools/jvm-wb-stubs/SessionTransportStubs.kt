package com.example.sonymultilive
import android.content.Context
import java.net.Socket
class SonyUsbPtpClient(context: Context, usbDeviceName: String, usbDeviceId: Int?, onEvent: (SonyPtpClient.PtpEvent) -> Unit) : SonyPtpClient {
    override fun connect(timeoutMs: Int) {}
    override fun openSession(sessionId: Int): SonyPtpClient.PtpResult = error("USB stub")
    override fun transaction(opCode: Int, params: IntArray, dataOut: ByteArray?): SonyPtpClient.PtpResult = error("USB stub")
    override fun close() {}
    fun diagnostics() = "stub"
}
class TestNetwork { fun bindSocket(socket: Socket) {} }
object SonyNetworkRoute {
    fun findWifiNetworkForHost(context: Context, host: String, timeout: Int): TestNetwork? = null
    fun describe(context: Context, host: String, network: TestNetwork) = "stub"
}
class TetheringNetworkRoute {
    val label = "stub"
    fun bind(socket: Socket) {}
    companion object { fun findForHost(context: Context, host: String): TetheringNetworkRoute? = null }
}
