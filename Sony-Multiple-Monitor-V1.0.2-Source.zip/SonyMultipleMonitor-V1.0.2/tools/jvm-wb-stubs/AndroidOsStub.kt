package android.os
object Build { const val MODEL = "JVM test" }
object Process {
    const val THREAD_PRIORITY_DISPLAY = -4
    fun setThreadPriority(priority: Int) {}
}
object SystemClock { fun elapsedRealtimeNanos() = System.nanoTime(); fun elapsedRealtime() = System.nanoTime() / 1_000_000 }
