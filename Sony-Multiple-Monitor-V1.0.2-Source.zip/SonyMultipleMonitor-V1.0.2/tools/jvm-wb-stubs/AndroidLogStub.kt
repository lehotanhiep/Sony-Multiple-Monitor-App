package android.util
object Log { fun i(tag: String, msg: String): Int = 0 }
