"""JVM regressions for reconnect, first frame and retained WB/USB behavior.
Requires Python, Kotlin and JDK; tools/jvm-wb-stubs are test-only dependencies.
"""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import sys

root = Path(__file__).resolve().parents[1]
compiler = os.environ.get('KOTLINC', 'kotlinc')
compiler_path = Path(shutil.which(compiler) or compiler).resolve()
stdlib = os.environ.get('KOTLIN_STDLIB', str(compiler_path.parent.parent / 'lib/kotlin-stdlib.jar'))
classes = ['SonyCameraSession', 'SonyCamera', 'CameraTransport', 'CameraSetting',
           'CameraTelemetry', 'LiveViewProfile', 'LiveViewStats', 'SonyExposureLogic',
           'SonyCameraValueFormatter', 'SonyPtpClient', 'SonyPtpIpClient', 'SonyPtpLiveViewController']
sources = [root / 'app/src/main/java/com/example/sonymultilive' / (name + '.kt') for name in classes]
sources += sorted((root / 'tools/jvm-wb-stubs').glob('*.kt'))
tests = ['PerCameraRecConfirmationSelfTest', 'PtpQuickReconnectSelfTest', 'PtpStartupTimeoutSelfTest', 'ReconnectInFlightSelfTest',
         'PtpSourceResolutionSelfTest', 'PtpUsbLiveViewSelfTest', 'PtpDeviceNameSelfTest', 'WhiteBalanceAllCamSelfTest']
if len(sys.argv) > 1:
    tests = sys.argv[1:]
with tempfile.TemporaryDirectory() as temp:
    core = str(Path(temp) / 'core.jar')
    subprocess.run([compiler, '-nowarn', '-no-stdlib', '-no-reflect', '-classpath', stdlib,
                    '-d', core] + [str(p) for p in sources], check=True)
    for test in tests:
        jar = str(Path(temp) / (test + '.jar'))
        cp = core + os.pathsep + stdlib
        subprocess.run([compiler, '-nowarn', '-no-stdlib', '-no-reflect', '-classpath', cp,
                        '-d', jar, str(root / 'tools' / (test + '.kt'))], check=True)
        subprocess.run(['java', '-cp', jar + os.pathsep + cp, test + 'Kt'], check=True, timeout=45)
