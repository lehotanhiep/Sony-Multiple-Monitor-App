"""Regression tests for presentation timing and connected-host discovery exclusions.
DiscoveryExclusionStubs.kt is test-only; do not copy it into app sources.
"""
import os
from pathlib import Path
import subprocess
import tempfile
root = Path(__file__).resolve().parents[1]
source = root / 'app/src/main/java/com/example/sonymultilive'
compiler = os.environ.get('KOTLINC', 'kotlinc')
stdlib = os.environ['KOTLIN_STDLIB']
with tempfile.TemporaryDirectory() as temp:
    for test, files in [
        ('FrameBlendClockSelfTest', [source / 'FrameBlendClock.kt']),
        ('DiscoveryExclusionSelfTest', [source / (n + '.kt') for n in ['SonyPtpDiscovery', 'SonyCamera', 'CameraTransport', 'CameraIdentity']] + [root / 'tools/DiscoveryExclusionStubs.kt', root / 'tools/jvm-wb-stubs/AndroidContextStub.kt'])
    ]:
        jar = str(Path(temp) / (test + '.jar'))
        subprocess.run([compiler, '-nowarn', '-no-stdlib', '-no-reflect', '-classpath', stdlib, '-d', jar] + [str(f) for f in files] + [str(root / 'tools' / (test + '.kt'))], check=True)
        subprocess.run(['java', '-cp', jar + os.pathsep + stdlib, test + 'Kt'], check=True)
